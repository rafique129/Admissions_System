<?php include"header.php"; ?>

<h4 class="welcome">Terms & Conditions</h4>
<p class="text"><strong>The applicant is required to read thoroughly and understand the terms and conditions, policies and procedures of the company as given below. This application/agreement form is considered as an authentic and legally binding document. This contract is between the Applicant (hereinafter referred to as Member) and <?php echo $cname; ?>  (hereinafter referred to as LIFE EASY)</strong></p>
<ol type="1" class="text"> 
<li>The applicant should have completed minimum 18 years of age and shall be competent to enter into contract as provided in the Indian Contract Act.</li>
<li>There is no Registration Fees OR any charges to join the LIFE EASY. The LIFE EASY not responsible or liable for any amount of cash paid to anybody anywhere except at the registered office of the <?php echo $cname; ?>.</li>
<li>The registered member shall be entitled to promote "PACKAGE"  issued by the <?php echo $cname; ?>.</li>
<li>The applicant has to pay Rs. 1000/-  with each product.</li>
<li>Maintenance/Administrative charges will be deducted from Member's First Payout as and when generated. </li>
<li>Payment will be made only when an ID reaches the Minimum Limit of Rs.500/-. This Minimum Limit is at the sole discretion of <?php echo $cname; ?>. Whenever it is changed, the information will be provided on the Website.</li>
<li>In all cases incentives and awards will be given after deduction of T.D.S. 10% as formulated by the Government norms & 10% processing charges.</li>
<li>Annual Maintainance charge will be deducted after every 12 months from respective member account</li>
<li>Member can also avail his product by personally visit at <?php echo $cname; ?> office, or personally mailed,couriered with additional charges. </li>
<li>The Commission/Incentives will be credited on fortnightly basis by Direct Transfer in respective member's bank account by the <?php echo $cname; ?> or cheque or Money Order and member understand that <?php echo $cname; ?> do not offer refunds for services or memberships</li>
<li>The applicant has to submit compulsory one passport size photograph and Identity Proof to the <?php echo $cname; ?> with Application form. The members have to submit Residence Proof if required by the <?php echo $cname; ?> or Bank for verification at any point of time.</li>
<li>At any point of time, if member would like to change his/her Mobile number or Communication address the member has to and his/her liability to inform the <?php echo $cname; ?>.  </li>
<li>The member will be eligible for incentives or commission only as per the volume of joining done by him/her and also subject to the eligibility norms formulated by the <?php echo $cname; ?>. The <?php echo $cname; ?> dose not assures any commission or incentive to the member on merely account of his/her joining the <?php echo $cname; ?>.</li>
<li>The member will not be a consumer, agent, or employee of the <?php echo $cname; ?>. His/her position being so, he/she can not bind the <?php echo $cname; ?> in any manner, nor he/she has any authority to bind the <?php echo $cname; ?> or to represent or speak on behalf of the <?php echo $cname; ?>.</li>
<li>The member has to pay annual renewal fees at the end of 12 months of their membership as per the <?php echo $cname; ?> norms.</li>
<li>All individual members should adhere to rules and regulations formed by the <?php echo $cname; ?> and if any of the members is found guilty of not observing the same, then he/she will be terminated from the <?php echo $cname; ?>.</li>
<li>The <?php echo $cname; ?> reserves all rights to terminate a membership in following cases :

	<ul type="disc" class="text">
	<li>If the member Acts against the interest of the <?php echo $cname; ?>.</li>
	<li>If the member refuses to accept any of the Terms and Conditions agreed upon with the <?php echo $cname; ?> or subsequently altered / amended / added by the <?php echo $cname; ?>.</li>
	</ul>
</li>
<li>Once a membership is terminated, he/she cannot enter into any of the <?php echo $cname; ?> premises, meeting location of the <?php echo $cname; ?> and his/her incentives/commission will be stopped immediately.</li>
<li>The member shall not compel or induce or mislead any person with any false statement/promise to join the <?php echo $cname; ?>. </li>
<li>The <?php echo $cname; ?> reserves the right to reject any membership/member at its own discretion.</li>
<li>The member shall ensure that all the information furnished to the company is correct and properly entered. Any request for correction furnished by the member as to his /her sponsor or placement details will not be entertained, once payments are processed. </li>
<li>Member agrees to business policy of <?php echo $cname; ?>.</li>
<li>The <?php echo $cname; ?> reserves the right to modify the terms and conditions, make any alteration, amendment and additions, at any time for any reason, giving prior notice through its website and it will be binding on all the members of the <?php echo $cname; ?>, however it is also member's responsibility to check this document webpage periodically for any changes.</li>
<li>In case due to change in Government and enactment of law, <?php echo $cname; ?>'S business is closed, the <?php echo $cname; ?> shall not be liable for any kind of claims.</li>
<li>The Terms and Conditions within above mentioned shall be governed in accordance with the law in force in the territories of India. Disputes if any arise, shall be subject to the exclusive jurisdiction of the court of Madurai.</li>
</ol>
<?php include"footer.php"; ?>