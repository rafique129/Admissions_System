<table align="center" cellpadding="0" cellspacing="0" width="245">
<tr>
<td align="center">

<?php if ($_SESSION['resort_user_login']=='') { ?>
<form method="post">
<table align="center" cellpadding="4" cellspacing="4" width="100%">
<tr><td class="user_text">User ID</td>
<td style="background:url(images/input_box.png) no-repeat;" width="144"><input type="text" name="uname" size="16" style="border:0px; background:#f3f3f3;"></td></tr>
<tr><td class="user_text">Password</td>
	<td style="background:url(images/input_box.png) no-repeat;"><input type="password" name="pword" size="16" style="border:0px; background:#f3f3f3;"></td></tr>
<tr><td colspan="2">

<table align="center" cellpadding="0" cellspacing="0" width="100%">
	<tr>
	<td>
	<a href="join_now.php" class="user_text">Students <font color="#FFFF00">Admission Form</font></a>
	</td>
	<td align="right"><input type="hidden" name="user_login" value="Login" /><input type="image" src="images/login.png" name="user_login"></td>
	</tr>
</table>

</td>
</tr>	
</table>
</form>
<?php } else { ?>

<div align="center">
<div>
<span class="user_text">
Welcome <font color="#FFFF00"><?php echo kandu_pidi($_SESSION['resort_user_login'],$table4,name); ?></font><br />
User ID : <?php echo new_number($_SESSION['resort_user_login'],$table4); ?> | <a href="logout.php" style="color:#FFFF00;">Sign Out</a>
</span>
</div>
</div>

<?php } ?>

</td>
</tr>
</table>