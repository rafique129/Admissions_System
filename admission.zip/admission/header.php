<?php include "include/db.php"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<style type="text/css">
#fixedtipdiv{
position:absolute;
padding: 2px;
border:1px solid black;
font:normal 12px Verdana;
line-height:18px;
z-index:100;
}
</style>
<script type="text/javascript">

/***********************************************
* Fixed ToolTip script- © Dynamic Drive (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit http://www.dynamicdrive.com/ for full source code
***********************************************/
		
var tipwidth='150px' //default tooltip width
var tipbgcolor='lightyellow'  //tooltip bgcolor
var disappeardelay=250  //tooltip disappear speed onMouseout (in miliseconds)
var vertical_offset="0px" //horizontal offset of tooltip from anchor link
var horizontal_offset="-3px" //horizontal offset of tooltip from anchor link

/////No further editting needed

var ie4=document.all
var ns6=document.getElementById&&!document.all

if (ie4||ns6)
document.write('<div id="fixedtipdiv" style="visibility:hidden;width:'+tipwidth+';background-color:'+tipbgcolor+'" ></div>')

function getposOffset(what, offsettype){
var totaloffset=(offsettype=="left")? what.offsetLeft : what.offsetTop;
var parentEl=what.offsetParent;
while (parentEl!=null){
totaloffset=(offsettype=="left")? totaloffset+parentEl.offsetLeft : totaloffset+parentEl.offsetTop;
parentEl=parentEl.offsetParent;
}
return totaloffset;
}


function showhide(obj, e, visible, hidden, tipwidth){
if (ie4||ns6)
dropmenuobj.style.left=dropmenuobj.style.top=-500
if (tipwidth!=""){
dropmenuobj.widthobj=dropmenuobj.style
dropmenuobj.widthobj.width=tipwidth
}
if (e.type=="click" && obj.visibility==hidden || e.type=="mouseover")
obj.visibility=visible
else if (e.type=="click")
obj.visibility=hidden
}

function iecompattest(){
return (document.compatMode && document.compatMode!="BackCompat")? document.documentElement : document.body
}

function clearbrowseredge(obj, whichedge){
var edgeoffset=(whichedge=="rightedge")? parseInt(horizontal_offset)*-1 : parseInt(vertical_offset)*-1
if (whichedge=="rightedge"){
var windowedge=ie4 && !window.opera? iecompattest().scrollLeft+iecompattest().clientWidth-15 : window.pageXOffset+window.innerWidth-15
dropmenuobj.contentmeasure=dropmenuobj.offsetWidth
if (windowedge-dropmenuobj.x < dropmenuobj.contentmeasure)
edgeoffset=dropmenuobj.contentmeasure-obj.offsetWidth
}
else{
var windowedge=ie4 && !window.opera? iecompattest().scrollTop+iecompattest().clientHeight-15 : window.pageYOffset+window.innerHeight-18
dropmenuobj.contentmeasure=dropmenuobj.offsetHeight
if (windowedge-dropmenuobj.y < dropmenuobj.contentmeasure)
edgeoffset=dropmenuobj.contentmeasure+obj.offsetHeight
}
return edgeoffset
}

function fixedtooltip(menucontents, obj, e, tipwidth){
if (window.event) event.cancelBubble=true
else if (e.stopPropagation) e.stopPropagation()
clearhidetip()
dropmenuobj=document.getElementById? document.getElementById("fixedtipdiv") : fixedtipdiv
dropmenuobj.innerHTML=menucontents

if (ie4||ns6){
showhide(dropmenuobj.style, e, "visible", "hidden", tipwidth)
dropmenuobj.x=getposOffset(obj, "left")
dropmenuobj.y=getposOffset(obj, "top")
dropmenuobj.style.left=dropmenuobj.x-clearbrowseredge(obj, "rightedge")+"px"
dropmenuobj.style.top=dropmenuobj.y-clearbrowseredge(obj, "bottomedge")+obj.offsetHeight+"px"
}
}

function hidetip(e){
if (typeof dropmenuobj!="undefined"){
if (ie4||ns6)
dropmenuobj.style.visibility="hidden"
}
}

function delayhidetip(){
if (ie4||ns6)
delayhide=setTimeout("hidetip()",disappeardelay)
}

function clearhidetip(){
if (typeof delayhide!="undefined")
clearTimeout(delayhide)
}

</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Admission System for Taraba State University</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script defer type="text/javascript" src="pngfix.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js"></script>
<style type="text/css">
<!--
.style1 {
	color: #FFFFFF;
	font-weight: bold;
	font-size: 24px;
}
-->
</style>
</head>
<body bgcolor="#075C9E" style="margin:0px;">

<table bgcolor="#3198D6" align="center" cellpadding="0" cellspacing="0" width="100%" style="border-left:0px solid #000000; border-right:0px solid #000000; border-bottom:0px solid #000000;">

<tr>
<td>


<table align="center" cellpadding="0" cellspacing="0" width="1000">
<tr>
<td style="background:url(images/background.jpg) repeat-y;">

<table align="center" cellpadding="0" cellspacing="0" width="962">
<tr>
<td>

<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr><td height="10" colspan="3"></td></tr>
<tr>
<td width="178">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/poly logo.jpg" alt="poly" width="131" height="121" /></td>
<td align="center" width="523"><span class="style1">ONLINE ADMISSION SYSTEM FOR KADUNA POLYTECHNIC</span> </td>
<td align="right" valign="top" width="257"><?php include"user_login.php"; ?></td>
</tr>
</table>


<tr><td height="20"></td></tr>
<tr><td align="center">
<?php
if (($_SESSION['resort_user_login']=='')) { include"menu.php"; } else { include"menu_logged_in.php"; }
?>
</td></tr>
</table>

<tr bgcolor="#085D9F"><td height="10"></td></tr>
<tr><td style="background:url(images/banner_back.jpg) repeat-x;">

<table align="center" cellpadding="0" cellspacing="0" width="962">
<tr>
  <td width="720"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="720" height="288" title="flash">
    <param name="movie" value="polyf.swf" />
    <param name="quality" value="high" />
    <embed src="polyf.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="720" height="288"></embed>
  </object></td>
  <td width="10"></td>
<td valign="top" align="center"><?php include"latest_news.php"; ?></td>
</tr>
<tr><td height="10" colspan="3"></td></tr>
</table>

</td>
</tr>
<tr>
<td valign="top">

<table align="center" cellpadding="0" cellspacing="0" width="962">
<tr>
<td width="720" valign="top">

