<div align="left">
<table align="left" cellpadding="0" cellspacing="0">
<tr>
<td style="background:url(images/menu_01.png) no-repeat;" width="120" height="43" align="center"><a href="website.php" class="menu">Home</a></td>
<td style="background:url(images/menu_02.png) no-repeat;" width="120" height="43" align="center"><a href="about.php" class="menu">About Us</a></td>
<?php /*
<td style="background:url(images/menu_02.png) no-repeat;" width="120" height="43" align="center"><a href="products.php" class="menu">Products</a></td>
<td style="background:url(images/menu_02.png) no-repeat;" width="120" height="43" align="center"><a href="business_plan.php" class="menu">Business Plan</a></td>
<td style="background:url(images/menu_02.png) no-repeat;" width="120" height="43" align="center"><a href="rewards.php" class="menu">Rewards</a></td>
*/?>
<td style="background:url(images/menu_02.png) no-repeat;" width="120" height="43" align="center"><a href="javascript:void(0)" onclick="window.open('feedback.php', 'newwindow', 'width=1002,height=471,scrollbars=yes,resizable=no')" class="menu">Feedback</a></td>
<td style="background:url(images/menu_02.png) no-repeat;" width="120" height="43" align="center"><a href="contact.php" class="menu">Contact Us</a></td>
<td style="background:url(images/menu_03.png) no-repeat;" width="242" height="43" align="center"><a href="course.php" class="menu">Course</a></td>
</tr>
</table>
</div>