<table cellpadding="10" align="center">
<tr>
<td align="center"><a href="biography.php" class="text" style="color:#000000;"><img src="images/bio_report.jpg" border="0" /></a></td>
<td align="center"><a href="account.php" class="text" style="color:#000000;"><img src="images/income_report.jpg" border="0" /></a></td>
</tr>
</table>
