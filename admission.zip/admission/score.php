<?php include"header.php"; ?>

<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="14"><img src="images/orange_left.png" width="14" height="43" /></td>
<td style="background:url(images/orange_center.jpg)" class="mtitle"><img src="images/arrow.png" align="absmiddle" /> My Profile</td>
<td width="14" align="right"><img src="images/orange_right.png" width="14" height="43" /></td>
</tr>
<tr bgcolor="#FFFFFF">
<td></td>
<td valign="top" class="text">

<?php if ($_SESSION['resort_user_login']=='') { echo '<script>window.location.href="website.php";</script>'; } else { ?>
<?php $welcome='Mark Details'; include "member.php"; ?>
<?php $ed_ge=mysql_fetch_array(mysql_query("select * from $table4 where sno='$main_sno'")); ?>

<?php //include "for_profile.php"; ?>

<table align="center" cellpadding="5" cellspacing="5" width="100%" style="border:1px solid #447322;">

<tr bgcolor="#447322">
<td colspan="2" valign="top" class="mtitle">
<strong>My Mark Details</strong>
</td>
</tr>

<tr>
<td class="text">Maths:</td>
<td class="text"><?php echo $ed_ge['m_1']; ?></td>
</tr>
<tr bgcolor="#F2F2F2">
<td class="text">English:</td>
<td class="text"><?php echo $ed_ge['m_2']; ?></td>
</tr>
<tr>
<td class="text">Subject 3:</td>
<td class="text"><?php echo $ed_ge['m_3']; ?></td>
</tr>
<tr bgcolor="#F2F2F2">
<td class="text">Subject 4:</td>
<td class="text"><?php echo $ed_ge['m_4']; ?></td>
</tr>
<tr>
<td class="text">Subject 5:</td>
<td class="text"><?php echo $ed_ge['m_5']; ?></td>
</tr>
</table>


<?php include"footer.php"; } ?>