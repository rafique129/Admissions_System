<?php session_start(); ?>
<?php
$c_email="prabakar12@gmail.com";
$c_name="RESORT WEALTH PROMOTERS";

if(isset($_REQUEST['submit']))
{
include("securimage.php");
  $img = new Securimage();
  $valid = $img->check($_POST['code']);

  if($valid == true) {
  
$fname=$_REQUEST['fname'];
$email=$_REQUEST['email'];
$phone=$_REQUEST['phone'];
$quote=$_REQUEST['quote'];

//$ins1="insert into contact (fname,email,phone,query) values ('$fname','$email','$phone','$query')";
//mysql_query($ins1);



$from=$email;

$to=$c_email;
		
		// subject
		$subject = 'Contact Form for '.$c_name;
		$message = '<table cellspacing=0 cellpadding=0>
		<tr>
		<td>
		<p>
		<table cellspacing="0" cellpadding="10">
		<tr>
		<td colspan=2>This is from <b>'.$fname.'<b></td></tr>
	  <tr>
	  <td>Name:</td>
	  <td>'.$fname.'</td>
	  </tr>
	  <tr>
	    <td>Email:</td><td>'.$email.'</span></td>
	    </tr>
	  <tr>
	    <td>Phone:</td><td>'.$phone.'</span></td>
	    </tr>
	  <tr>
	    <td>Comments:</td>
	    <td>'.$quote.'</td>
	    </tr>

	  
	  </table></p>
	  </td></tr></table>';
		
		
		$message1='<table cellspacing=0 cellpadding=0>
		<tr>
		<td>
		<p>
		Hello <b>'.$fname.'</b>,<br><br>
		Thanks for submit this form.<br><br>
		If you have any questions in the future, please contact us at <a href="mailto:'.$c_email.'">'.$c_email.'</a><br><br>
		We are looking forward to providing you with quality information.<br><br><br>
		Regards,<br>
		'.$c_name.' Team<br>
		</p>
		</td></tr></table>';
		
		
		
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html;charset=iso-8859-1' . "\r\n";
		$headers .= 'From: '.$from.' <'.$from.'>' . "\r\n";

		// Mail it
		
		mail($to, $subject, $message, $headers);
		
		
		$header  = 'MIME-Version: 1.0' . "\r\n";
		$header .= 'Content-type: text/html;charset=iso-8859-1' . "\r\n";
		$header .= 'From: '.$to.' <'.$to.'>' . "\r\n";



mail($from, $subject, $message1, $header);
$msg="Thank you for your query. We will contact you shortly.";

$msg1="1";

}
else
{
$msg="Verification code incorrect";
}
}
?>
<script language="javascript">
function validation()
{
var sam=document.form_quote;
 	
	
	if(sam.fname.value=='')
		{
		alert("Please enter your Name");
		sam.fname.focus();
		return false;
		}
	
		if(sam.email.value=="")
			{
			alert("Please enter your E-mail id");
			sam.email.focus();
			return false;
			}
if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(form_quote.email.value))
		{
			//ok;
		}
	else
		{
			alert("Invalid E-mail id! Please re-enter.")
			sam.email.focus();
			return false;
		}


		
		

/////////////////////////////////////////////
if(sam.phone.value=='')
		{
		alert("Please enter phone number");
		sam.phone.focus();
		return false;
		}
if (!/\d{10,}/.test(fname.tphno11.value)) 
//if(fname.tzip.value=='')		
		{
		alert("Please enter 10 digit as a number");
		sam.phone.focus();
		return false;
		}
		
		

 }
 
 </script>


  

	<table cellspacing="0" cellpadding="0" border="0"  width="250" height="408" style="border:1px solid #FF9900;">
	
	<tr>
	  
	  <td>
	  
	  <table cellspacing="0" cellpadding="0" width="250" height="408">
	  <tr>
	  <td class="enquiry" valign="top">
	  	<center><font color="#990000"><?php echo $msg;?></font></center>
	
	</td>
	</tr>
	<?php
	if($msg1=='')
	{
	?>
	<tr>
<td class="enquiry"><img src="images/enquiry_icon.png" title="Enquiry_icon" alt="Enquiry_icon" width="28" height="32" align="absmiddle" />&nbsp;&nbsp;&nbsp;<font color="#447322">Enquiry Form</font></td>
</tr>

	  <form name="form_quote" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>" onSubmit="return validation();">
	  <tr>
	  <td class="enquiry">Name*<br><input type="text" name="fname" value="<?php echo $_REQUEST['fname'];?>" size="30"></td>
	  </tr>
	  <tr>
	    <td class="enquiry">Email*<br><input type="text" name="email" value="<?php echo $_REQUEST['email'];?>" size="30"></td>
	    </tr>
	  <tr>
	    <td class="enquiry">Phone*<br><input type="text" name="phone" value="<?php echo $_REQUEST['phone'];?>"></td>
	    </tr>
	  
	  <tr>
	    <td class="enquiry">Comments<br><textarea name="quote" rows="3" cols="24"><?php echo $_REQUEST['query'];?></textarea></td>
	    </tr>
		<tr>
		<td class="enquiry">Enter Verification Code*<br>
		<img src="securimage_show.php?sid=<?php echo md5(uniqid(time())); ?>" name="siimage" align="absmiddle" id="siimage">
<a tabindex="-1" style="border-style: none" href="securimage_play.php" title="Audible Version of CAPTCHA">
<img src="images/audio_icon.png" alt="Audio Version" width="22" height="22" border="0" align="absmiddle" onClick="this.blur()" /></a>
<a tabindex="-1" style="border-style: none" href="#" title="Refresh Image" onClick="document.getElementById('siimage').src = 'securimage_show.php?sid=' + Math.random(); return false">
<img src="images/refresh.png" alt="Reload Image" width="15" height="18" border="0" align="absmiddle" onClick="this.blur()" /></a>
<br />
<input type="text" name="code" />
</td>
</tr>

	  <tr>
	    <td align="center" height="35">
<input type="hidden" name="submit" />
<input type="image" src="images/submit.png" name="submit" value="submit" /></td>
	    </tr>
		</form>
		<?php
	  }
	  ?>
	  </table>
	  </td>
	  
	  </tr>
		
	</table>
	


