<?php include "include/db.php"; ?><?php if(($_SESSION[$admin_session]=='') and ($_SESSION[$c_session]=='')) { ?><script>window.location.href="website.php";</script><?php } else { ?>

<?php
include "header1.php"; 
$matter=$_REQUEST['matter'];
?>
<?php
if(isset($_REQUEST['act_user']))
{
$act_user=$_REQUEST['act_user'];
$page=$_REQUEST['page'];
$sno=$_REQUEST['sno'];
//mysql_query("update $table4 set active='$act_user' where sno='$sno'");
mysql_query("update $table4 set login_active='$act_user' where sno='$sno'");
/*echo '<script>alert("Status has been Changed");</script>';*/
$matter='Status Has Been Changed Successfully';
}
?>

<?php
if(isset($_REQUEST['user']))
{
$user=$_REQUEST['user'];
$from=$_REQUEST['from'];
$to=$_REQUEST['to'];
$page=$_REQUEST['page'];

mysql_query("delete from $table4 where sno='$user'") or die (mysql_error());
mysql_query("delete from $table8 where user_id='$user'") or die (mysql_error());
mysql_query("delete from $table8 where level_id='$user'") or die (mysql_error());
mysql_query("update $table3 set user_id='deleted'  where user_id='$user'") or die (mysql_error());

$mattered='User Has Been Deleted';
echo '<script>window.location.href="'.$_SERVER['PHP_SELF'].'?from='.$from.'&to='.$to.'&page='.$page.'matter='.$mattered.'";</script>';
}
?>



<?php
$dated_new='2009-01-01';
$from=$_REQUEST['from'];
$to=$_REQUEST['to'];
if($from=='') { $from_time="$dated_new"; $from_date=$dated_new;  } else { $from_time="$from";  $from_date=$from; }
if($to=='') { $to_time="$dated";  $to_date=$dated; } else { $to_time="$to";   $to_date=$to;}
$where_condi1=" and dated>='$from_time' and "; $where_condi2=" dated<='$to_time'"; 
$where_condi_new=$where_condi1.$where_condi2;
?>


<tr>
<td colspan="5" height="5">
<?php
include "dropdown.php"; 
?>
</td>
</tr>
<tr>
  <td colspan="3" valign="top" align="center">

  <table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:0px solid #000000" width="100%">

<tr>

<td colspan="2" align="center">


<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="18"><img src="images/blue_left1.jpg" width="18" height="34" /></td>
<td colspan="2" background="images/blue_center.jpg"><div class="user_head">STUDENTS LIST</div></td>
<td valign="top" align="right" width="18"><img src="images/blue_right1.jpg" width="18" height="34" /></td>
</tr>
</table>

</td>
</tr>

<tr><td colspan="2" align="center"><?php echo $matter; ?></td></tr>


  <?php ob_start(); ?>

<tr>
<td colspan="2" align="center">

<table border="0" align="center" cellpadding="10" bgcolor="#FFFFFF" style="border:1px solid #000000" width="93%">
<tr bgcolor="#FFFFFF">
<td colspan="2" align="center"><strong><font color="#000000">Feedback Report</font></strong></td>
</tr>

<?php $jws_table_name="$feedback_table"; $where_condition=" where fno!='' $where_all  order by fno desc"; $target_from_jws='?page_id='.$page_id.$new_where;$limit = 10; include "pagination_common.php"; ?>

<tr><td colspan="2" align="center"><?php echo $pagination; ?></td></tr>

<?php if ($_REQUEST['added']=='3') { ?><tr><td colspan="2" align="center" class="error"><img src="thumbtack-red.png" /> Product Seeker Status Has Been Changed</td></tr><?php } ?>

<?php /*<tr><td colspan="2" align="center">
<form method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<table width="100%" align="center">
<tr>
<td>Name:</td>
<td><input type="text" name="j_name" value="<?php echo $j_name; ?>" />
<td>Postal Code:</td>
<td><input type="text" name="j_post" value="<?php echo $j_post; ?>" />
<td><select name="active" onchange="this.form.submit()"><option value="">All</option><option value="1"<?php if($active==1) { echo ' selected="selected"'; } ?>>Active</option><option value="2"<?php if($active==2) { echo ' selected="selected"'; } ?>>Pending</option></select></td>
<input type="hidden" name="page_id" value="1" />
<td><input type="submit" name="search" value="Search" /></td>
</tr>
</table>
</form>
</td></tr>*/?>

<tr><td colspan="2" align="center">


<table width="93%" style="border:#967853 solid 1px;" cellpadding="6" cellspacing="0">
<tr>
<td class="titled">Name</td>
<td class="titled">Email</td>
<td class="titled">Comment</td>
</tr>

<?php
//$job=mysql_query("select * from $job_table");while ($traders=mysql_fetch_array($job)) 
while ($traders=mysql_fetch_array($result)) {
?>
<tr>
<td><?php echo str_replace("$j_name","<b>$j_name</b>",$traders[name]); ?></td>
<td><?php echo str_replace($j_post,"<b>$j_post</b>",$traders['email_id']); ?></td>
<td><?php echo str_replace($j_post,"<b>$j_post</b>",$traders['comment']); ?></td>
</tr>
<?php } ?>

</table>


</td></tr>


</table>

</td>
</tr>


<?php $print_value=ob_get_clean(); echo $print_value; ?>

</table>

<br />
<br />

  </td>
</tr>


</table>


<div align="center"><?php $print_value1=str_replace("'","","$print_value"); $print_value2='<table width="100%">'.$print_value1.'</table>'; ?>
<form name="pay_out_details" method="post" action="print.php" target="_blank">
<input type="hidden" name="print" value='<?php echo $print_value2; ?>' />
<input type="submit" name="submit" value="Print"  />
</form>
</div>

<?php
include "footer.php";
?>
<?php } ?>


