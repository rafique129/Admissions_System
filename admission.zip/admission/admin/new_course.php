<?php include "include/db.php";
?>
<?php if($_SESSION[$admin_session]=='') { ?><script>window.location.href="website.php";</script><?php } else { ?>

<script>
	  function show()
	  {
	  var sbkname=document.est_add.name.value;
//	  alert(sbkname);
	  if (sbkname=="add_new")
		{	
		 ssk1.style.display="";
		 ssk.style.display="none";
		} else {
		 ssk1.style.display="none";
		 ssk.style.display="";
		}
	  }
</script>



<?php
if(isset($_REQUEST['add']))
{
$name=$_REQUEST['name'];
$name_1=$_REQUEST['name_1'];
$course=$_REQUEST['course'];
$ip=$_SERVER['REMOTE_ADDR'];
if($name_1=='') { $name=$name; } else { $name=$name_1; }
mysql_query("insert into $table9 (name,course,dated,date_timed,ip) values ('$name','$course','$dated','$date_timed','$ip')");
echo '<script>window.location.href="'.$_SERVER['PHP_SELF'].'?added=1";</script>';
}
?>


<?php 
include "header1.php"; 
?>
<tr>
<td colspan="5" height="5">
<?php
include "dropdown.php"; 
?>
</td>
</tr>
<tr>
  <td colspan="3" valign="top" align="center">
  
  <table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:px solid #000000; width:30%" height="300">

<tr>

<td colspan="2" align="center">

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="18"><img src="images/blue_left1.jpg" width="18" height="34" /></td>
<td colspan="2" background="images/blue_center.jpg"><div class="user_head">Add New Course</div></td>
<td valign="top" align="right" width="18"><img src="images/blue_right1.jpg" width="18" height="34" /></td>
</tr>
</table></td>
</tr>


<tr><td colspan="2" align="center">


<form name="est_add">
<table width="100%" cellpadding="3" cellspacing="3">
<?php if($_REQUEST[added]!='') { echo '<tr><td colspan="2" align="center">New Course Has Been Added</td></tr>'; } ?>
<tr><td>Department:</td><td>
<div id="ssk"><select name="name" onchange="show()"><option value="">--Select--</option><?php $deal_ms=mysql_query("select * from $table9 group by name order by name"); while ($deal_ms_list=mysql_fetch_array($deal_ms)) {?><option value="<?php echo $deal_ms_list[name]; ?>"><?php echo $deal_ms_list[name]; ?></option><?php } ?><option value="add_new">Add New</option></select></div>
<div id="ssk1" style="display:none"><input type="text" name="name_1" /></div>
</td></tr>
<tr><td>Course</td><td><input type="text" name="course" value="" size="12" /></td></tr>

<tr><td colspan="2" align="center"><input type="submit" name="add" value="ADD" /></td></tr>
</table>
</form>


</td></tr>

</table>
  
  
  </td>
</tr>
</table>
<?php
include "footer.php";
?>
<?php } ?>