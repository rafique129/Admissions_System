<?php include "include/db.php"; ?>
<html>
<title><?php echo $_REQUEST['sno']; ?> <?php echo $_REQUEST['title']; ?></title>
<head>
<style>
td { font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; }
</style>
</head>
<body onLoad="window.print();">
<div align="center" style="font-family:Verdana, Arial, Helvetica, sans-serif; padding:3px; font-size:14px; font-weight:bold;">
<?php if ($_REQUEST['sno']!='') { echo $_REQUEST['sno']; echo ' '.kandu_pidi_new($_REQUEST['sno'],$table4,name,sno).' Amount: '.kandu_pidi_new($_REQUEST['sno'],$table4,amount,sno).' '; }echo $_REQUEST['title']; ?>
</div>
<?php
$print1=$_REQUEST['print'];
$print1=str_replace("FFCC00","FEF9F9","$print1");
$print1=str_replace("FFFFFF","000000","$print1");
$print1=str_replace("F0F0F0","FFFFFF","$print1");
$print1=str_replace('\"','"',"$print1");
$print1=str_replace('" />','',"$print1");
echo $print1;
?>
</body>
</html>
