<style>
div.pagination {
	padding: 3px;
	margin: 3px;
}

div.pagination a {
	padding: 2px 5px 2px 5px;
	margin: 2px;
	border: 1px solid #000000;
	text-decoration: none; /* no underline */
	color: #000000;
}
div.pagination a:hover, div.pagination a:active {
	border: 1px solid #000000;

	color: #000;
}
div.pagination span.current {
	padding: 2px 5px 2px 5px;
	margin: 2px;
		border: 1px solid #000000;
		
		font-weight: bold;
		background-color: #000000;
		color: #FFF;
	}
	div.pagination span.disabled {
		padding: 2px 5px 2px 5px;
		margin: 2px;
		border: 1px solid #FFFFFF;
	
		color: #FFFFFF;
	}
</style>
<?php
	$tbl_name="$jws_table_name";
	$adjacents = 3;
	$query = "SELECT COUNT(*) as num FROM $tbl_name $where_condition";
	$total_pages = mysql_fetch_array(mysql_query($query));
	$total_pages = $total_pages[num];
	$targetpage = $target_from_jws; 
	$limit = $limited_value;
	$page = $_GET['page'];
	if($page) 
		$start = ($page - 1) * $limit;
	else
		$start = 0;	
	$sql = "select * from $tbl_name $where_condition LIMIT $start, $limit";
	$result = mysql_query($sql);
	if ($page == 0) $page = 1;	
	$prev = $page - 1;
	$next = $page + 1;
	$lastpage = ceil($total_pages/$limit);
	$lpm1 = $lastpage - 1;					
	$pagination = "";
	if($lastpage > 1)
	{	
		$pagination .= "<div class=\"pagination\">";
		if ($page > 1) 
			$pagination.= "<a title=\"$prevpage of $letter this state\" href=\"$targetpage&page=$prev$link\"> Previous</a>";
		else
			$pagination.= "<span class=\"disabled\"> Previous</span>";	
		
		if ($lastpage < 7 + ($adjacents * 2))
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a title=\"$counter of $letter this state\" href=\"$targetpage&page=$counter$link\">$counter</a>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))
		{
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a title=\"$counter of $letter this state\" href=\"$targetpage&page=$counter$link\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a title=\"$lpm1page of $letter this state\" href=\"$targetpage&page=$lpm1$link\">$lpm1</a>";
				$pagination.= "<a title=\"$lastpagepage of $letter this state\" href=\"$targetpage&page=$lastpage$link\">$lastpage</a>";		
			}
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<a title=\"1page of $letter this state\" href=\"$targetpage&page=1$link\">1</a>";
				$pagination.= "<a title=\"2page of $letter this state\" href=\"$targetpage&page=2$link\">2</a>";
				$pagination.= "...";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a title=\"$counter of $letter this state\" href=\"$targetpage&page=$counter$link\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a title=\"$lpm1page of $letter this state\" href=\"$targetpage&page=$lpm1$link\">$lpm1</a>";
				$pagination.= "<a title=\"$lastpagepage of $letter this state\" href=\"$targetpage&page=$lastpage$link\">$lastpage</a>";		
			}
			else
			{
				$pagination.= "<a title=\"1page of $letter this state\" href=\"$targetpage&page=1$link\">1</a>";
				$pagination.= "<a title=\"2page of $letter this state\" href=\"$targetpage&page=2$link\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a title=\"$counter of $letter this state\" href=\"$targetpage&page=$counter$link\">$counter</a>";					
				}
			}
		}
		if ($page < $counter - 1) 
			$pagination.= "<a title=\"$nextpage of $letter this state\" href=\"$targetpage&page=$next$link\">Next </a>";
		else
			$pagination.= "<span class=\"disabled\">Next </span>";
		$pagination.= "</div>\n";		
	}

/*		while($row = mysql_fetch_array($result))
		{
echo $row['district'];
?>
<br>
<?php
	
		}
*/
//echo $pagination; ?>