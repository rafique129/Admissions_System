<?php include "include/db.php";
?>
<?php if($_SESSION[$admin_session]=='') { ?><script>window.location.href="website.php";</script><?php } else { ?>


<?php
if(isset($_REQUEST['change_sett']))
{
$year_da=$_REQUEST['year_da'];
$month_da=$_REQUEST['month_da'];
$date_da=$_REQUEST['date_da'];

$pay_dated=$year_da.'-'.$month_da.'-'.$date_da;

$amount=$_REQUEST['amount'];
$div_per=$_REQUEST['div_per'];
$lev_per=$_REQUEST['lev_per'];
$spo_per=$_REQUEST['spo_per'];
$per_page=$_REQUEST['per_page'];
//mysql_query("update $table2 set amount='$amount',div_per='$div_per',lev_per='$lev_per',spo_per='$spo_per',per_page='$per_page' where sno='1'") or die (mysql_error());
$update1="update $table1 set pay_dated='$pay_dated' where slno='1'";
mysql_query($update1);
$ok='Settings Has Been Changed Successfully';
}
?>


<?php 
include "header1.php"; 
?>
<tr>
<td colspan="5" height="5">
<?php
include "dropdown.php"; 
?>
</td>
</tr>
<tr>
  <td colspan="3" valign="top" align="center">
  
  <table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:px solid #000000; width:30%" height="300">

<tr>

<td colspan="2" align="center">

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="18"><img src="images/blue_left1.jpg" width="18" height="34" /></td>
<td colspan="2" background="images/blue_center.jpg"><div class="user_head">CHANGE SETTINGS</div></td>
<td valign="top" align="right" width="18"><img src="images/blue_right1.jpg" width="18" height="34" /></td>
</tr>
</table></td>
</tr>

<?php $settings=mysql_fetch_array(mysql_query("select * from $table2 where sno='1'")); //echo date("w"); ?>
<form name="form1" action="<?php $_SERVER['PHP_SELF'];?>" method="post" onSubmit="return validation();">
<tr><td colspan="2" align="center"><?php echo $ok; ?></td></tr>
<tr><td>Active Release Date:</td><td><?php echo date_only(kandu_pidi_new(1,$table1,pay_dated,slno)); ?></td></tr>

<tr><td>Payout Release Date:</td><td><select name="date_da" class="simple_da"><?php for ($h = 01; $h < 32; $h++){ ?><option value="<?php echo "$h"; ?>"<?php if($h==$d){echo $sel;}?>><?php echo $h; ?></option><?php } ?></select>
<select name="month_da" class="simple_da"><?php for ($i = 01; $i < 13; $i++){ ?><option value="<?php echo "$i"; ?>"<?php if($i==$m){echo $sel;}?>><?php echo $i; ?></option><?php } ?></select>
<select name="year_da" class="simple_da"><?php for ($j = 1925; $j < 2014; $j++){ ?><option value="<?php echo "$j"; ?>"<?php $year_da=$y; if($j==$year_da){echo $sel;}?>><?php echo $j; ?></option><?php } ?></select></td></tr>

<tr>
<td colspan="2" align="center"><input type="submit" name="change_sett" value="Change"></td>
</tr>
</form>
</table>
  
  
  </td>
</tr>
</table>
<?php
include "footer.php";
?>
<?php } ?>