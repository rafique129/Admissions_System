<?php include "include/db.php";
?>
<?php if($_SESSION[$admin_session]=='') { ?><script>window.location.href="website.php";</script><?php } else { ?>

<script language="javascript">
function validation()
{
var fname=document.form1;
if(fname.oldpwd.value=='')
{
alert("Please type old password")
fname.oldpwd.focus();
return false;
}

if(fname.newpwd.value=='')
{
alert("Please type newpassword");
fname.newpwd.focus();
return false;
}


if(fname.newpwd.value!=fname.repwd.value)
{
alert("Retype password is wrong");
fname.repwd.focus();
return false;
}


}
</script>
<?php
if(isset($_REQUEST['change']))
{
$oldpwd=$_REQUEST['oldpwd'];
$newpwd=$_REQUEST['newpwd'];

$aa1="select * from $table1";
$bb1=mysql_query($aa1);
$cc1=mysql_fetch_array($bb1);
$dd1=$cc1['password'];

if($oldpwd==$dd1)
{

$update1="update $table1 set password='$newpwd' where password='$oldpwd'";
$update2=mysql_query($update1);
$msg="Password changed";
?>
<script>
alert("Your password successfully changed. Click ok and login again");
window.location.href="logout.php";
</script>
<?php

}
else
{
$msg="Old password is wrong";
}



}
?>

<?php 
include "header1.php"; 
?>
<tr>
<td colspan="5" height="5">
<?php
include "dropdown.php"; 
?>
</td>
</tr>
<tr>
  <td colspan="3" valign="top" align="center">
  
  <table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:0px solid #000000" height="200">

<tr bgcolor="#FFFFFF">

<td colspan="2" align="center">

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="18"><img src="images/blue_left1.jpg" width="18" height="34" /></td>
<td colspan="2" background="images/blue_center.jpg"><div class="user_head">CHANGE PASSWORD</div></td>
<td valign="top" align="right" width="18"><img src="images/blue_right1.jpg" width="18" height="34" /></td>
</tr>
</table>
</td>
</tr>
<form name="form1" action="<?php $_SERVER['PHP_SELF'];?>" method="post" onSubmit="return validation();">
<tr>
<td>Old Password</td><td><input type="password" name="oldpwd"></td>
</tr>
<tr bgcolor="#F0F0F0">
<td>New Password</td><td><input type="password" name="newpwd"></td>
</tr>
<tr>
<td>Retype Password</td><td><input type="password" name="repwd"></td>
</tr>
<td colspan="2" align="center"><input type="submit" name="change" value="Change"></td>
</tr>
</form>
</table>
  
  
  </td>
</tr>
</table>
<?php
include "footer.php";
?>
<?php } ?>