<?php session_start();
include "../include/db.php";
$admin_session='admin_side_main_sess';
$c_session='admin_side_council_sess';
$sel=' selected="selected"';
?>