<table cellpadding="0" cellspacing="0" border="0" class="text">
<?php
//if ($_REQUEST['tree_view_concept_id']=='') { $tree_view_concept_id=$main_sno; } else { $tree_view_concept_id=$_REQUEST['tree_view_concept_id']; }
$prabakar_different_concept_amount=''; 
$prabakar_different_concept=mysql_query("select * from $table4 where refer_id='$prabakar_tree_view_concept_id'");	
$prabakar_different_concept_counting_value=mysql_num_rows($prabakar_different_concept);
/*?>
<tr><td colspan="<?php echo $prabakar_different_concept_counting_value; ?>" align="center">
<div style="border:#000000 solid 0px; color:#000000; padding:10px;">
<img src="admin/images/trees003.gif" width="50" height="52" /><br /><?php $prabakar_tree_view_concept_id; echo kandu_pidi_new($prabakar_tree_view_concept_id,$table4,name,sno); echo ' ('.$prabakar_tree_view_concept_id.') '; ?></div></td></tr>*/?>
<?php if ($prabakar_different_concept_counting_value!='0') { ?>

<tr><td valign="top" colspan="<?php echo $prabakar_different_concept_counting_value; ?>" align="center" style="padding-top:12px;"><img src="admin/images/tree/tree.jpg" /></td></tr>

<?php if($prabakar_different_concept_counting_value!='1') { ?>
<tr><td colspan="<?php echo $prabakar_different_concept_counting_value; ?>" align="center" style="height:2px; padding-left:8px; padding-right:8px;"><div style="background-image:url(admin/images/tree/tree1.jpg); height:1px;"></div></td></tr>
<?php } ?>

<tr>
<?php /*$prabakar_different_concepta_count=mysql_num_rows($prabakar_different_concept); $prabakar_different_concepta_commission='0';*/
$prabakar_i=0;
while ($prabakar_different_concepta=mysql_fetch_array($prabakar_different_concept))	
{
$prabakar_i++;
$prabakar_different_concepta_user_id=$prabakar_different_concepta['sno']; ?>
<td onClick="window.location.href='?tree_view_concept_id=<?php echo $prabakar_different_concepta_user_id; ?>';" align="<?php if($prabakar_different_concept_counting_value=='1') { echo 'center'; } else if ($prabakar_i=='1') { echo 'left'; } else if ($prabakar_i==$prabakar_different_concept_counting_value) { echo 'right'; } else echo 'center'; ?>" style="padding-left:8px; padding-right:8px; cursor:pointer;"><img src="admin/images/tree/tree.jpg" /><div style="border:#000000 solid 1px; padding:8px; text-align:center; color:#000000; font-size:9px; font-weight:normal;"><img src="admin/images/trees003.gif" width="50" height="52" onMouseover="fixedtooltip('<?php echo $prabakar_different_concepta_user_id; ?><br /><?php echo kandu_pidi_new($prabakar_different_concepta_user_id,$table4,name,sno); echo '<br />'; echo date_only(kandu_pidi_new($prabakar_different_concepta_user_id,$table4,dated,sno)); ?>', this, event, '100px')" onMouseout="delayhidetip()" /><br /><?php /*echo $prabakar_different_concepta_user_id; echo ', '; */ echo kandu_pidi_new($prabakar_different_concepta_user_id,$table4,name,sno); echo ' ('.$prabakar_different_concepta_user_id.') ';//name_display($prabakar_different_concepta_user_id,$prabakar_jws_b3table)); ?> <?php echo $prabakar_different_concepta['side']; ?></div></td>
<?php } ?>
</tr><?php } ?>
<?php if($prabakar__REQUEST['tree_view_concept_id']!='') { ?>
<tr><td colspan="<?php echo $prabakar_different_concept_counting_value; ?>" align="center" style="padding-top:12px;"><INPUT TYPE="button" VALUE="Back" onClick="history.go(-1);"></td></tr>
<?php } ?>
</table>