<?php include "include/db.php"; ?> <?php if(($_SESSION[$admin_session]=='') and ($_SESSION[$c_session]=='')) { ?><script>window.location.href="website.php";</script><?php } else { ?>

<?php
include "header1.php"; $sno=$_REQUEST['sno']; 
?>
<?php
if(isset($_REQUEST['edit_user']))
{
$sno=$_REQUEST['sno'];
$name=$_REQUEST['name'];
$password=$_REQUEST['password'];
$email=$_REQUEST['email'];

$pan_number=$_REQUEST[pan_number];
$dep_cour=$_REQUEST[dep_cour];
$department=kandu_pidi_new($dep_cour,$table9,name,sno);
$course=kandu_pidi_new($dep_cour,$table9,course,sno);


$year_da=$_REQUEST['year_da'];
$month_da=$_REQUEST['month_da'];
$date_da=$_REQUEST['date_da'];

$dob=$year_da.'-'.$month_da.'-'.$date_da;

//$dob=$_REQUEST['dob'];

$sex=$_REQUEST['sex'];
$addr1=$_REQUEST['addr1'];
$addr2=$_REQUEST['addr2'];
$city=$_REQUEST['city'];
$state=$_REQUEST['state'];
$country=$_REQUEST['country'];
$post_code=$_REQUEST['post_code'];
$mnumber=$_REQUEST['mnumber'];
$tnumber=$_REQUEST['tnumber'];
$nominee=$_REQUEST['nominee'];
$rnominee=$_REQUEST['rnominee'];
$pan_number=$_REQUEST['pan_number'];
$acc_no=$_REQUEST['acc_no'];
$acc_na=$_REQUEST['acc_na'];
$acc_ba=$_REQUEST['acc_ba'];
$acc_br=$_REQUEST['acc_br'];
$acc_ty=$_REQUEST['acc_ty'];
$acc_if=$_REQUEST['acc_if'];

$fran=$_REQUEST['fran'];

$dated1=explode("-",$_REQUEST['dated']);
$dated=$dated1[2]."-".$dated1[1]."-".$dated1[0];
$datetimed=$dated." ".$time;

$status=$_REQUEST['status'];
$comments=$_REQUEST['comments'];
$m_1 = $_REQUEST['m_1'];
$m_2 = $_REQUEST['m_2'];
$m_3 = $_REQUEST['m_3'];
$m_4 = $_REQUEST['m_4'];
$m_5 = $_REQUEST['m_5'];


mysql_query("update $table4 set dated='$dated',datetimed='$datetimed',name='$name',password='$password',dob='$dob',sex='$sex',addr1='$addr1',addr2='$addr2',city='$city',state='$state',country='$country',post_code='$post_code',mnumber='$mnumber',tnumber='$tnumber',nominee='$nominee',rnominee='$rnominee',pan_number='$pan_number',acc_no='$acc_no',acc_na='$acc_na',acc_ba='$acc_ba',acc_br='$acc_br',acc_ty='$acc_ty',acc_if='$acc_if',department='$department',course='$course',email='$email',status='$status',comments='$comments', m_1=$m_1, m_2=$m_2, m_3=$m_3, m_4=$m_4, m_5=$m_5 where sno='$sno'") or die (mysql_error());
echo '<script>window.location.href="user_view.php?sno='.$sno.'";</script>';
}
/*
echo str_replace("- ","",$datetime);
echo '<br />';
echo time();
*/
?>


<tr>
<td colspan="5" height="5">
<?php
include "dropdown.php"; 
?>
<?php 
function date_fun($date_change) 
{  
$date_changed=date("d-m-Y",strtotime($date_change));  
echo $date_changed; 
}
?>

</td>
</tr>
<tr>
  <td colspan="3" valign="top" align="center">
  
  <table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:0px solid #000000" width="450">

<tr bgcolor="#666666">

<td colspan="2" align="center">

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="18"><img src="images/blue_left1.jpg" width="18" height="34" /></td>
<td colspan="2" background="images/blue_center.jpg"><div class="user_head">EDIT STUDENT DETAILS PAGE</div></td>
<td valign="top" align="right" width="18"><img src="images/blue_right1.jpg" width="18" height="34" /></td>
</tr>
</table>

</td>
</tr>

<tr>
<td colspan="2" align="center">
<table width="95%" cellpadding="3" cellspacing="3" align="center">
<form method="post">
<tr>
<td>User:</td>
<td>
<select name="sno" onchange="this.form.submit();">
<option value="">--Select--</option>
<?php $select_group_id=mysql_query("select * from $table4"); while ($select_group_id_array=mysql_fetch_array($select_group_id)) { ?>
<option value="<?php echo $select_group_id_array['sno']; ?>" <?php if ($select_group_id_array['sno']==$sno) { echo ' selected="selected"'; } ?>><?php echo new_number($select_group_id_array['sno'],$table4);//echo $select_group_id_array[months].$select_group_id_array[sno];
/* ?>, <?php echo $select_group_id_array[name]; */?></option>
<?php } ?>
</select>
</td>
</tr>
</form>

<?php if($sno!='') { ?>
<form name="user_edit" action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" onSubmit="return user_e_validation();">
<?php $user_edit=mysql_fetch_array(mysql_query("select * from $table4 where sno='$sno'")); ?>
<input type="hidden" name="sno" value="<?php echo $sno; ?>" />

<?php if ($_REQUEST['added']!='') { ?><tr><td colspan="2" align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><strong>Your Link Has Been Added</strong></font></td></tr><?php } ?>
<?php if ($_REQUEST['refer_error']!='') { ?><tr><td colspan="2" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFCC00"><strong><?php echo $refer_error; ?></strong></font></td></tr><?php } ?>

<tr><td colspan="2" style="font-weight:bold;" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><strong>PERSONAL DETAILS</strong></font></td></tr>
<tr><td>Username*:</td><td><input type="text" name="email" class="small" value="<?php echo $user_edit['email']; ?>" /></td></tr>
<!--<tr><td>Secret Question:</td><td><input type="text" name="quiz" class="small" /></td></tr>
<tr><td>Answer:</td><td><input type="text" name="answ" class="small" /></td></tr>-->

<?php /*<tr bgcolor="#F0F0F0"><td>Date:</td><td><input type="text" name="dated" class="small" value="<?php echo date_fun($user_edit['dated']); ?>" /></td></tr>*/?><input type="hidden" name="dated" class="small" value="<?php echo date_fun($user_edit['dated']); ?>" />
<tr bgcolor="#F0F0F0"><td>Name*:</td><td><input type="text" name="name" class="small" value="<?php echo $user_edit['name']; ?>" /></td></tr>
<!--<tr><td>Maiden Name*:</td><td><input type="text" name="mname" class="small" value="<?php echo $user_edit['mname']; ?>" /></td></tr>-->
<tr><td>Password*:</td><td><input type="text" name="password" class="small" value="<?php echo $user_edit['password']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td>Confirm Password*:</td><td><input type="text" name="password1" class="small" value="<?php echo $user_edit['password']; ?>" /></td></tr>
<tr><td>Date of Birth*:</td><td><!--<script>DateInput('dob', true, 'YYYY-MM-DD','<?php echo $user_edit['dob']; ?>')</script>-->
<?php $piri=explode("-",$user_edit['dob']); $year_da=$piri[0];$month_da=$piri[1];$date_da=$piri[2]; ?>
<select name="date_da" class="simple_da"><?php for ($h = 01; $h < 32; $h++){ ?><option value="<?php echo "$h"; ?>"<?php if($h==$date_da){echo $sel;}?>><?php echo $h; ?></option><?php } ?></select>
<select name="month_da" class="simple_da"><?php for ($i = 01; $i < 13; $i++){ ?><option value="<?php echo "$i"; ?>"<?php if($i==$month_da){echo $sel;}?>><?php echo $i; ?></option><?php } ?></select>
<select name="year_da" class="simple_da"><?php for ($j = 1925; $j < 2012; $j++){ ?><option value="<?php echo "$j"; ?>"<?php if($j==$year_da){echo $sel;}?>><?php echo $j; ?></option><?php } ?></select>
</td></tr>
<tr bgcolor="#F0F0F0"><td>Gender:</td><td><input type="radio" name="sex" value="male" <?php if($user_edit['sex']=='male') { echo $checked_value; } ?> />Male,&nbsp;&nbsp;&nbsp;<input type="radio" name="sex" value="female" <?php if($user_edit['sex']=='female') { echo $checked_value; } ?> />Female</td></tr>
<tr><td>Address First Line*:</td><td><input type="text" name="addr1" class="small" value="<?php echo $user_edit['addr1']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td>Address Second Line:</td><td><input type="text" name="addr2" class="small" value="<?php echo $user_edit['addr2']; ?>" /></td></tr>
<tr><td>City*:</td><td><input type="text" name="city" class="small" value="<?php echo $user_edit['city']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td>State*:</td><td><input type="text" name="state" class="small" value="<?php echo $user_edit['state']; ?>" /></td></tr>
<tr><td>Country*:</td><td><input type="text" name="country" class="small" value="<?php echo $user_edit['country']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td>Postal Code*:</td><td><input type="text" name="post_code" class="small" value="<?php echo $user_edit['post_code']; ?>" /></td></tr>
<tr><td>Mobile Number*:</td><td><input type="text" name="mnumber" class="small" value="<?php echo $user_edit['mnumber']; ?>" /></td></tr>

<tr bgcolor="#F0F0F0"><td>Passport Number*:</td><td><input type="text" name="pan_number" class="small" value="<?php echo $user_edit['pan_number']; ?>" /></td></tr>
<tr><td>Course*:</td><td><select name="dep_cour"><?php $deal_ms=mysql_query("select * from $table9 order by name"); while ($deal_ms_list=mysql_fetch_array($deal_ms)) {?><option value="<?php echo $deal_ms_list[sno]; ?>"<?php if($deal_ms_list[name]==$user_edit['dep_cour']) echo ' selected="selected"';?>><?php echo $deal_ms_list[name]; ?>--><?php echo $deal_ms_list[course]; ?></option><?php } ?></select></td></tr>


<tr bgcolor="#F0F0F0"><td colspan="2" style="font-weight:bold;" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><strong>MARK DETAILS </strong></font></td></tr>

<tr><td>Maths*:</td><td><input type="text" name="m_1" class="small" value="<?php echo $user_edit['m_1']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td>English*:</td><td><input type="text" name="m_2" class="small" value="<?php echo $user_edit['m_2']; ?>" /></td></tr>
<tr><td>Subject 3:</td><td><input type="text" name="m_3" class="small" value="<?php echo $user_edit['m_3']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td>Subject 4:</td><td><input type="text" name="m_4" class="small" value="<?php echo $user_edit['m_4']; ?>" /></td></tr>
<tr><td>Subject 5:</td><td><input type="text" name="m_5" class="small" value="<?php echo $user_edit['m_5']; ?>" /></td></tr>

<?php if(($_SESSION[$admin_session]=='')){?>
<input type="hidden" name="comments" value="<?php echo $user_edit['comments']; ?>" />
<tr><td>Comments:</td><td><textarea name="comments"><?php echo $user_edit['comments']; ?></textarea></td></tr>
<?php }else{?>
<tr bgcolor="#F0F0F0"><td>Status:</td><td><input type="text" name="status" class="small" value="<?php echo $user_edit['status']; ?>" /></td></tr>
<input type="hidden" name="comments" value="<?php echo $user_edit['comments']; ?>" />


<?php }?>
<tr><td colspan="2" align="center"><input type="submit" name="edit_user" value="Update"></td></tr>
</form>
<?php } ?>
</table>



</td>
</tr>

</table>
  
<br />
<br />

  </td>
</tr>
</table>




<?php
include "footer.php";
?>
<?php } ?>


<script language="javascript">	function user_e_validation()	{	var nice=document.user_edit;
if(nice.name.value=='')	{	alert("Enter Name");	nice.name.focus();	return false;	}
if(nice.password.value=='')	{	alert("Enter Password");	nice.password.focus();	return false;	}
if(nice.password.value!=nice.password1.value)	{	alert("Confirm Password must be equal Password");	nice.password.focus();	return false;	}
if(nice.addr1.value=='')	{	alert("Enter Address");	nice.addr1.focus();	return false;	}
if(nice.city.value=='')	{	alert("Enter City");	nice.city.focus();	return false;	}
if(nice.state.value=='')	{	alert("Enter State");	nice.state.focus();	return false;	}
if(nice.country.value=='')	{	alert("Enter Country");	nice.country.focus();	return false;	}
if(nice.post_code.value=='')	{	alert("Enter Postal Code");	nice.post_code.focus();	return false;	}
if(nice.mnumber.value=='')	{	alert("Enter Mobile Number");	nice.mnumber.focus();	return false;	}
if(nice.nominee.value=='')	{	alert("Enter Nominee");	nice.nominee.focus();	return false;	}
if(nice.rnominee.value=='')	{	alert("Enter Nominee Relationship");	nice.rnominee.focus();	return false;	}
/*
if(nice.acc_no.value=='')	{	alert("Enter Account Number");	nice.acc_no.focus();	return false;	}
if(nice.acc_na.value=='')	{	alert("Enter Account Name");	nice.acc_na.focus();	return false;	}
if(nice.acc_ba.value=='')	{	alert("Enter Bank Name");	nice.acc_ba.focus();	return false;	}
if(nice.acc_br.value=='')	{	alert("Enter Bank Branch Name");	nice.acc_br.focus();	return false;	}
if(nice.acc_ty.value=='')	{	alert("Enter Account Type");	nice.acc_ty.focus();	return false;	}
*/
if(nice.refer_id.value=='')	{	alert("Enter Refer ID");	nice.refer_id.focus();	return false;	}
if(nice.sponsor_id.value=='')	{	alert("Enter Sponsor ID");	nice.sponsor_id.focus();	return false;	}
if(nice.method.value=='')	{	alert("Select User Method");	nice.method.focus();	return false;	}
if(nice.m_1.value=='')	{	alert("Enter Maths Mark");	nice.m_1.focus();	return false;	}
if(nice.m_2.value=='')	{	alert("Enter English Mark");	nice.m_2.focus();	return false;	}
}	</script>