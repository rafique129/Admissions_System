<?php include "include/db.php"; ?><?php if(($_SESSION[$admin_session]=='') and ($_SESSION[$c_session]=='')) { ?><script>window.location.href="website.php";</script><?php } else { ?>

<?php
include "header1.php"; 
$matter=$_REQUEST['matter'];
?>
<?php
if(isset($_REQUEST['act_user']))
{
$act_user=$_REQUEST['act_user'];
$page=$_REQUEST['page'];
$sno=$_REQUEST['sno'];
//mysql_query("update $table4 set active='$act_user' where sno='$sno'");
mysql_query("update $table4 set login_active='$act_user' where sno='$sno'");
/*echo '<script>alert("Status has been Changed");</script>';*/
$matter='Status Has Been Changed Successfully';
}
?>

<?php
if(isset($_REQUEST['user']))
{
$user=$_REQUEST['user'];
$from=$_REQUEST['from'];
$to=$_REQUEST['to'];
$page=$_REQUEST['page'];

mysql_query("delete from $table4 where sno='$user'") or die (mysql_error());
mysql_query("delete from $table8 where user_id='$user'") or die (mysql_error());
mysql_query("delete from $table8 where level_id='$user'") or die (mysql_error());
mysql_query("update $table3 set user_id='deleted'  where user_id='$user'") or die (mysql_error());

$mattered='User Has Been Deleted';
echo '<script>window.location.href="'.$_SERVER['PHP_SELF'].'?from='.$from.'&to='.$to.'&page='.$page.'matter='.$mattered.'";</script>';
}
?>



<?php
$dated_new='2009-01-01';
$from=$_REQUEST['from'];
$to=$_REQUEST['to'];
if($from=='') { $from_time="$dated_new"; $from_date=$dated_new;  } else { $from_time="$from";  $from_date=$from; }
if($to=='') { $to_time="$dated";  $to_date=$dated; } else { $to_time="$to";   $to_date=$to;}
$where_condi1=" and dated>='$from_time' and "; $where_condi2=" dated<='$to_time'"; 
$where_condi_new=$where_condi1.$where_condi2;
?>


<tr>
<td colspan="5" height="5">
<?php
include "dropdown.php"; 
?>
</td>
</tr>
<tr>
  <td colspan="3" valign="top" align="center">

  <table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:0px solid #000000" width="100%">

<tr>

<td colspan="2" align="center">


<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="18"><img src="images/blue_left1.jpg" width="18" height="34" /></td>
<td colspan="2" background="images/blue_center.jpg"><div class="user_head">STUDENTS LIST</div></td>
<td valign="top" align="right" width="18"><img src="images/blue_right1.jpg" width="18" height="34" /></td>
</tr>
</table>

</td>
</tr>

<tr><td colspan="2" align="center"><?php echo $matter; ?></td></tr>

<tr><td colspan="2" align="center">
<form method="post">
<table width="75%">
<input type="hidden" name="page" value="<?php echo $page; ?>" />
<tr>
<td>From:</td><td><script>DateInput('from', true, 'YYYY-MM-DD','<?php echo $from_date; ?>')</script></td>
<td>To:</td><td><script>DateInput('to', true, 'YYYY-MM-DD','<?php echo $to_date; ?>')</script></td>
<td><input type="submit" name="sub" value="Submit" /></td>
</tr>
</table>
</form>
</td></tr>


  <?php ob_start(); ?>

<?php $first_value=''; $jws_table_name=$table4; $where_condition="where sno!='' $where_condi_new order by sno desc "; $target_from_jws=$_SERVER['PHP_SELF'].'?from='.$from.'&to='.$to;//$limit_per_page_jws='10'; ?>
<tr><td colspan="2" align="center"><?php include "pagination_common.php";echo $pagination ?></td></tr>

<tr>
<td colspan="2" align="center">

<table width="99%" align="center" cellpadding="2" cellspacing="0">
<tr>
<td><strong>IDS</strong></td>
<td><strong>Username</strong></td>
<td><strong>Passwords</strong></td>
<?php /*<td><strong>Name</strong></td>*/?>
<td><strong>Date</strong></td>
<td><strong>Department</strong></td>
<td><strong>Course</strong></td>
<td><strong>Status</strong></td>
<td><strong>Change</strong></td>
<td><strong>Action</strong></td>
<?php /*<td><strong>Delete</strong></td>*/?>
</tr>

<?php //$user_list=mysql_query("select * from $table4 where active='1'"); while ($user_list_new=mysql_fetch_array($user_list)){
while ($user_list_new=mysql_fetch_array($result)){
$pdc='';if (($user_list_new['fran']!='')) { $pdc=' style="background:#CCCCCC;"'; $pdc1=' title="PDC"'; }
?>
<tr <?php //echo $pdc; echo $pdc1; ?>>
<td><!--<a href="user_tree_view.php?tree_view1=<?php echo $user_list_new['uniq_ids']; ?>" style="color:#000000;"><?php echo $user_list_new['sno']; ?></a>--><?php echo new_number($user_list_new['sno'],$table4); //echo $user_list_new[months].$user_list_new['sno'].new_con($user_list_new['sno']); ?></td>
<td><?php echo $user_list_new['email']; ?></td>
<td><!--<a target="_blank" href="../downlines.php?admin_uniq_ids=<?php echo $user_list_new['uniq_ids']; ?>&admin_sno=<?php echo $user_list_new['sno']; ?>" style="color:#000000;"><?php echo $user_list_new['password']; ?></a>--><?php echo $user_list_new['password']; ?></td>
<?php /*<td><!--<a target="_blank" href="../earning_history.php?admin_uniq_ids=<?php echo $user_list_new['uniq_ids']; ?>&admin_sno=<?php echo $user_list_new['sno']; ?>" style="color:#000000;"><?php echo $user_list_new['name']; if ($user_list_new['pay_method']=='paypal') { echo ' (Paypal)'; } ?></a>--><?php echo $user_list_new['name']; ?></td>*/?>
<td><?php echo date_with_day($user_list_new['dated']); ?></td>
<td><?php echo $user_list_new['department'];?></td>
<td><?php echo $user_list_new['course'];?></td>
<td><?php if ($user_list_new['login_active']=='0') { echo 'Pending'; $active='1'; $activate_word='Activate';} if ($user_list_new['login_active']=='1') { echo 'Live';  $active='0';$activate_word='Deactivate';} ?></td>
<td><a style="color:#000000;" href="<?php echo $_SERVER['PHP_SELF']; ?>?act_user=<?php echo $active; ?>&sno=<?php echo $user_list_new['sno']; ?>&page=<?php echo $page; ?>&from=<?php echo $from; ?>&to=<?php echo $to; ?>"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><?php echo $activate_word ?></font></a></td>
<td>
<a href="user_view.php?sno=<?php echo $user_list_new['sno']; ?>"><img src="include/images/view.png" alt="View" border="0" /></a>
<a href="user_edit.php?sno=<?php echo $user_list_new['sno']; ?>"><img src="include/images/edit.png" alt="Edit" border="0" /></a>
<!--<a href="<?php echo $_SERVER['PHP_SELF']; ?>?pro_id=<?php echo $pro_list_array['sno']; ?>&page=delete&delete1=1&active=0&pages=<?php echo $pages; ?>" onClick="return (confirm('Do you really want to delete the Product?'))";><img src="include/images/delete-icon.png" alt="Delete" border="0" /></a>-->
</td>
<?php /*<td><a href="<?php echo $_SERVER['PHP_SELF'].'?user='.$user_list_new['sno']; ?>&from=<?php echo $from; ?>&to=<?php echo $to; ?>&page=<?php echo $page; ?>" onClick="return (confirm('Do you really want to delete the User?'))" style="color:#000000;">Delete</a></td>*/?>
</tr>
<?php } ?>
</table>

</td>
</tr>


<?php $print_value=ob_get_clean(); echo $print_value; ?>

</table>

<br />
<br />

  </td>
</tr>


</table>


<div align="center"><?php $print_value1=str_replace("'","","$print_value"); $print_value2='<table width="100%">'.$print_value1.'</table>'; ?>
<form name="pay_out_details" method="post" action="print.php" target="_blank">
<input type="hidden" name="print" value='<?php echo $print_value2; ?>' />
<input type="submit" name="submit" value="Print"  />
</form>
</div>

<?php
include "footer.php";
?>
<?php } ?>


