<?php include "include/db.php"; ?> <?php if($_SESSION[$admin_session]=='') { ?><script>window.location.href="website.php";</script><?php } else { ?>
<?php
include "header1.php"; 
$matter=$_REQUEST['matter'];
?>



<?php
$dated_new='2009-01-01';
$from=$_REQUEST['from'];
$to=$_REQUEST['to'];
$name=$_REQUEST['name'];
if($from=='') { $from_time="$dated_new"; $from_date=$dated_new;  } else { $from_time="$from";  $from_date=$from; }
if($to=='') { $to_time="$dated";  $to_date=$dated; } else { $to_time="$to";   $to_date=$to;}
if($name=='') { } else { $new_condi=" and name='$name'";}
$where_condi1=" and dated>='$from_time' and "; $where_condi2=" dated<='$to_time'"; 
$where_condi_new=$where_condi1.$where_condi2;
$where_condi_new=$new_condi;
?>


<tr>
<td colspan="5" height="5">
<?php
include "dropdown.php"; 
?>
</td>
</tr>
<tr>
  <td colspan="3" valign="top" align="center">

  <table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:0px solid #000000" width="56%">

<tr>

<td colspan="2" align="center">


<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="18"><img src="images/blue_left1.jpg" width="18" height="34" /></td>
<td colspan="2" background="images/blue_center.jpg"><div class="user_head">COURSE LIST</div></td>
<td valign="top" align="right" width="18"><img src="images/blue_right1.jpg" width="18" height="34" /></td>
</tr>
</table>

</td>
</tr>

<tr><td colspan="2" align="center"><?php echo $matter; ?></td></tr>

<tr><td colspan="2" align="center">
<form method="post">
<table width="57%">
<input type="hidden" name="page" value="<?php echo $page; ?>" />
<tr>
<td>Department:</td><td><select name="name" onchange="this.form.submit();"><option value="">--All--</option><?php $deal_ms=mysql_query("select * from $table9 group by name order by name"); while ($deal_ms_list=mysql_fetch_array($deal_ms)) {?><option value="<?php echo $deal_ms_list[name]; ?>" <?php if($deal_ms_lis[name]==$name){echo ' selected="selected"';} ?>><?php echo $deal_ms_list[name]; ?></option><?php } ?></select></td>
<td><input type="submit" name="sub" value="Submit" /></td>
</tr>
</table>
</form>
</td></tr>


  <?php ob_start(); ?>

<?php $first_value=''; $jws_table_name=$table9; $where_condition="where sno!='' $where_condi_new order by name"; $target_from_jws=$_SERVER['PHP_SELF'].'?from='.$from.'&to='.$to;//$limit_per_page_jws='10'; ?>
<tr><td colspan="2" align="center"><?php include "pagination_common.php";echo $pagination ?></td></tr>

<tr>
<td colspan="2" align="center">

<table width="99%" align="center" cellpadding="2" cellspacing="0">
<tr>
<td><strong>Department</strong></td>
<td><strong>Course</strong></td>
<td><strong>View</strong></td>
<td><strong>Edit</strong></td>
</tr>

<?php //$user_list=mysql_query("select * from $table4 where active='1'"); while ($user_list_new=mysql_fetch_array($user_list)){
while ($user_list_new=mysql_fetch_array($result)){
$pdc='';if (($user_list_new['fran']!='')) { $pdc=' style="background:#CCCCCC;"'; $pdc1=' title="PDC"'; }
?>
<tr <?php //echo $pdc; echo $pdc1; ?>>
<td><?php echo $user_list_new['name'];?></td>
<td><?php echo $user_list_new['course'];?></td>
<td><a style="color:#000000;" href="course_view.php?sno=<?php echo $user_list_new['sno']; ?>">View</a></td>
<td><a style="color:#000000;" href="course_edit.php?sno=<?php echo $user_list_new['sno']; ?>">Edit</a></td>
</tr>
<?php } ?>
</table>

</td>
</tr>


<?php $print_value=ob_get_clean(); echo $print_value; ?>

</table>

<br />
<br />

  </td>
</tr>


</table>


<div align="center"><?php $print_value1=str_replace("'","","$print_value"); $print_value2='<table width="100%">'.$print_value1.'</table>'; ?>
<form name="pay_out_details" method="post" action="print.php" target="_blank">
<input type="hidden" name="print" value='<?php echo $print_value2; ?>' />
<input type="submit" name="submit" value="Print"  />
</form>
</div>

<?php
include "footer.php";
?>
<?php } ?>


