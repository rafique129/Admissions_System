<?php include "include/db.php";
?>
<?php if($_SESSION[$admin_session]=='') { ?><script>window.location.href="website.php";</script><?php } else { ?>

<?php
$edit_id=$_REQUEST['edit_id'];
$view_id=$_REQUEST['view_id'];
if (($edit_id=='') and ($view_id=='')) { $width='60'; $heading='Latest News List'; } else { $width='50'; }
if ($edit_id!='') { $heading='Edit Latest News'; }
if ($view_id!='') { $heading='View Latest News'; }
?>
<?php if (isset($_REQUEST['act_user'])) { $page=$_REQUEST['page']; $sno=$_REQUEST['sno']; $active=$_REQUEST['act_user']; mysql_query("update $table6 set active='$active' where sno='$sno'"); echo $loading_code; ?><script>window.location.href="<?php echo $_SERVER['PHP_SELF']; ?>?added=3&page=<?php echo $page; ?>";</script> <?php } ?>
<?php if (isset($_REQUEST['del_user'])) { $page=$_REQUEST['page']; $sno=$_REQUEST['sno']; mysql_query("delete from $table6 where sno='$sno'"); echo $loading_code; ?> <script>window.location.href="<?php echo $_SERVER['PHP_SELF']; ?>?added=2&page=<?php echo $page; ?>";</script> <?php } ?>
<?php if (isset($_REQUEST['edit_user'])) {
$title=$_REQUEST['title'];
$content=$_REQUEST['content'];
$sno=$_REQUEST['sno'];
mysql_query("update $table6 set title='$title',content='$content' where sno='$sno'") or die (mysql_error()); echo $loading_code; ?> <script>window.location.href="<?php echo $_SERVER['PHP_SELF']; ?>?added=1&page=<?php echo $page; ?>";</script> <?php } ?>

<?php 
include "header1.php"; 
?>
<tr>
<td colspan="5" height="5">
<?php
include "dropdown.php"; 
?>
</td>
</tr>
<tr>
  <td colspan="3" valign="top" align="center">
  
  <table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:px solid #000000;" width="85%">

<tr bgcolor="#">

<td colspan="2" align="center">

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="18"><img src="images/blue_left1.jpg" width="18" height="34" /></td>
<td colspan="2" background="images/blue_center.jpg"><div class="user_head">EDIT ANNOUNCEMENTS</div></td>
<td valign="top" align="right" width="18"><img src="images/blue_right1.jpg" width="18" height="34" /></td>
</tr>
</table>

</td>
</tr>



<tr><td colspan="2" align="center">
<table border="0" align="center" cellpadding="10" width="100%">

<?php if ($_REQUEST['added']=='1') { ?><tr><td colspan="2" align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#000000"><strong>User Information Has Been Updated</strong></font></td></tr><?php } ?>
<?php if ($_REQUEST['added']=='2') { ?><tr><td colspan="2" align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#000000"><strong>User Has Been Deleted</strong></font></td></tr><?php } ?>
<?php if ($_REQUEST['added']=='3') { ?><tr><td colspan="2" align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#000000"><strong>User Status Has Been Changed</strong></font></td></tr><?php } ?>
<?php $jws_table_name=$table6; $where_condition="order by sno "; $target_from_jws=$_SERVER['PHP_SELF'].'?';//$limit_per_page_jws='10'; ?>
<?php if (($edit_id=='') and ($view_id=='')) { ?><tr><td colspan="2" align="center"><?php include "pagination_common.php"; echo $pagination ?></td></tr>
<tr><td colspan="2">
<table width="95%" align="center" cellpadding="6" cellspacing="0">
<tr><td width="12%" style="font-weight:bold;">Title</td>
<td width="41%" style="font-weight:bold;">Content</td>
<td width="6%" style="font-weight:bold;">Status</td>
<td width="10%" style="font-weight:bold;">Added Date</td>
<td width="5%" style="font-weight:bold;">Edit</td>
<td width="12%" align="center" style="font-weight:bold;">Change Status</td>
<td width="7%" align="center" style="font-weight:bold;">View</td>
<!--<td width="7%" style="font-weight:bold;">Delete</td>-->
</tr>
<?php
//$edit_url=mysql_query("select * from $jws_b2table order by sno desc limit 0,2");
while ($edit_url1=mysql_fetch_array($result)) { ?>
<tr>
<td class="text1"><?php echo $edit_url1['title']; ?></td><td class="text1"><?php echo $edit_url1['content']; ?></td>
<td class="text1"><?php if ($edit_url1['active']=='0') { echo 'Pending'; $active='1'; $activate_word='Activate';} if ($edit_url1['active']=='1') { echo 'Live';  $active='0';$activate_word='Deactivate';} ?></td>
<td class="text1"><?php echo date_only($edit_url1['date']); ?></td>
<td><a style="color:#000000;" href="<?php echo $_SERVER['PHP_SELF']; ?>?edit_id=<?php echo $edit_url1['sno']; ?>&page=<?php echo $page; ?>"><font face="Verdana, Arial, Helvetica, sans-serif" color="#000000">Edit</font></a></td>
<td align="center"><a style="color:#000000;" href="<?php echo $_SERVER['PHP_SELF']; ?>?act_user=<?php echo $active; ?>&sno=<?php echo $edit_url1['sno']; ?>&page=<?php echo $page; ?>"><font face="Verdana, Arial, Helvetica, sans-serif" color="#000000"><?php echo $activate_word ?></font></a></td>
<td align="center"><a style="color:#000000;" href="<?php echo $_SERVER['PHP_SELF']; ?>?view_id=<?php echo $edit_url1['sno']; ?>&page=<?php echo $page; ?>"><font face="Verdana, Arial, Helvetica, sans-serif" color="#000000">View</font></a></td>
<!--<td><a style="color:#000000;" href="<?php echo $_SERVER['PHP_SELF']; ?>?del_user=1&sno=<?php echo $edit_url1['sno']; ?>&page=<?php echo $page; ?>" onclick='return confirm("Are you want to Delete this Mobile?");'><font face="Verdana, Arial, Helvetica, sans-serif" color="#000000">Delete</font></a></td>-->
</tr>
<?php } ?>
</table>

</td></tr>
<?php } ?>

<?php if ($edit_id!='') { $ed_ge=mysql_fetch_array(mysql_query("select * from $jws_table_name where sno='$edit_id'")); ?>
<form name="edit_user_form" action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" onSubmit="return validation_edit();">
<tr><td colspan="2" style="font-weight:bold;" align="center"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2"><strong>ACCOUNT DETAILS</strong></font><input type="hidden" name="sno" value="<?php echo $ed_ge['sno']; ?>" /><input type="hidden" name="page" value="<?php echo $_REQUEST['page']; ?>" /></td></tr>
<tr><td class="welcome">Title:</td><td><input type="text" name="title" class="small" value="<?php echo $ed_ge['title']; ?>" /></td></tr>
<tr><td class="welcome">Content:</td><td><textarea name="content" cols="40" rows="10"><?php echo $ed_ge['content']; ?></textarea></td></tr>
<tr><td colspan="2" align="center"><input type="submit" name="edit_user" value="Update"></td></tr>
</form>
<?php } ?>



<?php if ($view_id!='') { $ed_ge=mysql_fetch_array(mysql_query("select * from $jws_table_name where sno='$view_id'")); ?>
<tr><td colspan="2" style="font-weight:bold;" align="center"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2"><strong>ACCOUNT DETAILS</strong></font></td></tr>
<tr><td class="welcome">Title:</td><td class="text1"><?php echo $ed_ge['title']; ?></td></tr>
<tr><td class="welcome">Content:</td><td class="text1"><?php echo $ed_ge['content']; ?></td></tr>
<?php } ?>
</table>
</td></tr>




</table>
  
  
  </td>
</tr>
</table>
<?php
include "footer.php";
?>
<?php } ?>