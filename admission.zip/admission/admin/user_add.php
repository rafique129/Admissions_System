<?php include "include/db.php"; ?>
<?php if($_SESSION[$admin_session]=='') { ?><script>window.location.href="website.php";</script><?php } else { ?>

<?php
include "header1.php"; 
?>
<?php
if(isset($_REQUEST['add_user']))
{
$email=$_REQUEST['email'];
$password=$_REQUEST['password'];
$name=$_REQUEST['name'];

$year_da=$_REQUEST['year_da'];
$month_da=$_REQUEST['month_da'];
$date_da=$_REQUEST['date_da'];

$dob=$year_da.'-'.$month_da.'-'.$date_da;

//$dob=$_REQUEST['dob'];
$sex=$_REQUEST['sex'];
$addr1=$_REQUEST['addr1'];
$addr2=$_REQUEST['addr2'];
$city=$_REQUEST['city'];
$state=$_REQUEST['state'];
$country=$_REQUEST['country'];
$post_code=$_REQUEST['post_code'];
$mnumber=$_REQUEST['mnumber'];
$tnumber=$_REQUEST['tnumber'];
$nominee=$_REQUEST['nominee'];
$rnominee=$_REQUEST['rnominee'];
$pan_number=$_REQUEST['pan_number'];
$acc_no=$_REQUEST['acc_no'];
$acc_na=$_REQUEST['acc_na'];
$acc_ba=$_REQUEST['acc_ba'];
$acc_br=$_REQUEST['acc_br'];
$acc_ty=$_REQUEST['acc_ty'];
$acc_if=$_REQUEST['acc_if'];
$refer_id=$_REQUEST['refer_id'];
//$sponsor_id=$_REQUEST['sponsor_id'];
$fa_name=$_REQUEST['fa_name'];

//$fran=$_REQUEST['fran'];

if($_REQUEST[dated]==''){$dated=$dated;}else{$dated=$_REQUEST['dated'];}

$dep_cour=$_REQUEST[dep_cour];

$department=kandu_pidi_new($dep_cour,$table9,name,sno);
$course=kandu_pidi_new($dep_cour,$table9,course,sno);

$pin=$_REQUEST['pin'];

$datetimed=$datetime;

$side=$_REQUEST['side'];
$new_sno=$_REQUEST['new_sno'];

$m_1=$_REQUEST['m_1'];
$m_2=$_REQUEST['m_2'];
$m_3=$_REQUEST['m_3'];
$m_4=$_REQUEST['m_4'];
$m_5=$_REQUEST['m_5'];

$status=$_REQUEST['status'];
$comments=$_REQUEST['comments'];
/*if(mysql_num_rows(mysql_query("select * from $table4 where refer_id='$refer_id'"))>='5') { $error='Refer id already Added 5 Members'; } else */
/*if(mysql_num_rows(mysql_query("select * from $table3 where gen_id='$pin' and user_id=''"))=='0') { $error='Wrong Pin Number Please Try Again'; }*/

$username=strtoupper($_REQUEST['sponsor_id']);
$monthing=substr($username,0,2);
$sponsor_id=substr(substr($username,2),0,-2);
$t_value=substr($username,-2);
/*if(($t_value!=new_con($sponsor_id)) or (mysql_num_rows(mysql_query("select * from $table4 where sno='$sponsor_id' and  months='$monthing'"))==0)){echo '<script>alert("Wrong Sponsor ID Please Try Again");</script>';}else*/

/*if (check_da($sponsor_id,$table4,sno)=='0') { echo '<script>alert("Wrong Sponsor ID Please Try Again");</script>'; } else*/
if (check_da($new_sno,$table4,sno)!='0') { echo '<script>alert("This User ID is already Entered");</script>'; } else {
/*if (check_da($email,$table4,email)!='0') { echo '<script>alert("This Email ID is already Entered");</script>'; } else{*/

/*
$from_gen_id=mysql_fetch_array(mysql_query("select * from $table3 where gen_id='$pin' and user_id=''"));
$amount=$from_gen_id['amount'];
$div_per=$from_gen_id['div_per'];
$lev_per=$from_gen_id['lev_per'];
$spo_per=$from_gen_id['spo_per'];
$tot_per=$from_gen_id['tot_per'];
$months=$from_gen_id['months'];
*/


$months=$_REQUEST[months];

$amount=$default_investment;
$refer_id=pudhu_id_kudu($table4,refer_id,level_id);
$level_id_old=kandu_pidi_new($refer_id,$table4,level_id,sno);
$level_id=$level_id_old+1;
mysql_query("insert into $table4 (sno,email,password,name,dob,sex,addr1,addr2,city,state,country,post_code,mnumber,tnumber,nominee,rnominee,pan_number,acc_no,acc_na,acc_ba,acc_br,acc_ty,acc_if,refer_id,sponsor_id,side,amount,div_per,lev_per,spo_per,months,dated,datetimed,active,level_id,fa_name,tot_per,fran,login_active,department,course,m_1,m_2,m_3,m_4,m_5,status,comments) values ('$new_sno','$email','$password','$name','$dob','$sex','$addr1','$addr2','$city','$state','$country','$post_code','$mnumber','$tnumber','$nominee','$rnominee','$pan_number','$acc_no','$acc_na','$acc_ba','$acc_br','$acc_ty','$acc_if','$refer_id','$sponsor_id','$side','$amount','$div_per','$lev_per','$spo_per','$months','$dated','$datetimed','1','$level_id','$fa_name','$tot_per','$fran','1','$department','$course','$m_1','$m_2','$m_3','$m_4','$m_5','$status','$comments')") or die (mysql_error());

$updating=mysql_fetch_array(mysql_query("select * from $table4 order by sno desc"));
$main_sno=$updating[sno];
$bonus_kaaga=mysql_num_rows(mysql_query("select * from $table4 where level_id='$updating[level_id]'"));

for ($monthing=0;$monthing<20;$monthing++)
{
$next_month = next_last_find($m,$monthing,$d,$y);
$next_monthing=$next_month;
//echo $next_monthing;
$amount_b=$default_permonth;
$amount_or_b=with_tax($amount_b,$percentage_value);
//mysql_query("insert into $table8 (user_id,amount,amount_or,dated,date_timed,check_no,real_id) values ('$main_sno','$amount_b','$amount_or_b','$next_monthing','$date_timed','b','$main_sno')") or die (mysql_error);
}

$id1=$sponsor_id;
$id2=kandu_pidi_new($id1,$table4,sponsor_id,sno);
$id3=kandu_pidi_new($id2,$table4,sponsor_id,sno);
$id4=kandu_pidi_new($id3,$table4,sponsor_id,sno);
$id5=kandu_pidi_new($id4,$table4,sponsor_id,sno);
$id6=kandu_pidi_new($id5,$table4,sponsor_id,sno);
$id7=kandu_pidi_new($id6,$table4,sponsor_id,sno);

for ($i=1;$i<=6;$i++) {
$ids="id".$i;
$id=$$ids;
if($i==1) {$per=5;}else{$per=1;}
$amount_be=($default_investment*$per)/100;
$amount_or_be=with_tax($amount_be,$percentage_value);
if(($id!=0) and ($id!='')) {
//mysql_query("insert into $table8 (user_id,amount,amount_or,dated,date_timed,check_no,real_id) values ('$id','$amount_be','$amount_or_be','$dated','$date_timed','e','$main_sno')") or die (mysql_error);
}
}


mysql_query("update $table4 set fran=fran+1 where sno='$refer_id'") or die (mysql_error());
//$main_sno=$new_sno;
//mysql_query("update $table3 set user_id='$main_sno' where gen_id='$pin'") or die (mysql_error());

//include "inserting.php";

/*echo '<script>window.location.href="signupcopy.php?user_id='.$main_sno.'&sms=1";</script>';*/
echo '<script>alert("Registered Successfully");window.location.href="user_list.php";</script>';
}
}
?>


<tr>
<td colspan="5" height="5">
<?php
/*for ($monthing=0;$monthing<3;$monthing++)
{
$next_month = date('t-m-Y',mktime(0, 0, 0, $m+$monthing, $d, $y));
echo '<br />';
echo $next_month;
}*/
include "dropdown.php"; 
?>
</td>
</tr>
<tr>
  <td colspan="3" valign="top" align="center">
  
  <table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:0px solid #000000" width="570">

<tr bgcolor="#">

<td colspan="2" align="center">

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="18"><img src="images/blue_left1.jpg" width="18" height="34" /></td>
<td colspan="2" background="images/blue_center.jpg"><div class="user_head">NEW STUDENT ADMISSION PAGE</div></td>
<td valign="top" align="right" width="18"><img src="images/blue_right1.jpg" width="18" height="34" /></td>
</tr>
</table>

</td>
</tr>

<tr>
<td colspan="2" align="center">
<table width="93%" cellpadding="3" cellspacing="3" align="center">
<form name="user_add" action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" onSubmit="return user_validation();">
<?php if ($_REQUEST['added']!='') { ?><tr><td colspan="2" align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#000000"><strong>Your Link Has Been Added</strong></font></td></tr><?php } ?>
<?php if ($_REQUEST['refer_error']!='') { ?><tr><td colspan="2" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#00CC00"><strong><?php echo $refer_error; ?></strong></font></td></tr><?php } ?>
<?php if ($error!='') { ?><tr><td colspan="2" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFCC00"><strong><?php echo $error; ?></strong></font></td></tr><?php } ?>

<?php /*<tr><td colspan="2" style="font-weight:bold;" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><strong>ACCOUNT DETAILS</strong></font></td></tr>*/?>
<!--<tr><td>Secret Question:</td><td><input type="text" name="quiz" class="small" /></td></tr>
<tr><td>Answer:</td><td><input type="text" name="answ" class="small" /></td></tr>-->
<tr bgcolor="#F0F0F0"><td colspan="2" style="font-weight:bold;" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><strong>PERSONAL DETAILS </strong></font></td></tr>
<tr><td>Username*:</td><td><input type="text" name="email" class="small" value="<?php echo $_REQUEST['email']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td>Name*:</td><td><input type="text" name="name" class="small" value="<?php echo $_REQUEST['name']; ?>" /></td></tr>
<tr><td>Password*:</td><td><input type="password" name="password" class="small" /></td></tr>
<tr bgcolor="#F0F0F0"><td>Confirm Password*:</td><td><input type="password" name="password1" class="small" /></td></tr>
<tr><td>Date of Birth*:</td><td><!--<script>DateInput('dob', true, 'YYYY-MM-DD')</script>-->
<select name="date_da" class="simple_da"><?php for ($h = 01; $h < 32; $h++){ ?><option value="<?php echo "$h"; ?>"<?php if($h==$d){echo $sel;}?>><?php echo $h; ?></option><?php } ?></select>
<select name="month_da" class="simple_da"><?php for ($i = 01; $i < 13; $i++){ ?><option value="<?php echo "$i"; ?>"<?php if($i==$m){echo $sel;}?>><?php echo $i; ?></option><?php } ?></select>
<select name="year_da" class="simple_da"><?php for ($j = 1925; $j < 2014; $j++){ ?><option value="<?php echo "$j"; ?>"<?php $year_da=$y; if($j==$year_da){echo $sel;}?>><?php echo $j; ?></option><?php } ?></select>
</td></tr>
<tr bgcolor="#F0F0F0"><td>Gender:</td><td><input type="radio" name="sex" value="male" checked="checked" />Male,&nbsp;&nbsp;&nbsp;<input type="radio" name="sex" value="female" />Female</td></tr>
<tr><td>Address First Line*:</td><td><input type="text" name="addr1" class="small" value="<?php echo $_REQUEST['addr1']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td>Address Second Line:</td><td><input type="text" name="addr2" class="small" value="<?php echo $_REQUEST['addr2']; ?>" /></td></tr>
<tr><td>City*:</td><td><input type="text" name="city" class="small" value="<?php echo $_REQUEST['city']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td>State*:</td><td><input type="text" name="state" class="small" value="<?php echo $_REQUEST['state']; ?>" /></td></tr>
<tr><td>Country*:</td><td><input type="text" name="country" class="small" value="<?php echo $_REQUEST['country']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td>Postal Code*:</td><td><input type="text" name="post_code" class="small" value="<?php echo $_REQUEST['post_code']; ?>" /></td></tr>
<tr><td>Mobile Number*:</td><td><input type="text" name="mnumber" class="small" value="<?php echo $_REQUEST['mnumber']; ?>" /></td></tr>

<tr bgcolor="#F0F0F0"><td>Passport Number*:</td><td><input type="text" name="pan_number" class="small" value="<?php echo $_REQUEST['pan_number']; ?>" /></td></tr>
<tr><td>Course*:</td><td><select name="dep_cour"><?php $deal_ms=mysql_query("select * from $table9 order by name"); while ($deal_ms_list=mysql_fetch_array($deal_ms)) {?><option value="<?php echo $deal_ms_list[sno]; ?>"><?php echo $deal_ms_list[name]; ?>--><?php echo $deal_ms_list[course]; ?></option><?php } ?></select></td></tr>

<tr bgcolor="#F0F0F0"><td colspan="2" style="font-weight:bold;" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><strong>MARK DETAILS </strong></font></td></tr>

<tr><td>Maths*:</td><td><input type="text" name="m_1" class="small" value="<?php echo $_REQUEST['m_1']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td>English*:</td><td><input type="text" name="m_2" class="small" value="<?php echo $_REQUEST['m_2']; ?>" /></td></tr>
<tr><td>Subject 3:</td><td><input type="text" name="m_3" class="small" value="<?php echo $_REQUEST['m_3']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td>Subject 4:</td><td><input type="text" name="m_4" class="small" value="<?php echo $_REQUEST['m_4']; ?>" /></td></tr>
<tr><td>Subject 5:</td><td><input type="text" name="m_5" class="small" value="<?php echo $_REQUEST['m_5']; ?>" /></td></tr>

<tr bgcolor="#F0F0F0"><td>Status:</td><td><input type="text" name="status" class="small" value="<?php echo $_REQUEST['status']; ?>" /></td></tr>
<tr><td>Comments:</td><td><textarea name="comments"><?php echo $_REQUEST['comments']; ?></textarea></td></tr>


<tr bgcolor="#F0F0F0"><td colspan="2" align="center"><input type="submit" name="add_user" value="Add"></td></tr>
</form>
</table>



</td>
</tr>

</table>
  
<br />
<br />

  </td>
</tr>
</table>




<?php
include "footer.php";
?>
<?php } ?>


<script language="javascript">	function user_validation()	{	var nice=document.user_add;
if(nice.email.value=='')	{	alert("Enter username");	nice.email.focus();	return false;	}
if(nice.name.value=='')	{	alert("Enter Name");	nice.name.focus();	return false;	}
if(nice.password.value=='')	{	alert("Enter Password");	nice.password.focus();	return false;	}
if(nice.password.value!=nice.password1.value)	{	alert("Confirm Password must be equal Password");	nice.password.focus();	return false;	}
if(nice.password.value.length<6)
{
alert("Password length should be 6")
nice.password.focus();
return false;
}

if(nice.addr1.value=='')	{	alert("Enter Address");	nice.addr1.focus();	return false;	}
if(nice.city.value=='')	{	alert("Enter City");	nice.city.focus();	return false;	}
if(nice.state.value=='')	{	alert("Enter State");	nice.state.focus();	return false;	}
if(nice.country.value=='')	{	alert("Enter Country");	nice.country.focus();	return false;	}
if(nice.post_code.value=='')	{	alert("Enter Postal Code");	nice.post_code.focus();	return false;	}
if(nice.mnumber.value=='')	{	alert("Enter Mobile Number");	nice.mnumber.focus();	return false;	}
if(nice.pan_number.value=='')	{	alert("Enter Mobile Number");	nice.pan_number.focus();	return false;	}

if(nice.m_1.value=='')	{	alert("Enter Maths Mark");	nice.m_1.focus();	return false;	}
if(nice.m_2.value=='')	{	alert("Enter English Mark");	nice.m_2.focus();	return false;	}
}	</script>