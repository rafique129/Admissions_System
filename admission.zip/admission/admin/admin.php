<?php include "include/db.php"; ?>
<?php if(($_SESSION[$admin_session]=='') and ($_SESSION[$c_session]=='')) { ?><script>window.location.href="website.php";</script><?php } else { ?>


<?php 
include "header1.php"; 
?>
<tr>
<td colspan="5" height="5">
<?php
include "dropdown.php"; 
?>
</td>
</tr>
<tr>
  <td colspan="3" valign="top" align="center">&nbsp;
  
<h1>Home Page</h1>
  
  
  </td>
</tr>
</table>
</body>
</html>
<?php
}
?>