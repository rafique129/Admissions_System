<?php include "include/db.php"; ?> <?php if(($_SESSION[$admin_session]=='') and ($_SESSION[$c_session]=='')) { ?><script>window.location.href="website.php";</script><?php } else { ?>
<?php
include "header1.php"; 
$sno=$_REQUEST['sno'];?>


<tr>
<td colspan="5" height="5">
<?php
include "dropdown.php"; 
?>
</td>
</tr>
<tr>
  <td colspan="3" valign="top" align="center">
  
  <table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:0px solid #000000" width="450">

<tr bgcolor="#">

<td colspan="2" align="center">

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="18"><img src="images/blue_left1.jpg" width="18" height="34" /></td>
<td colspan="2" background="images/blue_center.jpg"><div class="user_head">VIEW STUDENT DETAILS</div></td>
<td valign="top" align="right" width="18"><img src="images/blue_right1.jpg" width="18" height="34" /></td>
</tr>
</table>

</td>
</tr>

<tr>
<td colspan="2" align="center">
<table width="95%" cellpadding="3" cellspacing="3" align="center">

<form method="post">
<tr>
<td>User:</td>
<td>
<select name="sno" onchange="this.form.submit();">
<option value="">--Select--</option>
<?php $select_group_id=mysql_query("select * from $table4"); while ($select_group_id_array=mysql_fetch_array($select_group_id)) { ?>
<option value="<?php echo $select_group_id_array['sno']; ?>" <?php if ($select_group_id_array['sno']==$sno) { echo ' selected="selected"'; } ?>><?php echo new_number($select_group_id_array['sno'],$table4);//echo $select_group_id_array[months].$select_group_id_array[sno];
/* ?>, <?php echo $select_group_id_array[name];*/ ?></option>
<?php } ?>
</select>
</td>
</tr>
</form>

<?php if($sno!='') { ?>
<?php ob_start(); ?>
<form name="user_edit" action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" onSubmit="return user_e_validation();">
<?php $user_edit=mysql_fetch_array(mysql_query("select * from $table4 where sno='$sno'")); ?>
<input type="hidden" name="sno" value="<?php echo $sno; ?>" />

<?php if ($_REQUEST['added']!='') { ?><tr><td colspan="2" align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><strong>Your Link Has Been Added</strong></font></td></tr><?php } ?>
<?php if ($_REQUEST['refer_error']!='') { ?><tr><td colspan="2" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFCC00"><strong><?php echo $refer_error; ?></strong></font></td></tr><?php } ?>
<?php /*
<tr><td colspan="2" style="font-weight:bold;" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><strong>ACCOUNT DETAILS</strong></font></td></tr>
<tr><td>Email*:</td><td><input type="text" name="email" class="small" value="<?php echo $_REQUEST['email']; ?>" /></td></tr>*/?>
<!--<tr><td>Secret Question:</td><td><input type="text" name="quiz" class="small" /></td></tr>
<tr><td>Answer:</td><td><input type="text" name="answ" class="small" /></td></tr>-->
<tr><td colspan="2" style="font-weight:bold;" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><strong>PERSONAL DETAILS</strong></font></td></tr>
<tr bgcolor="#F0F0F0"><td>Name*:</td><td><?php echo $user_edit['name']; ?></td></tr>
<!--<tr><td>Maiden Name*:</td><td><input type="text" name="mname" class="small" value="<?php echo $user_edit['mname']; ?></td></tr>-->
<tr><td>Password*:</td><td><?php echo $user_edit['password']; ?></td></tr>
<tr bgcolor="#F0F0F0"><td>Date of Birth*:</td><td><?php echo date_with_day($user_edit['dob']); ?></td></tr>
<tr><td>Gender:</td><td><?php echo $user_edit['sex']; ?></td></tr>
<tr bgcolor="#F0F0F0"><td>Address First Line*:</td><td><?php echo $user_edit['addr1']; ?></td></tr>
<tr><td>Address Second Line:</td><td><?php echo $user_edit['addr2']; ?></td></tr>
<tr bgcolor="#F0F0F0"><td>City*:</td><td><?php echo $user_edit['city']; ?></td></tr>
<tr><td>State*:</td><td><?php echo $user_edit['state']; ?></td></tr>
<tr bgcolor="#F0F0F0"><td>Country*:</td><td><?php echo $user_edit['country']; ?></td></tr>
<tr><td>Postal Code*:</td><td><?php echo $user_edit['post_code']; ?></td></tr>
<tr bgcolor="#F0F0F0"><td>Mobile Number*:</td><td><?php echo $user_edit['mnumber']; ?></td></tr>
<tr><td>Telephone Number:</td><td><?php echo $user_edit['tnumber']; ?></td></tr>

<tr bgcolor="#F0F0F0"><td>Passport Number*:</td><td><?php echo $user_edit['pan_number']; ?></td></tr>
<tr><td>Department:</td><td><?php echo $user_edit['department'].' Department ';//echo $user_edit['sponsor_id']; ?><?php //echo $refer_error; ?></td></tr>
<tr bgcolor="#F0F0F0"><td>Course*:</td><td><?php  echo $user_edit['course'].' Course';?></td></tr>

<tr><td colspan="2" style="font-weight:bold;" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><strong>MARK DETAILS </strong></font></td></tr>

<tr bgcolor="#F0F0F0"><td>Maths*:</td><td><?php echo $user_edit['m_1']; ?></td></tr>
<tr><td>English*:</td><td><?php echo $user_edit['m_2']; ?></td></tr>
<tr bgcolor="#F0F0F0"><td>Subject 3:</td><td><?php echo $user_edit['m_3']; ?></td></tr>
<tr><td>Subject 4:</td><td><?php echo $user_edit['m_4']; ?></td></tr>
<tr bgcolor="#F0F0F0"><td>Subject 5:</td><td><?php echo $user_edit['m_5']; ?></td></tr>


<tr><td>Status:</td><td><?php echo $user_edit['status']; ?></td></tr> 
<tr bgcolor="#F0F0F0"><td>Comments:</td><td><?php echo nl2br($user_edit['comments']); ?></td></tr>

<tr><td>Score:</td><td><?php echo $user_edit['score']; ?></td></tr>

</form>
<?php $print_value=ob_get_clean(); echo $print_value; ?>

<?php } ?>
</table>
<div align="center"><?php $print_value1=str_replace("'Do you really want to delete the Product?'","","$print_value"); $print_value2='<table width="100%">'.$print_value1.'</table>'; ?>
<form name="pay_out_details" method="post" action="print.php" target="_blank">
<input type="hidden" name="print" value='<?php echo $print_value2; ?>' />
<input type="submit" name="submit" value="Print"  />
</form>
</div>



</td>
</tr>

</table>
  
<br />
<br />

  </td>
</tr>
</table>




<?php
include "footer.php";
?>
<?php } ?>


<script language="javascript">	function user_e_validation()	{	var nice=document.user_edit;
if(nice.name.value=='')	{	alert("Enter Name");	nice.name.focus();	return false;	}
if(nice.password.value=='')	{	alert("Enter Password");	nice.password.focus();	return false;	}
if(nice.password.value!=nice.password1.value)	{	alert("Confirm Password must be equal Password");	nice.password.focus();	return false;	}
if(nice.addr1.value=='')	{	alert("Enter Address");	nice.addr1.focus();	return false;	}
if(nice.city.value=='')	{	alert("Enter City");	nice.city.focus();	return false;	}
if(nice.state.value=='')	{	alert("Enter State");	nice.state.focus();	return false;	}
if(nice.country.value=='')	{	alert("Enter Country");	nice.country.focus();	return false;	}
if(nice.post_code.value=='')	{	alert("Enter Postal Code");	nice.post_code.focus();	return false;	}
if(nice.mnumber.value=='')	{	alert("Enter Mobile Number");	nice.mnumber.focus();	return false;	}
if(nice.nominee.value=='')	{	alert("Enter Nominee");	nice.nominee.focus();	return false;	}
if(nice.rnominee.value=='')	{	alert("Enter Nominee Relationship");	nice.rnominee.focus();	return false;	}
if(nice.acc_no.value=='')	{	alert("Enter Account Number");	nice.acc_no.focus();	return false;	}
if(nice.acc_na.value=='')	{	alert("Enter Account Name");	nice.acc_na.focus();	return false;	}
if(nice.acc_ba.value=='')	{	alert("Enter Bank Name");	nice.acc_ba.focus();	return false;	}
if(nice.acc_br.value=='')	{	alert("Enter Bank Branch Name");	nice.acc_br.focus();	return false;	}
if(nice.acc_ty.value=='')	{	alert("Enter Account Type");	nice.acc_ty.focus();	return false;	}
if(nice.refer_id.value=='')	{	alert("Enter Refer ID");	nice.refer_id.focus();	return false;	}
if(nice.sponsor_id.value=='')	{	alert("Enter Sponsor ID");	nice.sponsor_id.focus();	return false;	}
if(nice.method.value=='')	{	alert("Select User Method");	nice.method.focus();	return false;	}
}	</script>