<?php include "include/db.php"; ?> <?php if($_SESSION[$admin_session]=='') { ?><script>window.location.href="website.php";</script><?php } else { ?>
<?php
include "header1.php"; 
?>
<?php
if(isset($_REQUEST['act_user']))
{
$act_user=$_REQUEST['act_user'];
$page=$_REQUEST['page'];
$sno=$_REQUEST['sno'];
mysql_query("update $table4 set active='$act_user' where sno='$sno'");
echo '<script>alert("Status has been Changed");</script>';
}
?>

<?php
if(isset($_REQUEST['search']))
{
$name=$_REQUEST['name'];
$uniq_ids=$_REQUEST['uniq_ids'];

$year_da=$_REQUEST['year_da'];
$month_da=$_REQUEST['month_da'];
$date_da=$_REQUEST['date_da'];

$dob=$year_da.'-'.$month_da.'-'.$date_da;

if ($name=='') { } else { $where1=" or name like '%$name%'"; }
if ($uniq_ids=='') { } else { $where1=" or sno like '%$uniq_ids%'"; }
//$where2=" and dob='$dob'";
$where_condition_e="where sno=''".$where1.$where2;
}

if($year_da=='') {$ya=$y;}else{$ya=$year_da;}
if($month_da=='') {$ma=$m;}else{$ma=$month_da;}
if($date_da=='') {$da=$d;}else{$da=$date_da;}
?>
<tr>
<td colspan="5" height="5">
<?php
include "dropdown.php"; 
?>
</td>
</tr>
<tr>
  <td colspan="3" valign="top" align="center">
  
  <table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:0px solid #000000" width="100%">

<tr><td colspan="2" align="center">

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="18"><img src="images/blue_left1.jpg" width="18" height="34" /></td>
<td colspan="2" background="images/blue_center.jpg"><div class="user_head">SEARCH STUDENTS</div></td>
<td valign="top" align="right" width="18"><img src="images/blue_right1.jpg" width="18" height="34" /></td>
</tr>
</table>

</td></tr>

<?php $first_value=''; $jws_table_name=$table4; $where_condition="$where_condition_e order by sno desc "; $target_from_jws=$_SERVER['PHP_SELF'].'?';//$limit_per_page_jws='10'; ?>
<tr><td colspan="2" align="center"><?php include "pagination_common.php"; echo $pagination ?></td></tr>


<tr><td colspan="2" align="center">

<table width="75%">
<form method="post">
<tr>
<td>Name:</td>
<td><input type="text" name="name" value="<?php echo $_REQUEST['name']; ?>" /></td>
<td>DOB:</td>
<td><!--<script>DateInput('dob', true, 'YYYY-MM-DD')</script>-->
<select name="date_da" class="simple_da"><?php for ($h = 01; $h < 32; $h++){ ?><option value="<?php echo "$h"; ?>"<?php if($h==$da){echo $sel;}?>><?php echo $h; ?></option><?php } ?></select>
<select name="month_da" class="simple_da"><?php for ($i = 01; $i < 13; $i++){ ?><option value="<?php echo "$i"; ?>"<?php if($i==$ma){echo $sel;}?>><?php echo $i; ?></option><?php } ?></select>
<select name="year_da" class="simple_da"><?php for ($j = 1925; $j < 2014; $j++){ ?><option value="<?php echo "$j"; ?>"<?php $year_da=$ya; if($j==$year_da){echo $sel;}?>><?php echo $j; ?></option><?php } ?></select>
</td>
<?php /*<td>User ID:</td>
<td><input type="text" name="uniq_ids" value="<?php echo $_REQUEST['uniq_ids']; ?>" /></td>*/?>
<td><input type="submit" name="search" value="Search" /></td>
</tr>
</form>
</table>

</td></tr>


<tr>
<td colspan="2" align="center">


<table width="99%" align="center" cellpadding="2" cellspacing="0">
<tr>
<td><strong>IDS</strong></td>
<td><strong>Passwords</strong></td>
<?php /*<td><strong>Name</strong></td>*/?>
<td><strong>Date</strong></td>
<td><strong>DOB</strong></td>
<td><strong>Reffer IDS</strong></td>
<td><strong>Sponsor IDS</strong></td>
<td><strong>Amount</strong></td>
<td><strong>Status</strong></td>
<td><strong><!--Change--></strong></td>
<td><strong>Action</strong></td>
</tr>

<?php //$user_list=mysql_query("select * from $table4 where active='1'"); while ($user_list_new=mysql_fetch_array($user_list)){
while ($user_list_new=mysql_fetch_array($result)){?>
<tr>
<td><?php echo new_number($user_list_new['sno'],$table4); ?></td>
<td><?php echo $user_list_new['password']; ?></td>
<?php /*<td><?php echo $user_list_new['name']; ?></td>*/?>
<td><?php echo date_with_day($user_list_new['dated']); ?></td>
<td><?php echo date_with_day($user_list_new['dob']); ?></td>
<td><?php echo new_number($user_list_new['refer_id'],$table4); ?></td>
<td><?php echo new_number($user_list_new['sponsor_id'],$table4); ?></td>
<td><?php $tot_amount=$tot_amount+$user_list_new['amount']; echo $user_list_new['amount']; ?></td>
<td><?php if ($user_list_new['active']=='0') { echo 'Pending'; $active='1'; $activate_word='Activate';} if ($user_list_new['active']=='1') { echo 'Live';  $active='0';$activate_word='Deactivate';} ?></td>
<td><a style="color:#000000;" href="<?php echo $_SERVER['PHP_SELF']; ?>?act_user=<?php echo $active; ?>&sno=<?php echo $user_list_new['sno']; ?>&page=<?php echo $page; ?>&name=<?php echo $name; ?>&uniq_ids=<?php echo $uniq_ids; ?>"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><?php //echo $activate_word ?></font></a></td>
<td>
<a href="user_view.php?sno=<?php echo $user_list_new['sno']; ?>"><img src="include/images/view.png" alt="View" border="0" /></a>
<a href="user_edit.php?sno=<?php echo $user_list_new['sno']; ?>"><img src="include/images/edit.png" alt="Edit" border="0" /></a>
<!--<a href="<?php echo $_SERVER['PHP_SELF']; ?>?pro_id=<?php echo $pro_list_array['sno']; ?>&page=delete&delete1=1&active=0&pages=<?php echo $pages; ?>" onClick="return (confirm('Do you really want to delete the Product?'))";><img src="include/images/delete-icon.png" alt="Delete" border="0" /></a>-->
</td>
</tr>
<?php } ?>
<tr>
<td colspan="7"></td>
<td><?php echo number_format($tot_amount,2); ?></td>
<td colspan="3"></td>
</tr>
</table>


</td>
</tr>

</table>
  
<br />
<br />

  </td>
</tr>
</table>




<?php
include "footer.php";
?>
<?php } ?>


