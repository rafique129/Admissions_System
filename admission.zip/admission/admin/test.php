<?php
$nu_pin=5;
for ($i_new=1;$i_new<=$nu_pin;$i_new++){
$codelenght = 10;
while($newcode_length < $codelenght) {
$x=1;
$y=3;
$part = rand($x,$y);
if($part==1){$a=48;$b=57;}  // Numbers
if($part==2){$a=65;$b=90;}  // UpperCase
if($part==3){$a=97;$b=122;} // LowerCase
$code_part=chr(rand($a,$b));
$newcode_length = $newcode_length + 1;
$newcode = $newcode.$code_part;
echo $newcode;
}
//$reffer_no=kandu_pidi_new($reffer_id,$table4,sno,sno);
echo '<br>';


$i_new1=$i_new*$nu_pin;
$gen_id=$newcode.$i_new1;
echo $gen_id;
//mysql_query("insert into $table3 (gen_id,reffer_id,reffer_no,amount,bv,perc,dated,eb,eb_id) values ('$gen_id','$reffer_id','$reffer_no','$amount','$bv','$perc','$dated','$eb','$eb_id')") or die (mysql_error());
//echo '<script>window.location.href="'.$_SERVER['PHP_SELF'].'?added=1";</script>';
}

?>