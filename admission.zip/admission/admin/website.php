<?php include "include/db.php"; ?>
<?php
if(isset($_REQUEST['login']))
{
$username=$_REQUEST["uname"];
$password=$_REQUEST["pword"];
$sql1="select * from $table1 where username='$username' and slno='1'";
$result1=mysql_query($sql1);
$res1=mysql_num_rows($result1);


if($res1==1)
{

$sql2="select * from $table1 where username='$username' and password='$password' and slno='1'";
$result2=mysql_query($sql2);
$res2=mysql_num_rows($result2);

if($res2==1)
{
$l_login=kandu_pidi_new(1,$table1,n_login,slno); $n_login=$datetime; mysql_query("update $table1 set n_login='$n_login',l_login='$l_login',ennu=ennu+1 where username='$username' and slno='1'") or die (mysql_error());
		 $sid=session_id();
		 $sesid=substr($sid,8,6);
		 $_SESSION[$admin_session]=$sesid.date("m/d").$username;
?>
<script>window.location.href="admin.php"</script>
<?php
}
else
{
?>
<script>
alert("Incorrect Password");
</script>
<?php
}


}
else
{

?>

<script>
alert("incorrect Username");
window.location.href="website.php";
</script>

<?php

}
}
?>



<?php include "header1.php"; ?>
<tr>
  <td colspan="3" valign="top" align="center"><br>
  <form name="form1" method="post" action="<?php $_SERVER['PHP_SELF'];?>">
<table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:px solid #000000" height="200">
<tr bgcolor="#ffffff">
<td colspan="2" align="center">

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="18"><img src="images/blue_left1.jpg" width="18" height="34" /></td>
<td colspan="2" background="images/blue_center.jpg"><div class="user_head">ADMIN LOGIN</div></td>
<td valign="top" align="right" width="18"><img src="images/blue_right1.jpg" width="18" height="34" /></td>
</tr>
</table>

</td>
</tr>
<tr>
<td>Username</td><td><input type="text" name="uname"></td>
</tr>
<tr>
<td>Password</td><td><input type="password" name="pword"></td>
</tr>
<tr bgcolor="#ffffff">
<td colspan="2" align="center"><input type="submit" name="login" value="Login"></td>
</tr>

<tr bgcolor="#ffffff">
<td colspan="2" align="center"><a href="website_c.php">Counsellor Login</a></td>
</tr>

</table>
  </form>
  
  </td>
</tr>
</table>
</body>
</html>