<?php include "include/db.php"; ?> <?php if($_SESSION[$admin_session]=='') { ?><script>window.location.href="website.php";</script><?php } else { ?>
<?php
include "header1.php"; 
$sno=$_REQUEST['sno'];?>


<tr>
<td colspan="5" height="5">
<?php
include "dropdown.php"; 
?>
</td>
</tr>
<tr>
  <td colspan="3" valign="top" align="center">
  
  <table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:0px solid #000000" width="300">

<tr bgcolor="#">

<td colspan="2" align="center">

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="18"><img src="images/blue_left1.jpg" width="18" height="34" /></td>
<td colspan="2" background="images/blue_center.jpg"><div class="user_head">SIGNUP COPY</div></td>
<td valign="top" align="right" width="18"><img src="images/blue_right1.jpg" width="18" height="34" /></td>
</tr>
</table>

</td>
</tr>

<tr>
<td colspan="2" align="center">
<table width="95%" cellpadding="3" cellspacing="3" align="center">

<form method="post" action="signupcopy.php" target="_blank">
<tr>
<td>User:</td>
<td>
<select name="user_id" onchange="this.form.submit();">
<option value="">--Select--</option>
<?php $select_group_id=mysql_query("select * from $table4"); while ($select_group_id_array=mysql_fetch_array($select_group_id)) { ?>
<option value="<?php echo $select_group_id_array['sno']; ?>" <?php if ($select_group_id_array['sno']==$sno) { echo ' selected="selected"'; } ?>><?php echo $select_group_id_array[sno]; ?>, <?php echo $select_group_id_array[name]; ?></option>
<?php } ?>
</select>
</td>
</tr>
</form>

<?php if($sno!='') { ?>
<?php ob_start(); ?>
<?php $user_edit=mysql_fetch_array(mysql_query("select * from $table4 where sno='$sno'")); ?>
<input type="hidden" name="sno" value="<?php echo $sno; ?>" />

<?php if ($_REQUEST['added']!='') { ?><tr><td colspan="2" align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><strong>Your Link Has Been Added</strong></font></td></tr><?php } ?>
<?php if ($_REQUEST['refer_error']!='') { ?><tr><td colspan="2" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFCC00"><strong><?php echo $refer_error; ?></strong></font></td></tr><?php } ?>
<tr><td colspan="2" align="center">





</td></tr>


<?php $print_value=ob_get_clean(); echo $print_value; ?>

<?php } ?>
</table>




</td>
</tr>

</table>
  
<br />
<br />

  </td>
</tr>
</table>




<?php
include "footer.php";
?>
<?php } ?>


<script language="javascript">	function user_e_validation()	{	var nice=document.user_edit;
if(nice.name.value=='')	{	alert("Enter Name");	nice.name.focus();	return false;	}
if(nice.password.value=='')	{	alert("Enter Password");	nice.password.focus();	return false;	}
if(nice.password.value!=nice.password1.value)	{	alert("Confirm Password must be equal Password");	nice.password.focus();	return false;	}
if(nice.addr1.value=='')	{	alert("Enter Address");	nice.addr1.focus();	return false;	}
if(nice.city.value=='')	{	alert("Enter City");	nice.city.focus();	return false;	}
if(nice.state.value=='')	{	alert("Enter State");	nice.state.focus();	return false;	}
if(nice.country.value=='')	{	alert("Enter Country");	nice.country.focus();	return false;	}
if(nice.post_code.value=='')	{	alert("Enter Postal Code");	nice.post_code.focus();	return false;	}
if(nice.mnumber.value=='')	{	alert("Enter Mobile Number");	nice.mnumber.focus();	return false;	}
if(nice.nominee.value=='')	{	alert("Enter Nominee");	nice.nominee.focus();	return false;	}
if(nice.rnominee.value=='')	{	alert("Enter Nominee Relationship");	nice.rnominee.focus();	return false;	}
if(nice.acc_no.value=='')	{	alert("Enter Account Number");	nice.acc_no.focus();	return false;	}
if(nice.acc_na.value=='')	{	alert("Enter Account Name");	nice.acc_na.focus();	return false;	}
if(nice.acc_ba.value=='')	{	alert("Enter Bank Name");	nice.acc_ba.focus();	return false;	}
if(nice.acc_br.value=='')	{	alert("Enter Bank Branch Name");	nice.acc_br.focus();	return false;	}
if(nice.acc_ty.value=='')	{	alert("Enter Account Type");	nice.acc_ty.focus();	return false;	}
if(nice.refer_id.value=='')	{	alert("Enter Refer ID");	nice.refer_id.focus();	return false;	}
if(nice.sponsor_id.value=='')	{	alert("Enter Sponsor ID");	nice.sponsor_id.focus();	return false;	}
if(nice.method.value=='')	{	alert("Select User Method");	nice.method.focus();	return false;	}
}	</script>