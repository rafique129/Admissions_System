<?php session_start();
session_destroy();
?>
<script>
window.location.href="website_c.php";
</script>