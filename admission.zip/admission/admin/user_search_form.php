<form method="post">
<tr>
<td>User:</td>
<td>
<select name="sno" onChange="this.form.submit();">
<option value="">--Select--</option>
<?php $select_group_id=mysql_query("select * from $table4"); while ($select_group_id_array=mysql_fetch_array($select_group_id)) { ?>
<option value="<?php echo $select_group_id_array['sno']; ?>" <?php if ($select_group_id_array['sno']==$sno) { echo ' selected="selected"'; } ?>><?php echo new_number($select_group_id_array[sno],$table4); /*?>, <?php echo $select_group_id_array[name];*/ ?></option>
<?php } ?>
</select>
</td>
</tr>
</form>