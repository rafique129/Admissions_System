<table align="left" cellpadding="5" cellspacing="0" border="0" width="100%"><tr valign="top"><td>
<div id="colortab" class="ddcolortabs">
<ul>
<?php if(($_SESSION[$admin_session]!='')){?><li><a href="#" rel="dropmenu1_super" class="white"><span>Settings</span></a></li>
<li><a href="#" rel="dropmenu1_3" class="white"><span>Course</span></a></li><?php }?>
<li><a href="#" rel="dropmenu1_2" class="white"><span>Admission</span></a></li>
<?php if(($_SESSION[$admin_session]!='')){?><li><a href="#" rel="dropmenu1_5" class="white"><span>Announcement</span></a></li><?php }?>
<li><a href="feedback.php" class="white"><span>Feedback</span></a></li>
<li><a href="logout<?php if(($_SESSION[$admin_session]=='')){echo '_1';}?>.php" rel="dropmenu1_z" class="white"><span>Logout</span></a></li>
</ul>
</div>

<div id="dropmenu1_super" class="dropmenudiv_a">
<a href="change_password.php">Change Password</a>
</div>

<div id="dropmenu1_3" class="dropmenudiv_a">
<a href="new_course.php">Add New Course</a>
<a href="course_list.php">Course List</a>
</div>


<div id="dropmenu1_2" class="dropmenudiv_a">
<?php if(($_SESSION[$admin_session]!='')){?><a href="user_add.php">New Student Admission</a><?php }?>
<a href="user_edit.php">Edit Student</a>
<a href="user_view.php">View Student</a>
<a href="user_list.php">Student List</a>
<?php /*<a href="user_search.php">Student Search</a>*/?>
</div>

<div id="dropmenu1_5" class="dropmenudiv_a">
<a href="edit_latest_news.php">View / Edit Announcement</a>
</div>

<script type="text/javascript">
//SYNTAX: tabdropdown.init("menu_id", [integer OR "auto"])
tabdropdown.init("colortab", 3)
</script>	<br>
<br>
</td>



<td align="right">
<?php if(($_SESSION[$admin_session]!='')){$cccc=1;}else{$cccc=2;}?>

<?php

$las=mysql_fetch_array(mysql_query("select * from $table1 where slno='$cccc'"));
?>
Last Login: <?php echo $las['l_login']; ?>
<br />
Now Login: <?php echo $las['n_login']; ?>
<br />
Total Login: <?php echo $las['ennu']; ?>
</td>

</tr></table>

