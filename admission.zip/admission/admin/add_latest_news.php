<?php include "include/db.php";
?>
<?php if($_SESSION[$admin_session]=='') { ?><script>window.location.href="website.php";</script><?php } else { ?>

<?php
if(isset($_REQUEST['add_latest_news']))
{
$title=$_REQUEST['title'];
$content=$_REQUEST['content'];
mysql_query("insert into $table9 (title,content,date,active) values ('$title','$content','$dated','1')");
?><script>window.location.href="<?php echo $_SERVER['PHP_SELF']; ?>?added=1";</script>
<?php } ?>

<?php 
include "header1.php"; 
?>
<tr>
<td colspan="5" height="5">
<?php
include "dropdown.php"; 
?>
</td>
</tr>
<tr>
  <td colspan="3" valign="top" align="center">
  
  <table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:px solid #000000">

<tr bgcolor="#">

<td colspan="2" align="center">

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="18"><img src="images/blue_left1.jpg" width="18" height="34" /></td>
<td colspan="2" background="images/blue_center.jpg"><div class="user_head">PUBLISH NEW ANNOUNCEMENT </div></td>
<td valign="top" align="right" width="18"><img src="images/blue_right1.jpg" width="18" height="34" /></td>
</tr>
</table>

</td>
</tr>


<tr><td colspan="2" align="center">
<table border="0" align="center" cellpadding="10" cellspacing="0" width="500">

<form name="latest_form" action="<?php $_SERVER['PHP_SELF'];?>" method="post">
<?php if ($_REQUEST['added']=='1') { ?><tr><td colspan="2" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><strong>Your News Has Been Added</strong></font></td></tr><?php } ?>
<tr>
<td class="welcome">Title:</td>
<td><input type="text" name="title" /></td>
</tr>
<tr>
<td class="welcome">Text:</td>
<td><textarea name="content" cols="40" rows="10"></textarea></td>
</tr>

<tr>
<td colspan="2" align="center"><input type="submit" name="add_latest_news" value="Add News"></td>
</tr>
</form>
</table>
</td></tr>


</table>
  
  
  </td>
</tr>
</table>
<?php
include "footer.php";
?>
<?php } ?>