<?php include"header.php"; ?>
<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="14"><img src="images/orange_left.png" width="14" height="43" /></td>
<td style="background:url(images/orange_center.jpg)" class="mtitle"><img src="images/arrow.png" align="absmiddle" /> My Account</td>
<td width="14" align="right"><img src="images/orange_right.png" width="14" height="43" /></td>
</tr>
<tr bgcolor="#FFFFFF">
<td></td>
<td valign="top" class="text">

<?php if ($_SESSION['resort_user_login']=='') { echo '<script>window.location.href="website.php";</script>'; } else { ?>
<?php $welcome=''; include "member.php"; ?>
<?php
$my_account=mysql_fetch_array(mysql_query("select * from $table4 where sno='$main_sno'"));
?>

<?php /*<table style="background:url(images/frame_border.png) no-repeat" align="center" cellpadding="0" cellspacing="0" width="680" height="917">*/?>
<table align="center" cellpadding="0" cellspacing="0" width="680" height="917">
<tr><td height="50"></td></tr>
<tr>
<td valign="top">

<table align="center" width="100%">
  <tbody>
    <tr>
      <td class="account" align="center" valign="top"><font size="3"><strong><u>Students Page</u></strong></font></td>
    </tr>
    <tr>
      <td align="right" valign="top"><p style="padding-right:50px;"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Date : <?php echo date_only($my_account['dated']); ?></font></p></td>
    </tr>
    <tr>
      <td class="account" align="center">------------------------------------------------------------------------------------------------------------------------------</td>
    </tr>
    <tr>
      <td class="account" align="center" valign="top"><p> <strong>CONGRATULATIONS!</strong></p></td>
    </tr>
    <tr>
      <td class="account" align="center"><strong> YOU HAVE SUCCESSFULLY REGISTERED AS AN APPLICANT WITH US.<br /></strong></td>
    </tr>
    <tr>
      <td class="text" align="center">&nbsp;</td>
    </tr>
    <tr>
      <td class="account" align="center"><strong>WE WARMLY WELCOME YOU TO THE <?php echo $company_name; ?></strong></td>
    </tr>
    <tr>
      <td class="account" align="center">------------------------------------------------------------------------------------------------------------------------------</td>
    </tr>
  </tbody>
</table>
<table align="center" cellpadding="10" cellspacing="0" width="80%">
  <tbody>
    <tr>
      <td class="text"><strong>MEMBER&rsquo;S USER ID</strong> </td>
      <td>:</td>
      <td class="text"><strong><?php echo new_number($main_sno,$table4); ?></strong></td>
    </tr>
    <tr bgcolor="#F2F2F2">
      <td class="text"><strong>NAME </strong></td>
      <td>:</td>
      <td class="text" ><?php echo $my_account['name']; ?></td>
    </tr>
    <tr>
      <td class="text"><strong>ADDRESS </strong></td>
      <td>:</td>
      <td class="text" ><?php echo $my_account['addr1']; ?>,<br /><?php echo $my_account['addr2']; ?></td>
    </tr>
    <tr bgcolor="#F2F2F2">
      <td class="text"><strong>CITY </strong></td>
      <td>:</td>
      <td class="text" ><?php echo $my_account['city']; ?></td>
    </tr>
    <tr>
      <td class="text"><strong>STATE </strong></td>
      <td>:</td>
      <td class="text" ><?php echo $my_account['state']; ?></td>
    </tr>
    <tr bgcolor="#F2F2F2">
      <td class="text"><strong>DEPARTMENT </strong></td>
      <td>:</td>
      <td class="text" ><?php echo $my_account['department']; ?></td>
    </tr>
    <tr>
      <td class="text"><strong>COURSE: </strong></td>
      <td>:</td>
      <td class="text" ><strong><?php echo $my_account['course']; ?></strong></td>
    </tr>
    <tr bgcolor="#F2F2F2">
      <td class="text"><strong>MOBILE NO. </strong></td>
      <td>:</td>
      <td class="text"><?php echo $my_account['mnumber']; ?></td>
    </tr>

    <tr>
      <td class="text"><strong>STATUS: </strong></td>
      <td>:</td>
      <td class="text" ><strong><?php echo $my_account['status']; ?></strong></td>
    </tr>
    <tr bgcolor="#F2F2F2">
      <td class="text"><strong>COMMENTS: </strong></td>
      <td>:</td>
      <td class="text"><?php echo $my_account['comments']; ?></td>
    </tr>
  </tbody>
</table>

</td>
</tr>
</table>
<?php include"footer.php"; } ?>
