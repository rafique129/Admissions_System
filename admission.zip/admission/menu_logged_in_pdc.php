	<style>
		
		/**	style used for both examples **/

		.menu { 
			height: 44px;
			display: block;
		}

		.menu ul {
			list-style: none;
			padding: 0;
			margin: 0;
		}

		.menu ul li {
			/* width and height of the menu items */  
			float: left;
			overflow: hidden;
			position: relative;
			text-align: center;
			line-height: 40px;
		}

		.menu ul li a {
			/* must be postioned relative  */ 
			position: relative;
			display: block;
			width: 142px;
			height: 44px;
			font-family: Arial;
			font-size: 12px;
			font-weight: bold;
			letter-spacing: 1px;
			text-transform: uppercase;
			text-decoration: none;
			cursor: pointer;
		}

		.menu ul li a span {
			/* all layers will be absolute positioned */
			position: absolute;
			left: 0;
			width: 142px;
		}

		.menu ul li a span.out {
			top: 0px;
		}

		.menu ul li a span.over,
		.menu ul li a span.bg {
			/* hide */  
			top: -44px;
		}

		/** 1st example **/

		#menu {
			background: #EEE;
		}

		#menu ul li a {
			color: #000;
		}

		#menu ul li a span.over {
			color: #FFF;
		}

		#menu ul li span.bg {
			/* height of the menu items */  
			height: 44px;
			background: url('bg_over.gif') center center no-repeat;
		}
		
		/** 2nd example **/

		#menu2 {
			background:url(images/menu_back.jpg);
			height:44px;
		}
		
		#menu2 ul li a {
			color: #FFF;
		}

		#menu2 ul li a span.over {
			background:url(images/menu_back_hover.jpg);
			color: #000;
			height:44px;
		}

	</style>
	<script type="text/javascript" src="../jquery.min.js"></script>
	<script language="javascript">
		$(document).ready(function() {

			/* 	1st example	*/

			/// wrap inner content of each anchor with first layer and append background layer
			$("#menu li a").wrapInner( '<span class="out"></span>' ).append( '<span class="bg"></span>' );

			// loop each anchor and add copy of text content
			$("#menu li a").each(function() {
				$( '<span class="over">' +  $(this).text() + '</span>' ).appendTo( this );
			});

			$("#menu li a").hover(function() {
				// this function is fired when the mouse is moved over
				$(".out",	this).stop().animate({'top':	'45px'},	250); // move down - hide
				$(".over",	this).stop().animate({'top':	'0px'},		250); // move down - show
				$(".bg",	this).stop().animate({'top':	'0px'},		120); // move down - show

			}, function() {
				// this function is fired when the mouse is moved off
				$(".out",	this).stop().animate({'top':	'0px'},		250); // move up - show
				$(".over",	this).stop().animate({'top':	'-45px'},	250); // move up - hide
				$(".bg",	this).stop().animate({'top':	'-45px'},	120); // move up - hide
			});
					

			/*	2nd example	*/
			
			$("#menu2 li a").wrapInner( '<span class="out"></span>' );
			
			$("#menu2 li a").each(function() {
				$( '<span class="over">' +  $(this).text() + '</span>' ).appendTo( this );
			});

			$("#menu2 li a").hover(function() {
				$(".out",	this).stop().animate({'top':	'44px'},	200); // move down - hide
				$(".over",	this).stop().animate({'top':	'0px'},		200); // move down - show

			}, function() {
				$(".out",	this).stop().animate({'top':	'0px'},		200); // move up - show
				$(".over",	this).stop().animate({'top':	'-44px'},	200); // move up - hide
			});

		});

	</script>

<div id="menu2" class="menu">
			<ul>
<!--				<li><a href="my_account.php">Welcome</a></li>-->
				<li><a href="profile.php">Profile</a></li>
				<li><a href="pin_transfer.php">PINs Account</a></li>				
				<li><a href="pin_transfered.php">Reports</a></li>
				<li><a href="#">Mail</a></li>
				<li><a href="modify_password.php">Password</a></li>
				<li><a href="logout.php">Logout</a></li>								
			</ul>
	  </div>    