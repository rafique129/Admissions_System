<table align="center" cellpadding="0" cellspacing="0">
<tr>
<td style="background:url(images/menu_01.png) no-repeat;" width="120" height="43" align="center"><a href="my_account.php" class="menu">My Account</a></td>
<td style="background:url(images/menu_02.png) no-repeat;" width="120" height="43" align="center"><a href="profile.php" class="menu">Profile</a></td>
<td style="background:url(images/menu_02.png) no-repeat;" width="120" height="43" align="center"><a href="edit_profile.php" class="menu">Edit Profile</a></td>
<td style="background:url(images/menu_02.png) no-repeat;" width="120" height="43" align="center"><a href="admit_status.php" class="menu">Admission Status</a></td>
<td style="background:url(images/menu_02.png) no-repeat;" width="120" height="43" align="center"><a href="modify_password.php" class="menu">Password</a></td>
<td style="background:url(images/menu_02.png) no-repeat;" width="120" height="43" align="center"><a href="#" class="menu">Contact Us</a></td>
<td style="background:url(images/menu_02.png) no-repeat;" width="120" height="43" align="center"><a href="javascript:void(0)" onclick="window.open('feedback.php', 'newwindow', 'width=1002,height=471,scrollbars=yes,resizable=no')" class="menu">Feedback</a></td>
<td style="background:url(images/menu_03.png) no-repeat; background-position:right;" width="242" height="43" align="center"><a href="logout.php" class="menu">Logout</a></td>
</tr>
</table>
