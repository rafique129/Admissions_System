<?php include"header.php"; ?>

<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="14"><img src="images/orange_left.png" width="14" height="43" /></td>
<td style="background:url(images/orange_center.jpg)" class="mtitle"><img src="images/arrow.png" align="absmiddle" /> My Profile</td>
<td width="14" align="right"><img src="images/orange_right.png" width="14" height="43" /></td>
</tr>
<tr bgcolor="#FFFFFF">
<td></td>
<td valign="top" class="text">

<?php if ($_SESSION['resort_user_login']=='') { echo '<script>window.location.href="website.php";</script>'; } else { ?>
<?php $welcome='My Profile '; include "member.php"; ?>
<?php $ed_ge=mysql_fetch_array(mysql_query("select * from $table4 where sno='$main_sno'")); ?>

<?php include "for_profile.php"; ?>

<table align="center" cellpadding="5" cellspacing="5" width="100%" style="border:1px solid #447322;">

<tr bgcolor="#447322">
<td colspan="2" valign="top" class="mtitle">
<strong>Account Details</strong>
</td>
</tr>
<tr>
<td class="text" width="150">Username:</td>
<td class="text"><?php echo new_number($main_sno,$table4);//echo $ed_ge['sno']; ?></td>
</tr>
<tr bgcolor="#F2F2F2">
<td class="text">Password:</td>
<td class="text">********</td>
</tr>

<tr><td colspan="2" align="center"><br /></td></tr>

<tr bgcolor="#447322">
<td colspan="2" valign="top" class="mtitle">
<strong>Personal Details</strong>
</td>
</tr>

<tr>
<td class="text">Name:</td>
<td class="text"><?php echo $ed_ge['name']; ?></td>
</tr>
<!--<tr>
<td class="text">Maiden Name:</td>
<td class="text"><?php echo $ed_ge['mname']; ?></td>
</tr>-->
<tr bgcolor="#F2F2F2">
<td class="text">Date of Birth:</td>
<td class="text"><?php echo date_only($ed_ge['dob']); ?></td>
</tr>
<tr>
<td class="text">Sex:</td>
<td class="text"><?php echo ucfirst($ed_ge['sex']); ?></td>
</tr>
<tr bgcolor="#F2F2F2">
<td class="text">Address 1:</td>
<td class="text"><?php echo $ed_ge['addr1']; ?></td>
</tr>
<tr>
<td class="text">Address 2:</td>
<td class="text"><?php echo $ed_ge['addr2']; ?></td>
</tr>
<tr bgcolor="#F2F2F2">
<td class="text">City:</td>
<td class="text"><?php echo $ed_ge['city']; ?></td>
</tr>
<tr>
<td class="text">State:</td>
<td class="text"><?php echo $ed_ge['state']; ?></td>
</tr>
<tr bgcolor="#F2F2F2">
<td class="text">Country:</td>
<td class="text"><?php echo $ed_ge['country']; ?></td>
</tr>
<tr>
<td class="text">Postal Code:</td>
<td class="text"><?php echo $ed_ge['post_code']; ?></td>
</tr>
<tr bgcolor="#F2F2F2">
<td class="text">Mobile Number:</td>
<td class="text"><?php echo $ed_ge['mnumber']; ?></td>
</tr>
<tr>
<td class="text">Telephone Number:</td>
<td class="text"><?php echo $ed_ge['tnumber']; ?></td>
</tr>

<tr bgcolor="#447322">
<td class="text" style="color:#FFFFFF;" colspan="2"><strong>Mark Information</strong></td>
</tr>

<tr>
<td class="text">Maths:</td>
<td class="text"><?php echo $ed_ge['m_1']; ?></td>
</tr>
<tr bgcolor="#F2F2F2">
<td class="text">English:</td>
<td class="text"><?php echo $ed_ge['m_2']; ?></td>
</tr>
<tr>
<td class="text"><label>
  <select name="subject 3" size="1" id="subject 3">
    <option selected="selected">Select Subject</option>
    <option>Physics</option>
    <option>Chemistry</option>
    <option>Biology</option>
    <option>Commerce</option>
    <option>Accounting</option>
    <option>Home Management</option>
    <option>Futher Maths</option>
    <option>Geography</option>
    <option>Technical Drawing</option>
  </select>
</label></td>
<td class="text"><?php echo $ed_ge['m_3']; ?></td>
</tr>
<tr bgcolor="#F2F2F2">
<td class="text"><label>
  <select name="subject 4" size="1" id="subject 4">
    <option selected="selected">Select Subject</option>
    <option>Physics</option>
    <option>Chemistry</option>
    <option>Biology</option>
    <option>Technical Drawing</option>
    <option>Geography</option>
    <option>Commerce</option>
    <option>Accounting</option>
    <option>Home Management</option>
  </select>
</label></td>
<td class="text"><?php echo $ed_ge['m_4']; ?></td>
</tr>
<tr>
<td class="text"><label>
  <select name="subject 5" size="1" id="subject 5">
    <option selected="selected">Select Subject</option>
    <option>Physics</option>
    <option>Chemistry</option>
    <option>Futher Maths</option>
    <option>Home Management</option>
    <option>Technical Drawing</option>
    <option>Government</option>
    <option>Commerce</option>
    <option>Accounting</option>
  </select>
</label></td>
<td class="text"><?php echo $ed_ge['m_5']; ?></td>
</tr>

<tr>
<td class="text">Your Score:</td>
<td class="text"><?php echo $ed_ge['score']; ?></td>
</tr>

</table>


<?php include"footer.php"; } ?>