<?php session_start(); ?>
<?php include"header.php"; ?>
<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="14"><img src="images/orange_left.png" width="14" height="43" /></td>
<td style="background:url(images/orange_center.jpg)" class="mtitle"><img src="images/arrow.png" align="absmiddle" /> Contact Us</td>
<td width="14" align="right"><img src="images/orange_right.png" width="14" height="43" /></td>
</tr>
<tr bgcolor="#FFFFFF">
<td></td>
<td valign="top" class="text">
<br />
<p align="center">Anglia Ruskin University<br />
  <br />
 
  TELEPHONE: 01223 123456 <br />
  EMAIL: taraba@tsu.com</p>
 <table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td>
</td>
<td valign="top"><?php include"enquiry.php"; ?></td>
</tr>
</table>
<p></p>
<p>
  <?php include"footer.php"; ?>
</p>
