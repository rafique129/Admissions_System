<HEAD>

<SCRIPT LANGUAGE="JavaScript">

<!-- This script and many more are available free online at -->
<!-- The JavaScript Source!! http://javascript.internet.com -->

<!-- Begin
var ans = new Array;
var done = new Array;
var yourAns = new Array;
var explainAnswer = new Array;

var score = 0;
ans[1] = "c";
ans[2] = "a";
ans[3] = "c";
ans[4] = "a";
ans[5] = "b";

explainAnswer[1]="The reason why Answer 1 is Blah Blah Blah";
explainAnswer[2]="The reason why Answer 2 is Blah Blah Blah";
explainAnswer[3]="The reason why Answer 3 is Blah Blah Blah";
explainAnswer[4]="The reason why Answer 4 is Blah Blah Blah";
explainAnswer[5]="The reason why Answer 5 is Blah Blah Blah";

function Engine(question, answer) {
yourAns[question]=answer;
}

function Score(){
var answerText = "How did you do?\n------------------------------------\n";
for(i=1;i<=5;i++){
   answerText=answerText+"\nQuestion :"+i+"\n";
  if(ans[i]!=yourAns[i]){
    answerText=answerText+"\nThe correct answer was "+ans[i]+"\n"+explainAnswer[i]+"\n";
  }
  else{
    answerText=answerText+" \nCorrect! \n";
    score++;
  }
}

answerText=answerText+"\n\nYour total score is : "+score+"\n";

//now score the user
answerText=answerText+"\nComment : ";
if(score<=0){
answerText=answerText+"You need to learn more";
}
if(score>=1 && score <=2){
answerText=answerText+"Need bit more practice";
}
if(score>=3 && score <=3){
answerText=answerText+"You are doing ok";
}
if(score>4){
answerText=answerText+"You are one hot IT guru!";
}

alert(answerText);
window.location.href="online_testing.php?score="+score;
}
//  End -->
</script>

</HEAD>

<!-- STEP TWO: Copy this code into the BODY of your HTML document  -->

<BODY>

<DIV ALIGN="CENTER">
<h1>ONLINE TEST</h1>
<b>Test your knowledge of IT!</b>
<hr>
<FORM>
<b>1. It is a global system of interconnected computer networks that use the standard Internet protocol suite (TCP/IP) to serve billions of users worldwide</b><br>
<input type=radio name="q1" value="a" onClick="Engine(1, this.value)">a) Facebook<br>
<input type=radio name="q1" value="b" onClick="Engine(1, this.value)">b) Twitter<br>
<input type=radio name="q1" value="c" onClick="Engine(1, this.value)">c) Internet<br>
<input type=radio name="q1" value="d" onClick="Engine(1, this.value)">d) Telephone<p>
<b>2. Which of the below is not an iPhone 4 feature?</b><br>
<input type=radio name="q2" value="a" onClick="Engine(2, this.value)">a) 4G<br>
<input type=radio name="q2" value="b" onClick="Engine(2, this.value)">b) Front facing camera<br>
<input type=radio name="q2" value="c" onClick="Engine(2, this.value)">c) HD recording<br>
<input type=radio name="q2" value="d" onClick="Engine(2, this.value)">d) Multitasking<p>
<b>3. When was the first e-mail sent?</b><br>
<input type=radio name="q3" value="a" onClick="Engine(3, this.value)">a) 1963<br>
<input type=radio name="q3" value="b" onClick="Engine(3, this.value)">b) 1969<br>
<input type=radio name="q3" value="c" onClick="Engine(3, this.value)">c) 1971<br>
<input type=radio name="q3" value="d" onClick="Engine(3, this.value)">d) 1974<p>
<b>4. Which of the below media types hold the most information?</b><br>
<input type=radio name="q4" value="a" onClick="Engine(4, this.value)">a) Blue-ray<br>
<input type=radio name="q4" value="b" onClick="Engine(4, this.value)">b) CD<br>
<input type=radio name="q4" value="c" onClick="Engine(4, this.value)">c) Floppy Diskette<br>
<input type=radio name="q4" value="d" onClick="Engine(4, this.value)">d) DVD<p>
<b>5. Which of the below versions of widows was the first to be released after Windows 98?</b><br>
<input type=radio name="q5" value="a" onClick="Engine(5, this.value)">a) Windows 99<br>
<input type=radio name="q5" value="b" onClick="Engine(5, this.value)">b) Windows 2000<br>
<input type=radio name="q5" value="c" onClick="Engine(5, this.value)">c) Windows ME<br>
<input type=radio name="q5" value="d" onClick="Engine(5, this.value)">d) Windows XP<p>
<CENTER>
<input type=button onClick="Score()" value="Well... How did I do?">
</CENTER>
</FORM>
</DIV>


