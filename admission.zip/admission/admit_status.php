<?php include"header.php"; ?>

<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="14"><img src="images/orange_left.png" width="14" height="43" /></td>
<td style="background:url(images/orange_center.jpg)" class="mtitle"><img src="images/arrow.png" align="absmiddle" /> Admission Status</td>
<td width="14" align="right"><img src="images/orange_right.png" width="14" height="43" /></td>
</tr>
<tr bgcolor="#FFFFFF">
<td></td>
<td valign="top" class="text">

<?php if ($_SESSION['resort_user_login']=='') { echo '<script>window.location.href="website.php";</script>'; } else { ?>
<?php $welcome=''; include "member.php"; ?>
<?php
$my_account=mysql_fetch_array(mysql_query("select * from $table4 where sno='$main_sno'"));
?>

<?php //include "for_profile.php"; ?>

<table align="center" cellpadding="5" cellspacing="5" width="100%" style="border:1px solid #447322;">

<tr bgcolor="#447322">
<td colspan="2" valign="top" class="mtitle">
<strong>ADMISSION STATUS AND COMMENTS</strong>
</td>
</tr>

    <tr bgcolor="#F2F2F2">
      <td class="text" width="200"><strong>ADMISSION STATUS: </strong></td>
      <td class="text" ><strong><?php echo $my_account['status']; ?></strong></td>
    </tr>
    <tr bgcolor="#F2F2F2">
      <td class="text"><strong>COMMENTS: </strong></td>
      <td class="text"><?php echo $my_account['comments']; ?></td>
    </tr>
</table>


<?php include"footer.php"; } ?>