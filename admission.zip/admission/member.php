<table width="100%" cellpadding="0" cellspacing="0">
<tr>
<td align="left"><h4 class="welcome"><?php echo $welcome; ?> Student ID and Name : <?php echo new_number($main_sno,$table4); ?></h4></td>
<td align="right"><h4 class="welcome">Name : <?php echo kandu_pidi_new($main_sno,$table4,name,sno); ?></h4></td>
</tr>
</table>
