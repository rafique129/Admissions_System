<?php include"header.php"; ?>
<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="14"><img src="images/orange_left.png" width="14" height="43" /></td>
<td style="background:url(images/orange_center.jpg)" class="mtitle"><img src="images/arrow.png" align="absmiddle" /> Edit Profile</td>
<td width="14" align="right"><img src="images/orange_right.png" width="14" height="43" /></td>
</tr>
<tr bgcolor="#FFFFFF">
<td></td>
<td valign="top" class="text">


<?php if ($_SESSION['resort_user_login']=='') { echo '<script>window.location.href="website.php";</script>'; } else { ?>
<style>
select.simple_da {font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px;}
</style>
<?php
if (isset($_REQUEST['edit_per'])) {
$name=$_REQUEST['name'];
$mname=$_REQUEST['mname'];
//$dob=$_REQUEST['dob'];
$year_da=$_REQUEST['year_da'];
$month_da=$_REQUEST['month_da'];
$date_da=$_REQUEST['date_da'];
$dob=$year_da.'-'.$month_da.'-'.$date_da;

$sex=$_REQUEST['sex'];
$addr1=$_REQUEST['addr1'];
$addr2=$_REQUEST['addr2'];
$city=$_REQUEST['city'];
$state=$_REQUEST['state'];
$country=$_REQUEST['country'];
$post_code=$_REQUEST['post_code'];
$mnumber=$_REQUEST['mnumber'];
$tnumber=$_REQUEST['tnumber'];
$nominee=$_REQUEST['nominee'];
$rnominee=$_REQUEST['rnominee'];
$pan_number=$_REQUEST['pan_number'];

$acc_no=$_REQUEST['acc_no'];
$acc_na=$_REQUEST['acc_na'];
$acc_ba=$_REQUEST['acc_ba'];
$acc_br=$_REQUEST['acc_br'];
$acc_ty=$_REQUEST['acc_ty'];
$acc_if=$_REQUEST['acc_if'];

/*mysql_query("update $jws_b3table set email='$email',password='$password',name='$name',mname='$mname',dob='$dob',sex='$sex',addr1='$addr1',addr2='$addr2',city='$city',state='$state',country='$country',post_code='$post_code',mnumber='$mnumber',tnumber='$tnumber',nominee='$nominee',rnominee='$rnominee',pan_number='$pan_number',acc_no='$acc_no',acc_na='$acc_na',acc_ba='$acc_ba',acc_br='$acc_br',acc_ty='$acc_ty',acc_if='$acc_if' where sno='$sno'") or die (mysql_error()); echo $loading_code; */
mysql_query("update $table4 set name='$name',dob='$dob',sex='$sex',addr1='$addr1',addr2='$addr2',city='$city',state='$state',country='$country',post_code='$post_code',mnumber='$mnumber',tnumber='$tnumber',nominee='$nominee',rnominee='$rnominee',pan_number='$pan_number',acc_no='$acc_no',acc_na='$acc_na',acc_ba='$acc_ba',acc_br='$acc_br',acc_ty='$acc_ty',acc_if='$acc_if' where sno='$main_sno'") or die (mysql_error()); echo $loading_code; ?> <script>window.location.href="profile.php?added=1&page=<?php echo $page; ?>";</script> <?php } ?>


<?php $welcome='Edit Profile '; include "member.php"; ?>
<?php $ed_ge=mysql_fetch_array(mysql_query("select * from $table4 where sno='$main_sno'")); ?>

<div style="padding:10px;" align="center"><?php include "for_profile.php"; ?></div>

<table align="center" cellpadding="5" cellspacing="5" width="100%" style="border:1px solid #447322;">

<?php if ($_REQUEST['added']=='1') { ?><tr><td colspan="2" align="center" class="text">Your Information Has Been Updated</td>
</tr><?php } ?>

<form name="edit_personal_details" action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" onSubmit="return validation_edit_per();">
<tr bgcolor="#447322">
<td colspan="2" valign="top" class="mtitle">
<strong>Personal Details</strong>
</td>
</tr>

<tr>
<td class="text">Name*:</td>
<td class="text"><input type="text" name="name" readonly="" value="<?php echo $ed_ge['name']; ?>" /></td>
</tr>
<!--<tr><td>Maiden Name:</td><td><input type="text" name="mname" value="<?php echo $ed_ge['mname']; ?>" /></td></tr>-->
<tr bgcolor="#F2F2F2">
<td class="text">Date of Birth*:</td>
<td class="text"><?php $piri=explode("-",$ed_ge['dob']); $year_da=$piri[0];$month_da=$piri[1];$date_da=$piri[2]; ?>
<select name="date_da" class="simple_da"><?php for ($h = 01; $h < 32; $h++){ ?><option value="<?php echo "$h"; ?>"<?php if($h==$date_da){echo $sel;}?>><?php echo $h; ?></option><?php } ?></select>
<select name="month_da" class="simple_da"><?php for ($i = 01; $i < 13; $i++){ ?><option value="<?php echo "$i"; ?>"<?php if($i==$month_da){echo $sel;}?>><?php echo $i; ?></option><?php } ?></select>
<select name="year_da" class="simple_da"><?php for ($j = 1925; $j < 2012; $j++){ ?><option value="<?php echo "$j"; ?>"<?php if($j==$year_da){echo $sel;}?>><?php echo $j; ?></option><?php } ?></select>
</td>
</tr>
<tr>
<td class="text">Sex*:</td>
<td class="text"><input type="radio" name="sex" value="male" <?php if ($ed_ge['sex']=='male') { echo $checked_value; } ?> />Male,&nbsp;&nbsp;&nbsp;<input type="radio" name="sex" value="female" <?php if ($ed_ge['sex']=='female') { echo $checked_value; } ?> />Female</td>
</tr>
<tr bgcolor="#F2F2F2">
<td class="text">Address First Line*:</td>
<td class="text"><input type="text" name="addr1" value="<?php echo $ed_ge['addr1']; ?>" /></td>
</tr>
<tr>
<td class="text">Address Second Line:</td>
<td class="text"><input type="text" name="addr2" value="<?php echo $ed_ge['addr2']; ?>" /></td>
</tr>
<tr bgcolor="#F2F2F2">
<td class="text">City*:</td>
<td class="text"><input type="text" name="city" value="<?php echo $ed_ge['city']; ?>" /></td>
</tr>
<tr>
<td class="text">State*:</td>
<td class="text"><input type="text" name="state" value="<?php echo $ed_ge['state']; ?>" /></td>
</tr>
<tr bgcolor="#F2F2F2">
<td class="text">Country*:</td>
<td class="text"><input type="text" name="country" value="<?php echo $ed_ge['country']; ?>" /></td>
</tr>
<tr>
<td class="text">Postal Code*:</td>
<td class="text"><input type="text" name="post_code" value="<?php echo $ed_ge['post_code']; ?>" /></td>
</tr>
<tr bgcolor="#F2F2F2">
<td class="text">Mobile Number*:</td>
<td class="text"><input type="text" name="mnumber" value="<?php echo $ed_ge['mnumber']; ?>" /></td>
</tr>
<tr>
<td class="text">Telephone Number:</td>
<td class="text"><input type="text" name="tnumber" value="<?php echo $ed_ge['tnumber']; ?>" /></td>
</tr>


<?php /*
<tr>
<td class="text">Account No*:</td>
<td class="text"><input type="text" name="acc_no" class="small" value="<?php echo $ed_ge['acc_no']; ?>" /></td></tr>
<tr bgcolor="#F2F2F2">
<td class="text">Account Holder Name*:</td>
<td class="text"><input type="text" name="acc_na" readonly="" class="small" value="<?php echo $ed_ge['acc_na']; ?>" /></td></tr>
<tr>
<td class="text">Bank Name*:</td>
<td class="text"><input type="text" name="acc_ba" class="small" value="<?php echo $ed_ge['acc_ba']; ?>" /></td></tr>
<tr bgcolor="#F2F2F2">
<td class="text">Branch*:</td>
<td class="text"><input type="text" name="acc_br" class="small" value="<?php echo $ed_ge['acc_br']; ?>" /></td></tr>
<tr>
<td class="text">Account Type*:</td>
<td class="text"><select name="acc_ty"><option value="">--Select--</option><option  <?php if ($ed_ge['acc_ty']=='current') { echo $selected_value; } ?> value="current">Current</option><option value="saving" <?php if ($ed_ge['acc_ty']=='saving') { echo $selected_value; } ?>>Saving</option></select></td></tr>
<tr bgcolor="#F2F2F2">
<td class="text">IFSC Code:</td>
<td class="text"><input type="text" name="acc_if" class="small" value="<?php echo $ed_ge['acc_if']; ?>" /></td></tr>
<tr>
<td class="text">Refferal ID:</td>
<td class="text"><input type="text" class="small" readonly="" value="<?php echo $ed_ge['refer_id']; ?>" /></td></tr>
*/?>
<tr bgcolor="#F2F2F2">
<td colspan="2" style="text-align:center;" class="text"><input type="submit" name="edit_per" value="Update" /></td>
</tr>
<tr><td colspan="2" height="10"></td></tr>
</form>

<?php /*
<tr>
<td class="text">Reffer ID:</td>
<td class="text"><a href="<?php echo $link_for_reg; ?>new_register.php?ref=<?php echo $ed_ge['sno']; ?>" target="_blank"><?php echo $link_for_reg; ?>new_register.php?ref=<?php echo $ed_ge['sno']; ?></a></td>
</tr>
*/ ?>
</table>

<script language="javascript">	function validation_edit_per()	{	var nice=document.edit_personal_details;		if(nice.name.value=='')	{	alert("Enter Your Name");	nice.name.focus();	return false;	}/*	if(nice.mname.value=='')	{	alert("Enter Your Maiden Name");	nice.mname.focus();	return false;	}*/	if(nice.addr1.value=='')	{	alert("Enter Address First Line");	nice.addr1.focus();	return false;	}	if(nice.city.value=='')	{	alert("Enter Your City");	nice.city.focus();	return false;	}	if(nice.state.value=='')	{	alert("Enter Your State");	nice.state.focus();	return false;	}	if(nice.country.value=='')	{	alert("Enter Your Country");	nice.country.focus();	return false;	}	if(nice.post_code.value=='')	{	alert("Enter Your Post Code");	nice.post_code.focus();	return false;	}	if(nice.mnumber.value=='')	{	alert("Enter Your Mobile Number");	nice.mnumber.focus();	return false;	}	/*if(nice.tnumber.value=='')	{	alert("Enter Your Telephone Number");	nice.tnumber.focus();	return false;	}	*/if(nice.nominee.value=='')	{	alert("Enter Your Nominee");	nice.nominee.focus();	return false;	}	if(nice.rnominee.value=='')	{	alert("Enter Your Nominee Relation");	nice.rnominee.focus();	return false;	}			}	</script>

<?php include"footer.php"; } ?>