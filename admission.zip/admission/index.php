<?php include"header.php"; ?>
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	left:206px;
	top:548px;
	width:476px;
	height:291px;
	z-index:1;
}
#Layer2 {
	position:absolute;
	left:692px;
	top:552px;
	width:218px;
	height:252px;
	z-index:2;
}
-->
</style>



<div id="Layer1">
  <p align="justify">Welcome! It is  with great pleasure that I extend a very warm welcome to you from Anglia Ruskin University. It is my hope that this website will meet your information needs  and, for those unfamiliar with Kaduna University, provide a comprehensive  introduction to our work, our aspirations and achievements and to the many  opportunities we offer for partnership and participation in the pursuit of our  goals. <br />
    Through the efforts of a dedicated and talented  staff, the University has established itself as a  progressive and successful centre of higher education and earned its current  position among the front rank of Universitys in the world. Our success serves  further to fuel our ambition as we increase our service to society - locally,  nationally and internationally. </p>
  <div align="justify">As the University intensifies efforts towards the much talked about golden jubilee (this year),  several committees have swung into action to ensure that the grand event befits  the 50th anniversary of the largest technical institution in sub-saharan Africa.</div>
</div>
<div id="Layer2">
  <p><img src="images/Haj. Rabi Bobboi.jpg" alt="Rector" width="205" height="236" /></p>
  <p>&nbsp; &nbsp; &nbsp;<strong>Haj. Rabi Bobboi Ibrahim &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Rector) </strong></p>
</div>
<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="14"><img src="images/orange_left.png" width="14" height="43" /></td>
<td style="background:url(images/orange_center.jpg)" class="mtitle"><img src="images/arrow.png" align="absmiddle" /> Welcome</td>
<td width="14" align="right"><img src="images/orange_right.png" width="14" height="43" /></td>
</tr>
<tr bgcolor="#FFFFFF">
<td></td>
<td valign="top">
  <p><br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      </p>
  <p>&nbsp;</p>
  <p><br />
    
    <?php include"footer.php"; ?></p>
  