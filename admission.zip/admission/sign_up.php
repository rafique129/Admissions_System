<?php include"header.php"; ?>
<?php
if(isset($_REQUEST['add_user']))
{
$email=$_REQUEST['email'];
$password=$_REQUEST['password'];
$name=$_REQUEST['name'];

$year_da=$_REQUEST['year_da'];
$month_da=$_REQUEST['month_da'];
$date_da=$_REQUEST['date_da'];

$dob=$year_da.'-'.$month_da.'-'.$date_da;

//$dob=$_REQUEST['dob'];
$sex=$_REQUEST['sex'];
$addr1=$_REQUEST['addr1'];
$addr2=$_REQUEST['addr2'];
$city=$_REQUEST['city'];
$state=$_REQUEST['state'];
$country=$_REQUEST['country'];
$post_code=$_REQUEST['post_code'];
$mnumber=$_REQUEST['mnumber'];
$tnumber=$_REQUEST['tnumber'];
$nominee=$_REQUEST['nominee'];
$rnominee=$_REQUEST['rnominee'];
$pan_number=$_REQUEST['pan_number'];
$acc_no=$_REQUEST['acc_no'];
$acc_na=$_REQUEST['acc_na'];
$acc_ba=$_REQUEST['acc_ba'];
$acc_br=$_REQUEST['acc_br'];
$acc_ty=$_REQUEST['acc_ty'];
$acc_if=$_REQUEST['acc_if'];
$refer_id=$_REQUEST['refer_id'];
//$sponsor_id=$_REQUEST['sponsor_id'];
$fa_name=$_REQUEST['fa_name'];

//$fran=$_REQUEST['fran'];

if($_REQUEST[dated]==''){$dated=$dated;}else{$dated=$_REQUEST['dated'];}

$dep_cour=$_REQUEST[dep_cour];

$department=kandu_pidi_new($dep_cour,$table9,name,sno);
$course=kandu_pidi_new($dep_cour,$table9,course,sno);

$pin=$_REQUEST['pin'];

$datetimed=$datetime;

$side=$_REQUEST['side'];
$new_sno=$_REQUEST['new_sno'];

$m_1=$_REQUEST['m_1'];
$m_2=$_REQUEST['m_2'];
$m_3=$_REQUEST['m_3'];
$m_4=$_REQUEST['m_4'];
$m_5=$_REQUEST['m_5'];

/*if(mysql_num_rows(mysql_query("select * from $table4 where refer_id='$refer_id'"))>='5') { $error='Refer id already Added 5 Members'; } else */
/*if(mysql_num_rows(mysql_query("select * from $table3 where gen_id='$pin' and user_id=''"))=='0') { $error='Wrong Pin Number Please Try Again'; }*/

$username=strtoupper($_REQUEST['sponsor_id']);
$monthing=substr($username,0,2);
$sponsor_id=substr(substr($username,2),0,-2);
$t_value=substr($username,-2);
/*if(($t_value!=new_con($sponsor_id)) or (mysql_num_rows(mysql_query("select * from $table4 where sno='$sponsor_id' and  months='$monthing'"))==0)){echo '<script>alert("Wrong Sponsor ID Please Try Again");</script>';}else*/

/*if (check_da($sponsor_id,$table4,sno)=='0') { echo '<script>alert("Wrong Sponsor ID Please Try Again");</script>'; } else*/
if (check_da($new_sno,$table4,sno)!='0') { echo '<script>alert("This User ID is already Entered");</script>'; } else {
if (check_da($email,$table4,email)!='0') { echo '<script>alert("This Username is already Entered");</script>'; } else{

/*
$from_gen_id=mysql_fetch_array(mysql_query("select * from $table3 where gen_id='$pin' and user_id=''"));
$amount=$from_gen_id['amount'];
$div_per=$from_gen_id['div_per'];
$lev_per=$from_gen_id['lev_per'];
$spo_per=$from_gen_id['spo_per'];
$tot_per=$from_gen_id['tot_per'];
$months=$from_gen_id['months'];
*/


$months=$_REQUEST[months];

$amount=$default_investment;
$refer_id=pudhu_id_kudu($table4,refer_id,level_id);
$level_id_old=kandu_pidi_new($refer_id,$table4,level_id,sno);
$level_id=$level_id_old+1;
mysql_query("insert into $table4 (sno,email,password,name,dob,sex,addr1,addr2,city,state,country,post_code,mnumber,tnumber,nominee,rnominee,pan_number,acc_no,acc_na,acc_ba,acc_br,acc_ty,acc_if,refer_id,sponsor_id,side,amount,div_per,lev_per,spo_per,months,dated,datetimed,active,level_id,fa_name,tot_per,fran,login_active,department,course,m_1,m_2,m_3,m_4,m_5) values ('$new_sno','$email','$password','$name','$dob','$sex','$addr1','$addr2','$city','$state','$country','$post_code','$mnumber','$tnumber','$nominee','$rnominee','$pan_number','$acc_no','$acc_na','$acc_ba','$acc_br','$acc_ty','$acc_if','$refer_id','$sponsor_id','$side','$amount','$div_per','$lev_per','$spo_per','$months','$dated','$datetimed','1','$level_id','$fa_name','$tot_per','$fran','1','$department','$course','$m_1','$m_2','$m_3','$m_4','$m_5')") or die (mysql_error());

$updating=mysql_fetch_array(mysql_query("select * from $table4 order by sno desc"));
$main_sno=$updating[sno];
$bonus_kaaga=mysql_num_rows(mysql_query("select * from $table4 where level_id='$updating[level_id]'"));

$_SESSION['resort_user_login']=$main_sno;
$l_login=kandu_pidi_new($main_sno,$table4,n_login,sno); $n_login=$datetime; mysql_query("update $table4 set n_login='$n_login',l_login='$l_login',ennu=ennu+1 where sno='$main_sno'") or die (mysql_error()); }
echo '<script>alert("Registered Successfully");window.location.href="online_test.php";</script>';


}
}
?>

<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="14"><img src="images/orange_left.png" width="14" height="43" /></td>
<td style="background:url(images/orange_center.jpg)" class="mtitle"><img src="images/arrow.png" align="absmiddle" /> Signup - New Students</td>
<td width="14" align="right"><img src="images/orange_right.png" width="14" height="43" /></td>
</tr>
<tr bgcolor="#FFFFFF">
<td class="text"></td>
<td valign="top">

<table width="93%" cellpadding="3" cellspacing="3" align="center">
<form name="user_add" action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" onSubmit="return user_validation();">
<?php if ($_REQUEST['added']!='') { ?><tr><td colspan="2" align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#000000"><strong>Your Link Has Been Added</strong></font></td></tr><?php } ?>
<?php if ($_REQUEST['refer_error']!='') { ?><tr><td colspan="2" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#00CC00"><strong><?php echo $refer_error; ?></strong></font></td></tr><?php } ?>
<?php if ($error!='') { ?><tr><td colspan="2" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFCC00"><strong><?php echo $error; ?></strong></font></td></tr><?php } ?>

<?php /*<tr><td colspan="2" style="font-weight:bold;" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><strong>ACCOUNT DETAILS</strong></font></td></tr>*/?>
<!--<tr><td class="text">Secret Question:</td><td class="text"><input type="text" name="quiz" class="small" /></td></tr>
<tr><td class="text">Answer:</td><td class="text"><input type="text" name="answ" class="small" /></td></tr>-->
<tr bgcolor="#F0F0F0"><td colspan="2" style="font-weight:bold;" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><strong>PERSONAL DETAILS </strong></font></td></tr>
<tr><td class="text">Username*:</td><td class="text"><input type="text" name="email" class="small" value="<?php echo $_REQUEST['email']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td class="text">Name*:</td><td class="text"><input type="text" name="name" class="small"  onkeyup="AllowAlphabet(this)" value="<?php echo $_REQUEST['name']; ?>" /></td></tr>
<tr><td class="text">Password*:</td><td class="text"><input type="password" name="password" class="small" /></td></tr>
<tr bgcolor="#F0F0F0"><td class="text">Confirm Password*:</td><td class="text"><input type="password" name="password1" class="small" /></td></tr>
<tr><td class="text">Date of Birth*:</td><td class="text"><!--<script>DateInput('dob', true, 'YYYY-MM-DD')</script>-->
<select name="date_da" class="simple_da"><?php for ($h = 01; $h < 32; $h++){ ?><option value="<?php echo "$h"; ?>"<?php if($h==$d){echo $sel;}?>><?php echo $h; ?></option><?php } ?></select>
<select name="month_da" class="simple_da"><?php for ($i = 01; $i < 13; $i++){ ?><option value="<?php echo "$i"; ?>"<?php if($i==$m){echo $sel;}?>><?php echo $i; ?></option><?php } ?></select>
<select name="year_da" class="simple_da"><?php for ($j = 1970; $j < 1996; $j++){ ?>
  <option value="<?php echo "$j"; ?>"<?php $year_da=$y; if($j==$year_da){echo $sel;}?>><?php echo $j; ?></option><?php } ?></select>
</td></tr>
<tr bgcolor="#F0F0F0"><td class="text">Gender:</td><td class="text"><input type="radio" name="sex" value="male" checked="checked" />Male,&nbsp;&nbsp;&nbsp;<input type="radio" name="sex" value="female" />Female</td></tr>
<tr><td class="text">Address First Line*:</td><td class="text"><input type="text" name="addr1" class="small" value="<?php echo $_REQUEST['addr1']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td class="text">Address Second Line:</td><td class="text"><input type="text" name="addr2" class="small" value="<?php echo $_REQUEST['addr2']; ?>" /></td></tr>
<tr><td class="text">City*:</td><td class="text"><input type="text" name="city" class="small" value="<?php echo $_REQUEST['city']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td class="text">State*:</td><td class="text"><input type="text" name="state" class="small" value="<?php echo $_REQUEST['state']; ?>" /></td></tr>
<tr><td class="text">Country*:</td><td class="text"><input type="text" name="country" class="small" value="<?php echo $_REQUEST['country']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td class="text">Postal Code*:</td><td class="text"><input type="text" name="post_code" class="small" value="<?php echo $_REQUEST['post_code']; ?>" /></td></tr>
<tr><td class="text">Mobile Number*:</td><td class="text"><input type="text" name="mnumber" class="small" value="<?php echo $_REQUEST['mnumber']; ?>" /></td></tr>

<tr bgcolor="#F0F0F0"><td class="text">Passport Number*:</td><td class="text"><input type="text" name="pan_number" class="small" value="<?php echo $_REQUEST['pan_number']; ?>" /></td></tr>
<tr><td class="text">Course*:</td><td class="text"><select name="dep_cour"><?php $deal_ms=mysql_query("select * from $table9 order by name"); while ($deal_ms_list=mysql_fetch_array($deal_ms)) {?><option value="<?php echo $deal_ms_list[sno]; ?>"><?php echo $deal_ms_list[name]; ?>--><?php echo $deal_ms_list[course]; ?></option><?php } ?></select></td></tr>



<tr bgcolor="#F0F0F0"><td colspan="2" style="font-weight:bold;" align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><strong>GRADE </strong></font></td></tr>
<tr><td>Maths*:</td><td><input type="text" name="m_1" class="small" value="<?php echo $_REQUEST['m_1']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td>English*:</td><td><input type="text" name="m_2" class="small" value="<?php echo $_REQUEST['m_2']; ?>" /></td></tr>
<tr><td>Subject 3:</td><td><input type="text" name="m_3" class="small" value="<?php echo $_REQUEST['m_3']; ?>" /></td></tr>
<tr bgcolor="#F0F0F0"><td>Subject 4:</td><td><input type="text" name="m_4" class="small" value="<?php echo $_REQUEST['m_4']; ?>" /></td></tr>
<tr><td>Subject 5:</td><td><input type="text" name="m_5" class="small" value="<?php echo $_REQUEST['m_5']; ?>" /></td></tr>


<tr><td colspan="2" align="center"><input type="submit" name="add_user" value="Add"></td></tr>

</form>
</table>
</p>
<script language="javascript">	function user_validation()	{	var nice=document.user_add;
if(nice.email.value=='')	{	alert("Enter username");	nice.email.focus();	return false;	}
if(nice.name.value=='')	{	alert("Enter Name");	nice.name.focus();	return false;	}
if(nice.password.value=='')	{	alert("Enter Password");	nice.password.focus();	return false;	}
if(nice.password.value!=nice.password1.value)	{	alert("Confirm Password must be equal Password");	nice.password.focus();	return false;	}
if(nice.password.value.length<6)
{
alert("Password length should be 6")
nice.password.focus();
return false;
}

if(nice.addr1.value=='')	{	alert("Enter Address");	nice.addr1.focus();	return false;	}
if(nice.city.value=='')	{	alert("Enter City");	nice.city.focus();	return false;	}
if(nice.state.value=='')	{	alert("Enter State");	nice.state.focus();	return false;	}
if(nice.country.value=='')	{	alert("Enter Country");	nice.country.focus();	return false;	}
if(nice.post_code.value=='')	{	alert("Enter Postal Code");	nice.post_code.focus();	return false;	}
if(nice.mnumber.value=='')	{	alert("Enter Mobile Number");	nice.mnumber.focus();	return false;	}
if(nice.pan_number.value=='')	{	alert("Enter Mobile Number");	nice.pan_number.focus();	return false;	}
}
function AllowAlphabet(ele){
               if (!ele.value.match(/^[a-zA-Z]+$/) && ele.value !="")
               {
                    ele.value="";
                    ele.focus(); 
                    alert("Please Enter only alphabets in text");
               }
}      
</script>
	</script>

<?php include"footer.php"; ?>
