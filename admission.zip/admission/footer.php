</td>
<td></td>
</tr>
<tr>
<td width="14" valign="bottom"><img src="images/white_left.png" width="14" height="14" /></td>
<td style="font-size:2px;" bgcolor="#FFFFFF">&nbsp;</td>
<td width="14" align="right" valign="bottom"><img src="images/white_right.png" width="14" height="14" /></td>
</tr>
</table>

</td>
<td width="5" valign="top"></td>
<?php if($gengen=='') {?>
<td valign="top">

<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="14"><img src="images/orange_left.png" width="14" height="43" /></td>
<td style="background:url(images/orange_center.jpg)" class="mtitle"><img src="images/arrow.png" align="absmiddle" /> Navigations</td>
<td width="14" align="right"><img src="images/orange_right.png" width="14" height="43" /></td>
</tr>
<tr bgcolor="#FFFFFF">
<td></td>
<style>
a.news { text-decoration:none;}
</style>
<td valign="top" class="news">
<?php
 if ($_SESSION['resort_user_login']!=''){
?>
<a class="news" href="my_account.php">My Account</a><br />
<a class="news" href="profile.php">My Profile</a><br />
<a class="news" href="edit_profile.php">Edit Profile</a><br />
<a class="news" href="admit_status.php">Admission Status</a><br />
<a class="news" href="modify_password.php">Change Password</a><br />
<a href="javascript:void(0)" onclick="window.open('feedback.php', 'newwindow', 'width=1002,height=471,scrollbars=yes,resizable=no')" class="news">Feedback</a><br />

<?php } else { ?>
<a class="news" href="website.php">Home</a><br />
<a class="news" href="about.php">About Us</a><br />
<a class="news" href="contact.php">Contact Us</a><br />
<a class="news" href="course.php">Courses</a><br />
<a href="javascript:void(0)" onclick="window.open('feedback.php', 'newwindow', 'width=1002,height=471,scrollbars=yes,resizable=no')" class="news">Feedback</a><br />
<?php } ?>
</td>
<td></td>
</tr>
<tr>
<td width="14" valign="bottom"><img src="images/white_left.png" width="14" height="14" /></td>
<td style="font-size:2px;" bgcolor="#FFFFFF">&nbsp;</td>
<td width="14" align="right" valign="bottom"><img src="images/white_right.png" width="14" height="14" /></td>
</tr>
</table>

</td><?php } ?>
</tr>
</table>

</td>
</tr>
<tr><td height="10"></td></tr>

<tr>
<td>
<table align="center" cellpadding="0" cellspacing="0" width="962">
<tr>
<td width="11"><img src="images/orange_left1.png" width="11" height="43" /></td>
<td style="background:url(images/orange_center.jpg) repeat-x" align="right">&nbsp;</td>
<td width="11" align="right"><img src="images/orange_left2.png" width="11" height="43" /></td>
</tr>
</table>

</td></tr>
<tr><td height="10"></td></tr>
</table>

</body>
</html>
