<?php include"header.php"; ?>

<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="14"><img src="images/orange_left.png" width="14" height="43" /></td>
<td style="background:url(images/orange_center.jpg)" class="mtitle"><img src="images/arrow.png" align="absmiddle" /> Request Pin</td>
<td width="14" align="right"><img src="images/orange_right.png" width="14" height="43" /></td>
</tr>
<tr bgcolor="#FFFFFF">
<td></td>
<td valign="top" class="text">

<?php if ($_SESSION['resort_user_login']=='') { echo '<script>window.location.href="website.php";</script>'; } else { ?>
<?php
if (isset($_REQUEST['change_pass']))
{
$old_pa=$_REQUEST['old_pa'];
$password=$_REQUEST['password'];
//$date=$y.'-'.$m.'-'.$d;
if (mysql_num_rows(mysql_query("select * from $table4 where sno='$main_sno' and password='$old_pa'"))=='0') { /*echo '<script>alert("Your Old Password is Wrong Try Again");</script>'; */echo '<script>window.location.href="'.$_SERVER['PHP_SELF'].'?added=3";</script>';} else { mysql_query("update $table4 set password='$password' where sno='$main_sno'"); echo '<script>window.location.href="'.$_SERVER['PHP_SELF'].'?added=1";</script>';} }
?>


<?php $welcome='Change Password '; include "member.php"; ?>


<table align="center" cellpadding="5" cellspacing="0" height="200" width="400">
<form name="change_password_form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" onSubmit="return change_password_validation();">
<?php if ($_REQUEST['added']=='1') { ?><tr><td colspan="2" style="padding:8px; color:#FF0000;" align="center" class="text">Your Password Has Been Added</td></tr><?php } ?>
<?php if ($_REQUEST['added']=='3') { ?><tr><td colspan="2" style="padding:8px; color:#FF0000;" align="center" class="text">Your Old Password is Wrong Try Again</td></tr><?php } ?>

<tr>
<td class="text">Old Password:</td>
<td><input type="password" name="old_pa" /></td>
</tr>
<tr>
<td class="text">New Password:</td>
<td><input type="password" name="password" /></td>
</tr>
<tr>
<td class="text">Confirm New Password:</td>
<td><input type="password" name="password1" /></td>
</tr>
<tr>
<td colspan="2" valign="bottom" align="center">
<input type="submit" name="change_pass" value="Change" />
</td>
</tr>
</form>
</table>
<script language="javascript">	function change_password_validation()	{	var nice=document.change_password_form;
if(nice.old_pa.value=='')	{	alert("Enter Your Old Password");	nice.old_pa.focus();	return false;	}	if(nice.password.value=='')	{	alert("Enter Your New Password");	nice.password.focus();	return false;	}	if(nice.password1.value != nice.password.value)	{	alert("Confirm Password and Password not Equal");	nice.password1.select;	nice.password1.focus();	return false;	}	
}
</script>



<?php include"footer.php"; } ?>