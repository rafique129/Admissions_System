<?php include "include/db.php";
?>
<link href="admin/include/style.css" rel="stylesheet" type="text/css">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Tree</title>
</head>

<body>
  <table border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF" style="border:0px solid #000000" width="80%">

<tr><td colspan="2" align="center">
<?php if ($_REQUEST['tree_view_concept_id']=='') { $tree_view_concept_id=1; } else { $tree_view_concept_id=$_REQUEST['tree_view_concept_id']; }
?>
<table>
<form method="post">
<tr>
<td>User:</td>
<td>
<select name="tree_view_concept_id" onChange="this.form.submit();">
<option value="">--Select--</option>
<?php $select_group_id=mysql_query("select * from $table4"); while ($select_group_id_array=mysql_fetch_array($select_group_id)) { ?>
<option value="<?php echo $select_group_id_array['sno']; ?>" <?php if ($select_group_id_array['sno']==$tree_view_concept_id) { echo ' selected="selected"'; } ?>><?php echo $select_group_id_array[sno]; ?>, <?php echo $select_group_id_array[name]; ?></option>
<?php } ?>
</select>
</td>
</tr>
</form>
</table>

</td></tr>



<tr>
<td colspan="2" align="center">











<div style="overflow:auto; width:660px; height:336px; padding:15px;">
<?php
//if ($_REQUEST['tree_view_concept_id']=='') { $tree_view_concept_id=$tree_id_new; } else { $tree_view_concept_id=$_REQUEST['tree_view_concept_id']; }
$different_concept_amount=''; 
$different_concept=mysql_query("select * from $table4 where refer_id='$tree_view_concept_id'");	
$different_concept_counting_value=mysql_num_rows($different_concept);
?>


<table cellpadding="0" cellspacing="0">
<tr><td colspan="<?php echo $different_concept_counting_value; ?>" align="center">
<div style="border:#000000 solid 0px; color:#000000; padding:10px;">
<img src="admin/images/trees003.gif" width="50" height="52" /><br /><?php $tree_id_new=$_SESSION['id']; /*echo $tree_id_new;  echo ', '; */echo kandu_pidi_new($tree_view_concept_id,$table4,name,sno); echo ' ('.$tree_view_concept_id.') '; ?></div></td></tr>
<?php if ($different_concept_counting_value!='0') { ?>

<tr><td colspan="<?php echo $different_concept_counting_value; ?>" align="center" style="padding-top:12px;"><img src="admin/images/tree/tree.jpg" /></td></tr>

<?php if($different_concept_counting_value!='1') { ?>
<tr><td colspan="<?php echo $different_concept_counting_value; ?>" align="center" style="height:2px; padding-left:8px; padding-right:8px;"><div style="background-image:url(admin/images/tree/tree1.jpg); height:1px;"></div></td></tr>
<?php } ?>

<tr>
<?php /*$different_concepta_count=mysql_num_rows($different_concept); $different_concepta_commission='0';*/
$i=0;
while ($different_concepta=mysql_fetch_array($different_concept))	
{
$i++;
$different_concepta_user_id=$different_concepta['sno']; ?>
<td onClick="window.location.href='?tree_view_concept_id=<?php echo $different_concepta_user_id; ?>';" align="<?php if($different_concept_counting_value=='1') { echo 'center'; } else if ($i=='1') { echo 'left'; } else if ($i==$different_concept_counting_value) { echo 'right'; } else echo 'center'; ?>" style="padding-left:8px; padding-right:8px; cursor:pointer;"><img src="admin/images/tree/tree.jpg" /><div style="border:#000000 solid 1px; padding:8px; text-align:center; color:#000000; font-size:9px; font-weight:normal;"><img src="admin/images/trees003.gif" width="50" height="52" /><br /><?php /*echo $different_concepta_user_id; echo ', '; */ echo kandu_pidi_new($different_concepta_user_id,$table4,name,sno); echo ' ('.$different_concepta_user_id.') ';//name_display($different_concepta_user_id,$jws_b3table)); ?> <?php echo $different_concepta['side']; ?></div></td>
<?php } ?>
</tr><?php } ?>
<?php if($_REQUEST['tree_view_concept_id']!='') { ?>
<tr><td colspan="<?php echo $different_concept_counting_value; ?>" align="center" style="padding-top:12px;"><INPUT TYPE="button" VALUE="Back" onClick="history.go(-1);"></td></tr>
<?php } ?>
</table>
</div>















</td></tr>
</table>
</body>
</html>
