<?php  include "include/db.php"; ?>
<?php $msg=2;

if(isset($_REQUEST['submit']))
{

$email_id=$_REQUEST['email'];
$comment=$_REQUEST['comment'];
$name=$_REQUEST['name'];

$s_id=$_SESSION['user_id'];

$query=mysql_query("insert into $feedback_table (name,email_id,comment) VALUES ('$name','$email_id','$comment')");

// $to = "jeya.web@gmail.com";	

		$to = "prabakar12@gmail.com";		
		$from = "prabakar12@gmail.com";		
		$subject = "Feedback Message from Gambomi Customer Relationship Management System";

		// To send HTML mail, the Content-type header must be set
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$headers .= 'From:'.$email_id."\r\n"
		.'Reply-To:' .$from."\r\n";
//		$success = mail($to,$subject, $message, $headers); 
		
		
$msg= "1";
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="home_files/style.css">
<link rel="stylesheet" type="text/css" href="new_menu/ddlevelsmenu-base.css" />
<link rel="stylesheet" type="text/css" href="new_menu/ddlevelsmenu-topbar.css" />
<style>
.alert { color:#FF0000; font-size:10px; }
label { color:#FF0000; font-size:10px; } 
</style>
<?php //include "php/validate.php"; ?>
</head>

<body>
<form  name="feedback" method="post" onSubmit="return user_validation();">
<table width="100%" border="0" cellspacing="1" cellpadding="5" id="td_font" >
 <tr>
    <td height="28" colspan="2" id="sub_head">Give US Your Feedback</td>
  </tr>
  <?php if($msg=="2") { } else { ?>
  <tr><td colspan="2">
  <table width="100%" border="0" cellspacing="0" cellpadding="0" id="td_font" >
<tr>
    <td height="35">Thank you for taking the time to give us your input. We look forward to reviewing your comments and suggestions.</td>
  </tr>

  <tr>
    <td height="60" align="right" style="padding-right:20px;">
	<A href="javascript: self.close ()">Close this Window</A> 
	</td>
  </tr>
</table>
</td></tr><?php  } ?>
  <?php if($msg=="2") {  ?>
  <tr>
    <td width="24%" height="23">Name<span class="alert">*</span></td>
    <td width="76%"><input type="text" name="name" id="name" style="width:170px;" class="required" /></td>
  </tr>
  <tr>
    <td height="23">Email Address<span class="alert">*</span></td>
    <td><input type="text" name="email" id="email" style="width:170px;" class="required" /></td>
  </tr>
  <tr>
    <td height="106">Comments<span class="alert">*</span></td>
    <td><textarea name="comment"  rows="6" id="comment" style="width:170px;" class="required"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="submit" id="submit" value="Submit" style="width:120px;"/></td>
  </tr><?php } else { } ?>
</table>
</form>

<script language="javascript">	function user_validation()	{	var nice=document.feedback;
if(nice.name.value=='')	{	alert("Enter Your Name");	nice.name.focus();	return false;	}
if(nice.email.value=='')	{	alert("Enter Your Email");	nice.email.focus();	return false;	}
if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(nice.email.value))	{}	else	{	alert("Invalid email address! Please re-enter.");	nice.email.focus();	return false;	}
if(nice.comment.value=='')	{	alert("Enter Your Feedback");	nice.comment.focus();	return false;	}
}
</script>

</body>
</html>
