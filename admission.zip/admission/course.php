<?php include"header.php"; ?>
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	left:246px;
	top:566px;
	width:632px;
	height:731px;
	z-index:1;
}
#Layer2 {
	position:absolute;
	left:259px;
	top:579px;
	width:281px;
	height:23px;
	z-index:2;
}
#Layer3 {
	position:absolute;
	left:258px;
	top:608px;
	width:606px;
	height:141px;
	z-index:3;
}
#Layer4 {
	position:absolute;
	left:258px;
	top:786px;
	width:221px;
	height:24px;
	z-index:4;
}
#Layer5 {
	position:absolute;
	left:257px;
	top:814px;
	width:608px;
	height:469px;
	z-index:5;
}
-->
</style>

<div id="Layer1">
  <label></label>
</div>
<div id="Layer2"> &nbsp;<strong>BUSINESS INFORMATION SYSTEM</strong> </div>
<div id="Layer3">
  <div align="justify">
    <p>Virtually every company uses business information systems in all aspects of their business. The real-world&nbsp;education you receive at Kaduna Polytechnic when you earn your bachelor's degree with a Business Information Systems specialization can prepare you to handle the same situations these companies face every day. Our experiential instruction provides a cross-section of business and technology, and is continually updated to keep pace with the latest advancements. You'll gain the technical skills needed for positions in fields like advertising, marketing, communications, finance, education, government service, or healthcare technology.</p>
  </div>
  <p>&nbsp;</p>
</div>
<div id="Layer4"><strong>&nbsp;SOFTWARE ENGINEERING </strong></div>
<div id="Layer5"> 
  <p align="justify">Computer Science and Software Engineering focuses on the object-oriented approach to software development, accepted by industry as a key technology for the future. The course provides an extensive education in contemporary approaches to the analysis, design and implementation of large-scale systems, along with a sound understanding of the traditional aspects of computer science such as hardware and operating systems. Like all IT courses at Kaduna Polytechnic, this course pays particular attention to the human factors involved in the development, deployment and use of computer-based systems. </p>
  <p align="justify"> There is a focus on applications involving multimedia, and on web-based systems, with an emphasis on the design of effective human-computer interfaces. A range of options in the final year of the course allows students to study advanced subjects in areas such as software engineering, computer networks, database, knowledge-based systems and human-computer interaction. The acquired skills and knowledge are consolidated in a major team project for an external client in the final year. The course uses C as the first programming language. Students then develop skills in C++ and Java programming languages. </p>
  <p align="justify"> Graduates of this course will have extensive skills in software development, particularly relating to medium- and large-scale projects, will have developed experience in working on team projects, and will have well-developed oral and written communication skills. The course involves the use of the most up-to-date technology and methods, and includes a major emphasis on software development for multimedia applications on the web. The course is oriented towards applications in areas such as defence, aerospace and medicine, where complex software plays a major role, often of a safety-critical nature; as well as in businesses that require extensive computer support, such as banking and manufacturing. </p>
</div>
<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="14"><img src="images/orange_left.png" width="14" height="43" /></td>
<td style="background:url(images/orange_center.jpg)" class="mtitle"><img src="images/arrow.png" align="absmiddle" />Courses </td>
<td width="14" align="right"><img src="images/orange_right.png" width="14" height="43" /></td>
</tr>
<tr bgcolor="#FFFFFF">
<td></td>
<td valign="top">

  <p><br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
    </p>
  <p>&nbsp;</p>
  <p><br />
    </p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p><br />
    <?php include"footer.php"; ?>
  </p>
