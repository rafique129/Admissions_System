<style type="text/css">

#marqueecontainer{
font-family:Arial, Helvetica, sans-serif;
color:#000000;
position: relative;
width: 200px; /*marquee width */
height: 200px; /*marquee height */
overflow: hidden;
border:0px solid #FFFFFF;
padding: 2px;
}

</style>

<script type="text/javascript">

/***********************************************
* Cross browser Marquee II- © Dynamic Drive (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit http://www.dynamicdrive.com/ for this script and 100s more.
***********************************************/

var delayb4scroll=2000 //Specify initial delay before marquee starts to scroll on page (2000=2 seconds)
var marqueespeed=1 //Specify marquee scroll speed (larger is faster 1-10)
var pauseit=1 //Pause marquee onMousever (0=no. 1=yes)?

////NO NEED TO EDIT BELOW THIS LINE////////////

var copyspeed=marqueespeed
var pausespeed=(pauseit==0)? copyspeed: 0
var actualheight=''

function scrollmarquee(){
if (parseInt(cross_marquee.style.top)>(actualheight*(-1)+8))
cross_marquee.style.top=parseInt(cross_marquee.style.top)-copyspeed+"px"
else
cross_marquee.style.top=parseInt(marqueeheight)+8+"px"
}

function initializemarquee(){
cross_marquee=document.getElementById("vmarquee")
cross_marquee.style.top=0
marqueeheight=document.getElementById("marqueecontainer").offsetHeight
actualheight=cross_marquee.offsetHeight
if (window.opera || navigator.userAgent.indexOf("Netscape/7")!=-1){ //if Opera or Netscape 7x, add scrollbars to scroll and exit
cross_marquee.style.height=marqueeheight+"px"
cross_marquee.style.overflow="scroll"
return
}
setTimeout('lefttime=setInterval("scrollmarquee()",30)', delayb4scroll)
}

if (window.addEventListener)
window.addEventListener("load", initializemarquee, false)
else if (window.attachEvent)
window.attachEvent("onload", initializemarquee)
else if (document.getElementById)
window.onload=initializemarquee


</script>

<table align="center" cellpadding="0" cellspacing="0" width="233" height="288">
<tr>
<td width="14" height="43"><img src="images/orange_left.png" width="14" height="43"></td>
<td style="background:url(images/orange_center.jpg) repeat-x" class="mtitle"><img src="images/arrow.png" align="absmiddle"> New Announcements</td>
<td width="14" height="43" align="right"><img src="images/orange_right.png" width="14" height="43"></td>
</tr>
<tr bgcolor="#FFFFFF">
<td></td>
<td valign="top" class="news">

<div id="marqueecontainer" onMouseover="copyspeed=pausespeed" onMouseout="copyspeed=marqueespeed">
<div id="vmarquee" style="position: absolute; width: 80%; margin-left:0px;" class="lnews">

<!--YOUR SCROLL CONTENT HERE-->
<?php
$la_news=mysql_fetch_array(mysql_query("select * from $table6 where active='1'"));
?>
<strong><?php echo $la_news['title']; ?></strong><br />
<?php echo $la_news['content']; ?><br />

<!--YOUR SCROLL CONTENT HERE-->

</div>
</div>

</td>
<td></td>
</tr>
<tr>
<td width="14" height="14" valign="bottom"><img src="images/white_left.png" width="14" height="14"></td>
<td style="background:#FFFFFF; font-size:2px;">&nbsp;</td>
<td width="14" height="14" align="right" valign="bottom"><img src="images/white_right.png" width="14" height="14"></td>
</tr>
</table>
