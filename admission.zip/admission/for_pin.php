<table cellpadding="10" align="center">
<tr>
<td align="center"><a href="pins.php" style="color:#000000;"><img src="images/used_pins.png" border="0" /></a></td>
<td align="center"><a href="un_used_pins.php" style="color:#000000;"><img src="images/unused_pins.png" border="0" /></a></td>
<?php /*<td align="center"><a href="pin_request.php" style="color:#000000;"><img src="images/request_pin.png" border="0" /></a></td>*/?>
</tr>
</table>
