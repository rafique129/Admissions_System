<?php include"header.php"; ?>

<h4 class="welcome">How to Join</h4>

<p class="text">To Join The Company, Required Documents are as Under :</p>
<p class="text"><strong>Application / Agreement Form (Duly Filled and Signed)  AND Identity Proof.</strong></p>
<p class="text">Decide how many PINs will be required for you or your referral on this time.<br>
Calculate the cost of PINs. [ 1 PIN = Rs.1000/- ]</p>
<p class="text">Now, There are 2 options for purchase the ( Registration PINs. )</p>

<p class="text"><strong>Option 1</strong></p>
<p class="text1">The New Applicants OR Existing Members have to contact their respective nearest PDC for the Purchase of registration Pins and follow the system or our office phone number.</p>
<center><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><strong>OR</strong></font></center>
<p class="text"><strong>Option 2</strong></p>
<p class="text1">The New Applicants / Existing Members have to prepare a DEMAND DRAFT (D.D.) in favour of  "<strong><?php echo $cname; ?></strong>" payable at "<strong>MADURAI</strong>" with brief details about Mobile Number/User ID/Address etc. clearly mentioned on a plain paper and send us OR Submit the nearest PDC.</p>
<p class="text">Write an email to : support@lifeeasy.in OR our PDC email ( listed in contact us ) with all the details like , Bank Name / Branch Name / Date / Amount / D.D. number / Scan copy of D.D./ sender’s name and User ID / No of pins required & Your email id, for us, to send PINs and to reply.</p>
<p class="text">As soon as company / PDC Receives your request, it will be cross checked with your email request, Immediately "<strong>PINs</strong>" & "<strong>Sponsor’s Details</strong>" will be delivered to your email address.</p>
<p class="text">After receiving the PINs, Open the website www.lifeeasy.in, Download the Application Form from website and fill in carefully.</p>
<p class="text">Now Go ahead complete the registration by clicking on link "<strong>JOIN NOW</strong>". </p>
<p class="text">Make sure that you have already read Terms & Conditions.</p>
<p class="text">After completion of registration note down your User ID. Then fill up the User ID in the Form as Registration No.</p>
<p class="text">Now your Registration is going to complete but not activated yet. To activate your Registration, your original form with Identity Proof handover to your Leader or send to companys's Reg. office address. </p>
<p class="text">After receiving your complete Form with ID Proof, Company will Activate your Membership.</p>
<p class="text">Congratulations – You are now "<strong>Registered Member</strong>" of Our Company.</p>

<?php include"footer.php"; ?>