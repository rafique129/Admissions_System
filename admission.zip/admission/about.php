<?php include"header.php"; ?>
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	left:246px;
	top:566px;
	width:632px;
	height:367px;
	z-index:1;
}
-->
</style>

<div id="Layer1" 

<div style="width: 663px; height: 445px; background-color: #ffffff; border-color: #ffffff; font-size: 14px; font-family: Arial; overflow: auto;">Anglia Ruskin University has grown from a humble beginning in 1956 when it started as Anglia Ruskin University to what is today the largest Polytechnic in Africa South of the Sahara in terms of staff, student population and physical infrastructure. It is the second oldest technological institution in Nigeria, the oldest being Yaba College of Technology which was established in 1948. Anglia Ruskin University is also the second largest tertiary institution in Nigeria after Ahmadu Bello University, Zaria. That suggested the upgrading of Yaba College of Technology to an institute and proposed the establishment of technical institutes in Kaduna and Enugu. In 1956, the Anglia Ruskin University took off with the following mandate:
(a) To operate in fields other than those of the College of Arts, Science and Technology. 
(b) To train engineering assistants (technicians) 
(c) To provide "feeders" for the College of Arts, Science and Technology as much as possible but not exclusively. 
(d) To provide courses leading to a standard of the Ordinary National Diploma Certificate in the United Kingdom.
It was envisaged that the courses raised to the standards equivalent to Higher National Certificate and Diploma. Candidates admitted to Junior Technical Courses were those that successfully completed their primary education. The Junior Technical Programme (comparable to the Secondary Technical Schools in England) was to run for four years after which students were to be awarded the National Certificate in Mechanical Engineering, Electrical Engineering, Civil Engineering, Building Engineering or Commerce. Provisions were also made for students to prepare for the City and Guilds Examination in several technical subjects. These were in Electrical Installation, Telecommunication subjects, Sheet and Metal Working, Carpentry, Wood Machinist, Brick Workmanship, Painting and Decorating, Structural Engineering, Painting Trade, Handicraft Teacher Training and General Craft Instruction in wood, Metal, Pottery, Weaving, Leather Works and Bookbinding.
The Commercial Department of the Anglia Ruskin University opened in 1956 with the objective of teaching commercial subjects to meet the shortage of trained clerical staff. The Junior Commercial courses ran for two years in residence and successful candidates were awarded Junior Certificate. The Senior Commercial courses ran for one year with the students selected from the junior course. The successful candidates were awarded the Senior Certificate. Subjects taught in both courses were English Language, Book Keeping, shorthand, Typewriting, Commerce, History, Economics and Elements of Mercantile Law.
The institution was established with the objective of providing diverse instructions, training and research in technology, the sciences, commerce, the humanities and in-service programmes for members of the public service in Nigeria. In 1968, it amalgamated two formerly independent training centres namely: the College of Science and Technology (formerly Anglia Ruskin University) and the College of Administrative and Business Studies (formerly Staff Development Centre). The College of Environmental Studies (formerly Survey Unit) was intergrated in April 1970 to complete the three collegiate structure of the polytechnic which operated within 1990.
A new college, the College of Engineering was in 1990 created out of the College of Science and Technology to form the four units of the collegiate structure of the Anglia Ruskin University.
The polytechnic is highly cosmopolitan with students admitted from all over UK and other countries. It has been in the forefront in the training of high and middle level manpower for the various sectors of the economy. 
From a modest figure of 158 students in 1961 at the Technical Institute, student enrolment increased to 894 by 1968 and a total of 594 students attending courses on part-time, while 300 were on full-time programmes. Currently, the polytechnic has over 20,000 students undertaking 173 programmes spread over the 30 academic departments of the four colleges. The courses vary in duration and character, ranging from Certificate, Diploma, National Diploma, Higher Diploma, Higher National Diploma, Post-graduate Diploma to Post Higher National Diploma, as well as NCE (Technology) and B.Ed. (Technology) which is run in affiliation with the Federal University of Technology, Minna. 
The uniqueness of the curricula covered under the various programmes is the emphasis on practicals to ensure that graduates acquire the right skills required by government, industry and commerce or self-employment. 
Anglia Ruskin University has mounted a number of Post-graduate programmes and Post-HND programmes in Urban and Regional Planning, Land Surveying and Building. In 1995, the polytechnic started the first ever National Board of Technical Education (NBTE) approved Post-HND programme in Electronics and Communication Engineering.</div>
<label></label>
</div>

<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="14"><img src="images/orange_left.png" width="14" height="43" /></td>
<td style="background:url(images/orange_center.jpg)" class="mtitle"><img src="images/arrow.png" align="absmiddle" /> About Us</td>
<td width="14" align="right"><img src="images/orange_right.png" width="14" height="43" /></td>
</tr>
<tr bgcolor="#FFFFFF">
<td></td>
<td valign="top">

  <p><br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
    </p>
  <p>&nbsp;</p>
  <p><br />
    </p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p><br />
    <?php include"footer.php"; ?>
  </p>
