<?php error_reporting(0);session_start();
if($_SERVER['HTTP_HOST']!='localhost')
{
}
else
{
$jws=mysql_connect("localhost","root","");
mysql_select_db("admission",$jws);
}

$table1="on_admit_3_login";
$table2="on_admit_3_sett";
$table3="on_admit_3_pins";
$table4="on_admit_3_users";
$table5="on_admit_3_earning";
$table6="on_admit_3_news";
$table7='on_admit_3_pins_request';
$table8='on_admit_3_payment';
$table9="on_admit_3_departments";
$feedback_table="on_admit_3_feedback";

include "config.php";

$cname="ONLINE ADMISSION SYSTEM FOR KADUNA POLYTECHNIC";


$co_settings=mysql_fetch_array(mysql_query("select * from $table2 where sno='1'")); 
$limited_value=$co_settings['per_page'];

$level_1=$co_settings['l1'];
$level_2=$co_settings['l2'];
$level_3=$co_settings['l3'];
$level_4=$co_settings['l4'];
$level_5=$co_settings['l5'];
$level_6=$co_settings['l6'];
$level_7=$co_settings['l7'];
$level_8=$co_settings['l8'];


$common_level_count=mysql_fetch_array(mysql_query("select * from $table4 order by level_id desc"));
$common_level_count_total=$common_level_count['level_id'];


$company_name=$cname;
/*
?>




<?php
if ((isset($_REQUEST['admin_uniq_ids'])) and (isset($_REQUEST['admin_sno'])))
{
$_SESSION['uniq_ids']=$_REQUEST['admin_uniq_ids'];
$_SESSION['resort_user_login']=$_REQUEST['admin_sno'];
}
?>

*/
?>
<?php
if (isset($_REQUEST['user_login']))
{
/*
$username=strtoupper($_REQUEST['uname']);
$months=substr($username,0,2);
$sno=substr(substr($username,2),0,-2);
$t_value=substr($username,-2);
*/
$sno=$_REQUEST['uname'];
//if($t_value==new_con($sno)){
$password=$_REQUEST['pword'];
if (mysql_num_rows(mysql_query("select * from $table4 where email='$sno' and password='$password' and active='1' and login_active='1'"))!='0')
{/* echo '<script>alert("Site Now Under Construction Please Try After 5 Days");window.location.href="website.php";</script>';*/
$_SESSION['resort_user_login']=kandu_pidi_new($sno,$table4,sno,email);
$l_login=kandu_pidi_new($sno,$table4,n_login,email); $n_login=$datetime; mysql_query("update $table4 set n_login='$n_login',l_login='$l_login',ennu=ennu+1 where sno='$sno'") or die (mysql_error()); echo '<script>window.location.href="my_account.php";</script>';}
else { echo '<script>alert("Incorrect Username or Password Please Try Again");</script>'; }
/*}
else { echo '<script>alert("Incorrect Username or Password Please Try Again");</script>'; }*/
}
$main_sno=$_SESSION['resort_user_login'];
$loading_code='<div align="center"><strong>LOADING.....</strong></div>';
$very_large_amount='36000';
$sel=' selected="selected"';
?>








<?php
if (isset($_REQUEST['pdc_login']))
{
$username=$_REQUEST['uname'];
$password=$_REQUEST['pword'];
if (mysql_num_rows(mysql_query("select * from $table4 where sno='$username' and pdc_password='$password' and active='1'"))!='0')
{ $_SESSION['pdc']=$username; $l_login=kandu_pidi_new($username,$table4,n_login,email); $n_login=$datetime; mysql_query("update $table4 set n_login='$n_login',l_login='$l_login',ennu=ennu+1 where sno='$username'") or die (mysql_error()); echo '<script>window.location.href="pin_transfer.php";</script>'; }
else { echo '<script>alert("Incorrect Username or Password Please Try Again");</script>'; }
}
$pdc_sno=$_SESSION['pdc'];
$loading_code='<div align="center"><strong>LOADING.....</strong></div>';
$very_large_amount='36000';
$sel=' selected="selected"';
$limited_value=20;
//ALTER TABLE `on_admit_3_payment` ADD `real_id` INT( 111 ) NOT NULL AFTER `user_id` ;
?>