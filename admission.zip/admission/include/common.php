<?php
if ($_SESSION['uniq_ids']!='') {

$bin=mysql_query("select * from $table4 where refer_id='$uniq_idds'"); while ($bin_history=mysql_fetch_array($bin)) { 
$bin_amount=amount_sum($bin_history['amount'],$bin_history['perc']);
$bin_detuct=detuct_sum($bin_amount);
$bin_net=net_sum($bin_amount,$bin_detuct);
$bin_total=$bin_total+$bin_net; }

/*
$pin=mysql_query("select * from $table5 where user_id='$uniq_idds' and trans='pin'"); while ($pin_history=mysql_fetch_array($pin)) { $pin_total=$pin_total+$pin_history['tot_amount'];}
*/

/*
$paid_un=mysql_query("select * from $table5 where user_id='$uniq_idds' and active='' and trans!='pin'"); while ($paid_un_history=mysql_fetch_array($paid_un)) { $paid_un_total=$paid_un_total+$paid_un_history['tot_amount'];}

$paid_ap=mysql_query("select * from $table5 where user_id='$uniq_idds' and active='1' and trans!='pin'"); while ($paid_ap_history=mysql_fetch_array($paid_ap)) { $paid_ap_total=$paid_ap_total+$paid_ap_history['tot_amount'];}
*/

/*
$paid_un=mysql_query("select * from $table5 where user_id='$uniq_idds' and active='3' and trans='withd'"); while ($paid_un_history=mysql_fetch_array($paid_un)) { $paid_un_total=$paid_un_total+$paid_un_history['tot_amount'];$paid_un_amount=$paid_un_amount+$paid_un_history['amount'];}

$paid_ap=mysql_query("select * from $table5 where user_id='$uniq_idds' and active='2' and trans='withd'"); while ($paid_ap_history=mysql_fetch_array($paid_ap)) { $paid_ap_total=$paid_ap_total+$paid_ap_history['tot_amount'];$paid_ap_amount=$paid_ap_amount+$paid_ap_history['amount'];}

$paid_ac=mysql_query("select * from $table5 where user_id='$uniq_idds' and active='1' and trans='withd'"); while ($paid_ac_history=mysql_fetch_array($paid_ac)) { $paid_ac_total=$paid_ac_total+$paid_ac_history['tot_amount'];$paid_ac_amount=$paid_ac_amount+$paid_ac_history['amount'];}
*/
$paid_un_total=w_pen($uniq_idds,$table5,withd);
$paid_ap_total=w_pro($uniq_idds,$table5,withd);
$paid_ac_total=w_suc($uniq_idds,$table5,withd);
$pin_total=w_pin($uniq_idds,$table5,pin);
$renew_total=w_renew($uniq_idds,$table5,renew);
$seed_total=w_renew($uniq_idds,$table5,renew);


//$bin_pin_total_total=$bin_total+$pin_total-$paid_un_total-$paid_ap_total-$paid_ac_total-$renew_total;
$bin_pin_total_total=total_total($bin_total,$pin_total,$paid_un_total,$paid_ap_total,$paid_ac_total,$renew_total,$seed_total);

$left_side=mysql_fetch_array(mysql_query("select * from $table4 where sponsor_id='$uniq_idds' and side='left'"));
$left_side_man=$left_side['uniq_ids'];
$right_side=mysql_fetch_array(mysql_query("select * from $table4 where sponsor_id='$uniq_idds' and side='right'"));
$right_side_man=$right_side['uniq_ids'];

}


if(!function_exists('left')){
function left($nice,$nice1)
{
$left_side=mysql_fetch_array(mysql_query("select * from $nice1 where sponsor_id='$nice' and side='left'"));
$left_side_man=$left_side['uniq_ids'];
return $left_side_man;
}
}

if(!function_exists('right')){
function right($nice,$nice1)
{
$left_side=mysql_fetch_array(mysql_query("select * from $nice1 where sponsor_id='$nice' and side='right'"));
$left_side_man=$left_side['uniq_ids'];
return $left_side_man;
}
}


/*
echo $left_side_man;
echo '<br>';
echo $right_side_man;
*/
?>
