<?php
if(!function_exists('WeekToDate1')){ function WeekToDate1 ($week, $year)		{		$Jan1 = mktime (1, 1, 1, 1, 1, $year);		$iYearFirstWeekNum = (int) strftime("%W",mktime (1, 1, 1, 1, 1, $year));				if ($iYearFirstWeekNum == 1)		{		$week = $week - 1;		}				$weekdayJan1 = date ('w', $Jan1);		$FirstMonday = strtotime(((4-$weekdayJan1)%7-5) . ' days', $Jan1);		$CurrentMondayTS = strtotime(($week) . ' weeks', $FirstMonday);		/*return ($CurrentMondayTS);*/				$sStartDate = date ("Y-m-d", $CurrentMondayTS);		$sEndDate = date ("Y-m-d", $CurrentMondayTS + (6*24*60*60));		return ($sStartDate);		}			}
if(!function_exists('WeekToDate2')){ function WeekToDate2 ($week, $year)		{		$Jan1 = mktime (1, 1, 1, 1, 1, $year);		$iYearFirstWeekNum = (int) strftime("%W",mktime (1, 1, 1, 1, 1, $year));				if ($iYearFirstWeekNum == 1)		{		$week = $week - 1;		}				$weekdayJan1 = date ('w', $Jan1);		$FirstMonday = strtotime(((4-$weekdayJan1)%7-5) . ' days', $Jan1);		$CurrentMondayTS = strtotime(($week) . ' weeks', $FirstMonday);		/*return ($CurrentMondayTS);*/				$sStartDate = date ("Y-m-d", $CurrentMondayTS);		$sEndDate = date ("Y-m-d", $CurrentMondayTS + (6*24*60*60));		return ($sEndDate);		}		}

$timezone  = +5.50;
$time_new_time=gmdate("Y-m-d-F-G-i-s", time() + 3600*($timezone+date("I")));
//echo $time_new_time;
$new_time=explode("-", $time_new_time);
$y=$new_time[0];
$m=$new_time[1];
$d=$new_time[2];
$month_num=$new_time[3];
$t=$new_time[4];
$n=$new_time[5];
$s=$new_time[6];
//$y=date(Y); $m=date(m); $d_num=date(d); $month_num=date(F);
$num = cal_days_in_month(CAL_GREGORIAN, $m, $y);
$dated=$y.'-'.$m.'-'.$d;
$datetime=$y.'-'.$m.'-'.$d.'-'.$t.'-'.$n.'-'.$s;
$datetime1=$s.','.$m.','.$d.','.$y;


$dated_week_start=WeekToDate1(week_only($dated),year_only($dated));
$dated_week_end=WeekToDate2(week_only($dated),year_only($dated));
?>
