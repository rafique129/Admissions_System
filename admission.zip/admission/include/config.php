<?php
$timezone  = +5.50;
$time_new_time=gmdate("Y-m-d-F-G-i-s", time() + 3600*($timezone+date("I")));
//echo $time_new_time;
$new_time=explode("-", $time_new_time);
$y=$new_time[0];
$m=$new_time[1];
$d=$new_time[2];
$month_num=$new_time[3];
$t=$new_time[4];
$n=$new_time[5];
$s=$new_time[6];
//$y=date(Y); $m=date(m); $d_num=date(d); $month_num=date(F);
$num = cal_days_in_month(CAL_GREGORIAN, $m, $y);
$dated=$y.'-'.$m.'-'.$d;
$datetime=$y.'-'.$m.'-'.$d.'-'.$t.'-'.$n.'-'.$s;
$datetime1=$s.','.$m.','.$d.','.$y;
$dated_orig=$dated;
$date_timed=$datetime;

$time=$t.':'.$n.':'.$s;;

$dated_or=$dated;


$selected_value=' selected="selected"';
$checked_value=' checked="checked"';
$tree_view_link1='Next';
$tree_view_link2='Form';

$extra_charges_1=10;
$extra_charges_2=10;
$extra_charges_new=5;

function kandu_pidi($nice,$nice1,$nice2) { $nice3=mysql_fetch_array(mysql_query("select * from $nice1 where sno='$nice'")); $nice4=$nice3[$nice2]; return $nice4; }

function kandu_pidi_new($nice,$nice1,$nice2,$nice_new) { $nice3=mysql_fetch_array(mysql_query("select * from $nice1 where $nice_new='$nice'")); $nice4=$nice3[$nice2]; return $nice4; }

function generate_ids($nice,$nice1,$nice2)
{
if($nice=='f') { $start='100000'; $end='199999'; }
if($nice=='a') { $start='600000'; $end='699999'; }
$value=rand($start, $end);
	function numbers($new,$new1,$new2)
	{
	$new3=mysql_num_rows(mysql_query("select * from $new1 where $new2='$new'"));
	return $new3;
	}

$nice3=numbers($value,$nice1,$nice2);
if($nice3!='0') { $value=rand($start, $end); $nice3=numbers($value,$nice1,$nice2); }
if($nice3!='0') { $value=rand($start, $end); $nice3=numbers($value,$nice1,$nice2); }
if($nice3!='0') { $value=rand($start, $end); $nice3=numbers($value,$nice1,$nice2); }
if($nice3!='0') { $value=rand($start, $end); $nice3=numbers($value,$nice1,$nice2); }

$nice4=$value;
return $nice4;
}



function double($nice,$nice1) { $nice3=mysql_num_rows(mysql_query("select * from $nice1 where sponsor_id='$nice'")); return $nice3; }
function double_only($nice,$nice1,$nice2) { $nice3=mysql_num_rows(mysql_query("select * from $nice1 where sponsor_id='$nice' and side='$nice2'")); return $nice3; }
function check_da($new,$new1,$new2){$new3=mysql_num_rows(mysql_query("select * from $new1 where $new2='$new' and active='1'"));return $new3;}


function day_only($nice) { $nice1=date("D",strtotime($nice)); return $nice1; }
function week_only($nice) { $nice1=date("W",strtotime($nice)); return $nice1; }
function month_only($nice) { $nice1=date("F",strtotime($nice)); return $nice1; }
function year_only($nice) { $nice1=date("Y",strtotime($nice)); return $nice1; }
function date_only($nice) { $nice1=date("d-m-Y",strtotime($nice)); return $nice1; }

if(!function_exists('date_with_day')){ function date_with_day($nice) { if(($nice=='0000-00-00 00:00:00') or ($nice=='')) { $nice1='--'; } else{$nice1=date("d-m-Y (D)",strtotime($nice)); } return $nice1; } }

function date_with_day_check($nice) { if($nice=='0000-00-00') { $nice1='--'; } else { $nice1=date("d-m-Y (D)",strtotime($nice)); } return $nice1; }

function date_with_month_check($nice) { if($nice=='0000-00-00') { $nice1='--'; } else { $nice1=date("M-d-Y",strtotime($nice)); } return $nice1; }

function tree_image($nice)
{
if($nice=='f') { $nice1='free.gif'; }
if($nice=='a') { $nice1='extra_amount.gif'; }
return $nice1;
}

$admin_url='admin';

function tree_1($nice) { if ($nice=='left') { $nice1='center'; } if ($nice=='right') { $nice1='center'; } return $nice1; }
function tree_2($nice) { if ($nice=='left') { $nice1='center'; } if ($nice=='right') { $nice1='center'; } return $nice1; }

/*
function main_tree($nice,$nice1) { $second=mysql_query("select * from $nice where sno='' $nice1"); $a3=''; $a3query=''; $a2=''; $a2query=''; while ($second_2=mysql_fetch_array($second)) { $a2='<span>'.$second_2['sno'].'</span>'; $a3=$a3.$a2; $a2query=" or sponsor_id='$a1'"; } return $a3; }

function main_tree_where($nice,$nice1) { $second=mysql_query("select * from $nice where sno='' $nice1"); $a3=''; $a3query=''; $a2=''; $a2query=''; while ($second_2=mysql_fetch_array($second)) { $a2=$second_2['sno']; $a2query=" or sponsor_id='$a2'"; $a3query=$a3query.$a2query; } return $a3query; }


function main_tree_query($nice,$nice1)
{
$second=mysql_query("select * from $nice where sno='' $nice1");
return $second;
}
*/
function amount_sum($amount,$perc)
{
$nice=$amount*$perc/100;
return $nice;
}
function detuct_sum($amount,$per)
{
$nice=$amount*$per/100;
return $nice;
}
function net_sum($nice,$nice1)
{
$nice2=$nice-$nice1;
return $nice2;
}
include "dated.php";
?>


<?php
function double_concept($nice,$nice1)
{
$nice2=mysql_num_rows(mysql_query("select * from $nice1 where sponsor_id='$nice'"));
return $nice2;
}
?>



<?php
function w_pen($nice,$nice1,$nice_new)
{
$nice2=mysql_query("select * from $nice1 where user_id='$nice' and trans='$nice_new' and active='3'");
while ($nice3=mysql_fetch_array($nice2))
{
$nice4=$nice4+$nice3['tot_amount'];}
return $nice4;
}


function w_pro($nice,$nice1,$nice_new)
{
$nice2=mysql_query("select * from $nice1 where user_id='$nice' and trans='$nice_new' and active='2'");
while ($nice3=mysql_fetch_array($nice2))
{
$nice4=$nice4+$nice3['tot_amount'];}
return $nice4;
}


function w_suc($nice,$nice1,$nice_new)
{
$nice2=mysql_query("select * from $nice1 where user_id='$nice' and active='1'");
while ($nice3=mysql_fetch_array($nice2))
{
$nice4=$nice4+$nice3['tot_amount'];}
return $nice4;
}

function w_pin($nice,$nice1,$nice_new)
{
$nice2=mysql_query("select * from $nice1 where user_id='$nice' and trans='$nice_new' and active='1'");
while ($nice3=mysql_fetch_array($nice2))
{
$nice4=$nice4+$nice3['tot_amount'];}
return $nice4;
}


function w_renew($nice,$nice1,$nice_new)
{
$nice2=mysql_query("select * from $nice1 where user_id='$nice' and trans='renew' and active='1'");
while ($nice3=mysql_fetch_array($nice2))
{
$nice4=$nice4+$nice3['tot_amount'];}
return $nice4;
}


function seed($nice,$nice1,$nice_new)
{
$nice2=mysql_query("select * from $nice1 where user_id='$nice' and seed!='0.00'");
while ($nice3=mysql_fetch_array($nice2))
{
$nice4=$nice4+$nice3['seed'];}
return $nice4;
}


function total_total($nice,$nice1,$nice2,$nice3,$nice4,$nice5,$nice6)
{
$main=$nice2+$nice3+$nice4-$nice5-$nice1+$nice6;
$total=$nice-$main;
return $total;
}



if(!function_exists('achieve_test_next')){
function achieve_test_next($nice,$nice1,$nice2)
{
if(!function_exists('achieve_test')){
function achieve_test($nice,$nice1,$nice2)
{ $nice_re=mysql_num_rows(mysql_query("select * from $nice1 where sno='$nice' and p1='$nice2'")); return $nice_re;}
}
if(achieve_test($nice,$nice1,$nice2)==1) { $disp='<div style="color:#66CC00;">Got</div>'; } else  if(achieve_test($nice,$nice1,$nice2)==0) { $disp='<div style="color:#FF0000;">Not</div>'; }
return $disp;
}
}



if(!function_exists('achieve_test_next_user')){
function achieve_test_next_user($nice,$nice1,$nice2)
{
if(!function_exists('achieve_test')){
function achieve_test($nice,$nice1,$nice2)
{ $nice_re=mysql_num_rows(mysql_query("select * from $nice1 where sno='$nice' and p1='$nice2'")); return $nice_re;}
}
if(achieve_test($nice,$nice1,$nice2)==1) { $disp='Achieved'; } else  if(achieve_test($nice,$nice1,$nice2)==0) { $disp='Not Achieved'; }
return $disp;
}
}

if(!function_exists('pay_date')){
function pay_date($nice) {
$nice1=explode("-",$nice);
$nice2=$nice1['2'];
$nice_y=$nice1['0'];
$nice_m=$nice1['1'];
if ($nice2<=15) { $nice3='22'; $month_value='0';}else
if ($nice2>=16) { $nice3='7'; $month_value='1';}//$nice33=$nice_y."-".$nice_m."-".$nice3;
$pay_out_date = mktime(0, 0, 0, $nice_m+$month_value, $nice3, $nice_y);//$nice33=date("Y-m-d",$pay_out_date);
$nice33=date("d",$pay_out_date);
return $nice33; } }

if(!function_exists('pay_month')){
function pay_month($nice) {
$nice1=explode("-",$nice);
$nice2=$nice1['2'];
$nice_y=$nice1['0'];
$nice_m=$nice1['1'];
if ($nice2<=15) { $nice3='22'; $month_value='0';}else
if ($nice2>=16) { $nice3='7'; $month_value='1';}//$nice33=$nice_y."-".$nice_m."-".$nice3;
$pay_out_date = mktime(0, 0, 0, $nice_m+$month_value, $nice3, $nice_y);//$nice33=date("Y-m-d",$pay_out_date);
$nice33=date("m",$pay_out_date);
return $nice33; } }

if(!function_exists('pay_year')){
function pay_year($nice) {
$nice1=explode("-",$nice);
$nice2=$nice1['2'];
$nice_y=$nice1['0'];
$nice_m=$nice1['1'];
if ($nice2<=15) { $nice3='22'; $month_value='0';}else
if ($nice2>=16) { $nice3='7'; $month_value='1';}//$nice33=$nice_y."-".$nice_m."-".$nice3;
$pay_out_date = mktime(0, 0, 0, $nice_m+$month_value, $nice3, $nice_y);//$nice33=date("Y-m-d",$pay_out_date);
$nice33=date("Y",$pay_out_date);
return $nice33; } }
/*
$date_check="2011-12-31";
echo pay_year("$date_check")."-".pay_month("$date_check")."-".pay_date("$date_check");
*/?>

<?php
function clean_num($num){ return trim(trim($num, '0'), '.'); }
$link_for_reg='http://www.pgmmarketings.in/investment/';
?>

<?php
function le($a,$b,$c,$d)
{
$e=mysql_query("select * from $d where sno='' $a") or die (mysql_error()); while ($f=mysql_fetch_array($e)) {$g=$g+$f[amount];}
$h=$g*$c/100;
return $h;
}
?>
<?php
function qe($a,$d)
{
$e=mysql_query("select * from $d where sno='' $a") or die (mysql_error()); while ($f=mysql_fetch_array($e)) {
$i=$i." or refer_id='".$f[sno]."' and active='1'";
}
return $i;
}
?>

<?php
function num_bu($a,$d)
{
$e=mysql_query("select * from $d where sno='' $a") or die (mysql_error());
$super=mysql_num_rows($e);
/*while ($f=mysql_fetch_array($e)) {
$i=$i." or refer_id='".$f[sno]."' and active='1'"; }*/
return $super;
}
?>



<?php
function tree_concept($table4,$nice_id)
{
if($nice_id!='') {

/*if(!function_exists('new_id')){
function new_id($nice,$nicea) { if($nice<=19530) {$nice1=T1;} else if($nice<=305175780) {$nice1=T2;} $checking=mysql_fetch_array(mysql_query("select * from $nicea where sno='$nice'")); $nice2=$checking[months]; $nice3=$nice2.$nice.$nice1; return $nice3; }
}*/
$full_id=new_number($nice_id,$table4);
//$idddd=kandu_pidi_new($nice_id,$table4,name,sno);
$prabakar="'".$full_id."<br />".kandu_pidi_new($nice_id,$table4,name,sno)."<br />".date_only(kandu_pidi_new($nice_id,$table4,dated,sno))."', this, event, '100px'";
$links='<a href="?tree_view_concept_id='.$nice_id.'" style="color:#000000; text-decoration:none;"><img src="images/trees003.gif" width="50" height="52" border="0" onMouseover="fixedtooltip('.$prabakar.')" onMouseout="delayhidetip()" /><br />'.$idddd.' '.$full_id.'</a>';
}
else
{
//$links='<img src="images/tree/tree.png" width="52" height="52">';
$links='<img src="images/tree/nice.gif" width="52" height="52"><br />Empty';
}
return $links;
}


function tree_concept_new($table4,$nice_id,$nice)
{
$prabakar=mysql_fetch_array(mysql_query("select * from $table4 where refer_id='$nice_id' limit $nice,1"));
return $prabakar[sno];
}

/*
function pudhu_id_kudu($nice,$nice1,$nice2)
{
$test=mysql_fetch_array(mysql_query("select * from $nice where fran!='' and fran!='5' order by $nice2 desc"));
$testing=$test[sno];

$test_12=mysql_fetch_array(mysql_query("select * from $nice where fran!='' order by $nice2 desc"));
$testing_12=$test_12[sno];

if($testing!='') {$testing_value=$testing;}else{$testing_value=$testing_12+1;}
return $testing_value;
}
*/

function pudhu_id_kudu($nice,$nice1,$nice2)
{
$test_12=mysql_fetch_array(mysql_query("select * from $nice order by $nice2 desc"));
//$testing_12=$test_12[$nice2];
$leveling=$test_12[$nice2];
if(mysql_num_rows(mysql_query("select * from $nice where level_id='$test_12[$nice2]'"))==pow(5,$leveling))
{
$just=mysql_fetch_array(mysql_query("select * from $nice where level_id='$test_12[$nice2]' order by $nice2"));
$testing_value=$just[sno];
}
else
{
$level=$test_12[$nice2]-1;
$just=mysql_fetch_array(mysql_query("select * from $nice where level_id='$level' order by fran"));
$testing_value=$just[sno];
}

return $testing_value;
}

$refer_id=pudhu_id_kudu($table4,refer_id,level_id);
//echo $refer_id;

$percentage_value='20';

function with_tax($nice,$nice1)
{
$nice2=$nice-($nice*$nice1/100);
return $nice2;
}

function next_last_find($nice,$nice1,$nice2,$nice3)
{
$nice4=date('Y-m-t',mktime(0, 0, 0, $nice+$nice1, $nice2, $nice3));
return $nice4;
}


function new_con($nice){if($nice<=19530) {$nice1=T1;} else if($nice<=305175780) {$nice1=T2;}return $nice1;}

function new_number($nice,$nicea) { if($nice!=0){/*if($nice<=19530) {$nice1=T1;} else if($nice<=305175780) {$nice1=T2;}*/$checking=mysql_fetch_array(mysql_query("select * from $nicea where sno='$nice'")); /*$nice2=$checking[months];*/ $nice3=$nice2.$nice.$nice1; return $nice3.', '.$checking[name]; }else{return '-';}}
$default_investment='10000';
$default_permonth='500';
?>
