<?php
if(!function_exists('calculate_pannu_2_1')){
function calculate_pannu_2_1($nice,$nice1,$timing)
{
$select="select * from $nice1 where sno='' ";
$max_value=$common_level_count_total+10;
$max_value='1';


if(!function_exists('file_name')){
function file_name($test)
{
$test1=explode("/","$test");
$test2=count($test1);
$testing=$test1[$test2-2];
return $testing;
}
}

$for_file_name=file_name($_SERVER['PHP_SELF']);
if($for_file_name!='rambakthan') { include "include/dated.php"; } else { include "../include/dated.php"; }



if($timing=='t')
{
$started=$dated_week_start.' 00:00:00';
$ended=$dated_week_end.' 23:59:59';
}
else
{
$started=$timing;
$ended=$dated_week_end.' 23:59:59';
}

//$select_1=" and datetimed>='$started' and datetimed<='$ended'";
$select_1='';

$where_c_1=" or sponsor_id='".$nice."' and active='1' $select_1";





if(!function_exists('query')){
function query($new,$new1,$new2)
{
$nice_q_0=mysql_query("$new $new1 $new2") or die (mysql_error());
$nice_c_0=mysql_num_rows($nice_q_0);
while ($nice_a_0=mysql_fetch_array($nice_q_0))
{
$nice_r_0=$nice_a_0['uniq_ids'];
$nice_w_1=$nice_w_1." or sponsor_id='".$nice_r_0."' and active='1'  $new2";
//$nice_t_0=$nice_t_0+$nice_a_0['bv'];
}
return $nice_w_1;
}
}


if(!function_exists('cound')){
function cound($new,$new1,$new2)
{
$nice_q_0=mysql_query("$new $new1") or die (mysql_error());
$nice_c_0=mysql_num_rows($nice_q_0);
/*while ($nice_a_0=mysql_fetch_array($nice_q_0))
{
$nice_r_0=$nice_a_0['uniq_ids'];
$nice_w_1=$nice_w_1." or sponsor_id='".$nice_r_0."' and active='1'  $new2";
$nice_t_0=$nice_t_0+$nice_a_0['bv'];
}*/
return $nice_c_0;
}
}


if(!function_exists('bvs')){
function bvs($new,$new1,$new2)
{
$nice_q_0=mysql_query("$new $new1") or die (mysql_error());
$nice_c_0=mysql_num_rows($nice_q_0);
while ($nice_a_0=mysql_fetch_array($nice_q_0))
{
/*
$nice_r_0=$nice_a_0['uniq_ids'];
$nice_w_1=$nice_w_1." or sponsor_id='".$nice_r_0."' and active='1'  $new2";
*/
$nice_t_0=$nice_t_0+$nice_a_0['bv'];
}
return $nice_t_0;
}
}


for ($i=1;$i<=$max_value;$i++){
$j=$i+1;
$where_c_j='where_c_'.$j;
$where_c_k='where_c_'.$i;
$$where_c_j=query($select,$$where_c_k,$select_1);
$bv_v_j='bv_v_'.$j;
$$bv_v_j=bvs($select,$$where_c_k,$select_1);
$bv_v_j_total=$bv_v_j_total+$$bv_v_j;

$j=$i+1;
$count_n_j='count_n_'.$j;
$$count_n_j=cound($select,$$where_c_k,$select_1);
}
//echo $where_c_3;
/*
for ($i=1;$i<=$max_value;$i++){
$j=$i+1;
$bv_v_j='bv_v_'.$j;
$where_c_k='where_c_'.$i;
$$bv_v_j=bvs($select,$$where_c_k,$select_1);
$bv_v_j_total=$bv_v_j_total+$$bv_v_j;
}

for ($i=1;$i<=$max_value;$i++){
$j=$i+1;
$count_n_j='count_n_'.$j;
$where_c_k='where_c_'.$i;
$$count_n_j=cound($select,$$where_c_k,$select_1);
}
*/
if(!function_exists('kandu_pidi_new')){ function kandu_pidi_new($a_nice,$a_nice1,$a_nice2,$a_nice_new) { $a_nice3=mysql_fetch_array(mysql_query("select * from $a_nice1 where $a_nice_new='$a_nice'")); $a_nice4=$a_nice3[$a_nice2]; return $a_nice4; } }

$bv_v_j_total_new=$bv_v_j_total+kandu_pidi_new($nice,$nice1,bv,uniq_ids);
return $bv_v_j_total_new;
}
}


if(!function_exists('samam_right')){
function samam_right($nice,$nice1)
{
if($nice>$nice1) { $left_earning_amount_main_concept=$nice-$nice1; $big_value=$nice; $small_value=$nice1; }
if($nice1>$nice) { $right_earning_amount_main_concept=$nice1-$nice; $big_value=$nice1; $small_value=$nice; }
if($nice1==$nice) { $right_earning_amount_main_concept=0; $left_earning_amount_main_concept=0; }
return $left_earning_amount_main_concept;
}
}

if(!function_exists('samam_left')){
function samam_left($nice,$nice1)
{
if($nice>$nice1) { $left_earning_amount_main_concept=$nice-$nice1; $big_value=$nice; $small_value=$nice1; }
if($nice1>$nice) { $right_earning_amount_main_concept=$nice1-$nice; $big_value=$nice1; $small_value=$nice; }
if($nice1==$nice) { $right_earning_amount_main_concept=0; $left_earning_amount_main_concept=0; }
return $right_earning_amount_main_concept;
}
}

if(!function_exists('samam')){
function samam($nice,$nice1)
{
if($nice>$nice1) { $left_earning_amount_main_concept=$nice-$nice1; $big_value=$nice; $small_value=$nice1; }
if($nice1>$nice) { $right_earning_amount_main_concept=$nice1-$nice; $big_value=$nice1; $small_value=$nice; }
if($nice1==$nice) { $right_earning_amount_main_concept=0; $left_earning_amount_main_concept=0;$small_value=$nice; }
return $small_value;
}
}
?>