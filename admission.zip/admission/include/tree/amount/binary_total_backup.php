<?php
// start
$tree_id_new=$right_side_man;
$select="select * from $table4 where ";
$where_con=" sponsor_id='".$tree_id_new."' and active='1'";
$new_think=mysql_query("$select $where_con");
$different_conceptb_count=mysql_num_rows($new_think);
while ($new_think_array=mysql_fetch_array($new_think))
{
$nice=$new_think_array['uniq_ids'];
$nice_newa0=$nice_newa0." or sponsor_id='".$nice."' and active='1'";
$different_amounta_commission=$different_amounta_commission+$new_think_array['bv'];
}
//echo $nicea;
//end
?>
<?php
//start

/*
$new_think1=mysql_query("$select sno='' $nice0a");
$different_concept1b_count=mysql_num_rows($new_think1);
while ($new_think1_array=mysql_fetch_array($new_think1))
{
$nice1=$new_think1_array['uniq_ids'];
$nice1a=$nice1a." or sponsor_id='".$nice1."' and active='1'";
$different_amount1a_commission=$different_amount1a_commission+$new_think1_array['bv'];
}
*/

//$different_amount_a_commission_y_z='';
$nice_newa_q='';
for ($i=1;$i<=5;$i++){
$k=$i-1;

$jupiter_web_soft='jupiter_web_soft'.$i;
$different_conceptc='different_conceptc'.$i;
$jupiter_web_softa='jupiter_web_softa'.$i;
$nice_new='nice_new'.$i;
$nice_newa='nice_newa'.$i;
$different_amount_a_commission='different_amount_a_commission'.$i;

$nice_newa_k='nice_newa'.$k;
$nice_newa_m=$$nice_newa_k;

$nice_newa_p='nice_newa'.$p;
$nice_newa_q=$$nice_newa_p;

$jupiter_web_softa_y=$$jupiter_web_softa;
$nice_new_y=$$nice_new;
$nice_newa_y=$$nice_newa;
$different_amount_a_commission_y=$$different_amount_a_commission;
$perum_imisai="$select sno='' $nice_newa_m";
$$jupiter_web_soft=mysql_query($perum_imisai);
$$different_conceptc=mysql_num_rows($$jupiter_web_soft);

while ($jupiter_web_softa_y=mysql_fetch_array($$jupiter_web_soft))
{
$nice_new_y=$jupiter_web_softa_y['uniq_ids'];
//$nice_newa_y=$nice_newa_y." or sponsor_id='".$nice_new_y."' and active='1'";
$nice_newa_q=$nice_newa_q." or sponsor_id='".$nice_new_y."' and active='1'";
$different_amount_a_commission_y=$different_amount_a_commission_y+$jupiter_web_softa_y['bv'];
}
$different_amount_a_commission_y_z=$different_amount_a_commission_y_z+$different_amount_a_commission_y;
echo '<br />';
echo '<br />';
echo $nice_newa_q; echo ', '; echo $i;
}
//echo $nice1a;
//end
echo '<br />';
echo $different_amount_a_commission_y_z;
?>
