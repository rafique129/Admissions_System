<?php
// start
$tree_id_new=$left_side_man;
$select="select * from $table4 where ";
/*
$where_con=" sponsor_id='".$tree_id_new."' and active='1'";
$new_think=mysql_query("$select $where_con");
$different_conceptb_count=mysql_num_rows($new_think);
while ($new_think_array=mysql_fetch_array($new_think))
{
$nice=$new_think_array['uniq_ids'];
$nice_newa0=$nice_newa0." or sponsor_id='".$nice."' and active='1'";
$different_amounta_commission=$different_amounta_commission+$new_think_array['bv'];
}
*/
$nice_newa0=" or sponsor_id='$tree_id_new' and active='1'";
//echo $nicea;
//end
?>
<?php
//start


$different_amount_a_commission_y_z='';
for ($i=1;$i<=2;$i++){
$k=$i-1;

$jupiter_web_soft='jupiter_web_soft'.$i;
$different_conceptc='different_conceptc'.$i;
$jupiter_web_softa='jupiter_web_softa'.$i;
$nice_new='nice_new'.$i;
$nice_newa='nice_newa'.$i;
$different_amount_a_commission='different_amount_a_commission'.$i;

$nice_newa_k='nice_newa'.$k;
$nice_newa_m=$$nice_newa_k;

$jupiter_web_softa_y=$$jupiter_web_softa;
$nice_new_y=$$nice_new;
$nice_newa_y=$$nice_newa;
$different_amount_a_commission_y=$$different_amount_a_commission;

$$jupiter_web_soft=mysql_query("$select sno='' $nice_newa_m");
$$different_conceptc=mysql_num_rows($$jupiter_web_soft);
$different_amount_a_commission_y='';
while ($jupiter_web_softa_y=mysql_fetch_array($$jupiter_web_soft))
{
$nice_new_y=$jupiter_web_softa_y['uniq_ids'];
$nice_newa_y=$nice_newa_y." or sponsor_id='".$nice_new_y."' and active='1'";
$different_amount_a_commission_y=$different_amount_a_commission_y+$jupiter_web_softa_y['bv'];
}
$different_amount_a_commission_y_z=$different_amount_a_commission_y_z+$different_amount_a_commission_y;
}
//echo $nice1a;
//end
echo '<br />';
echo $different_amount_a_commission_y_z;
?>
