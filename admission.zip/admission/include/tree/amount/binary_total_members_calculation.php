<?php
if(!function_exists('total_members')){
function total_members($nice,$nice1,$timing)
{
$select="select * from $nice1 where sno='' ";
$max_value=$common_level_count_total+10;
//$max_value='500';


if(!function_exists('file_name')){
function file_name($test)
{
$test1=explode("/","$test");
$test2=count($test1);
$testing=$test1[$test2-2];
return $testing;
}
}

$for_file_name=file_name($_SERVER['PHP_SELF']);
if($for_file_name!='rambakthan') { include "include/dated.php"; } else { include "../include/dated.php"; }



if($timing=='t')
{
$started=$dated_week_start.' 00:00:00';
$ended=$dated_week_end.' 23:59:59';
}
else
{
$started=$timing;
$ended=$dated_week_end.' 23:59:59';
}

//$select_1=" and datetimed>='$started' and datetimed<='$ended'";
$select_1='';

$where_c_1=" or sponsor_id='".$nice."' and active='1' $select_1";



if(!function_exists('date_with_day')){ function date_with_day($nice) { $nice1=date("d-m-Y (D)",strtotime($nice)); return $nice1; } }


if(!function_exists('query')){
function query($new,$new1,$new2)
{
$nice_q_0=mysql_query("$new $new1 $new2") or die (mysql_error());
$nice_c_0=mysql_num_rows($nice_q_0);
while ($nice_a_0=mysql_fetch_array($nice_q_0))
{
$nice_r_0=$nice_a_0['uniq_ids'];
$nice_w_1=$nice_w_1." or sponsor_id='".$nice_r_0."' and active='1'  $new2";
//$nice_t_0=$nice_t_0+$nice_a_0['bv'];
}
return $nice_w_1;
}
}


if(!function_exists('cound')){
function cound($new,$new1,$new2)
{
$nice_q_0=mysql_query("$new $new1") or die (mysql_error());
$nice_c_0=mysql_num_rows($nice_q_0);
/*while ($nice_a_0=mysql_fetch_array($nice_q_0))
{
$nice_r_0=$nice_a_0['uniq_ids'];
$nice_w_1=$nice_w_1." or sponsor_id='".$nice_r_0."' and active='1'  $new2";
$nice_t_0=$nice_t_0+$nice_a_0['bv'];
}*/
return $nice_c_0;
}
}


if(!function_exists('bvs')){
function bvs($new,$new1,$new2)
{
$nice_q_0=mysql_query("$new $new1") or die (mysql_error());
$nice_c_0=mysql_num_rows($nice_q_0);
while ($nice_a_0=mysql_fetch_array($nice_q_0))
{
/*
$nice_r_0=$nice_a_0['uniq_ids'];
$nice_w_1=$nice_w_1." or sponsor_id='".$nice_r_0."' and active='1'  $new2";
*/
$nice_t_0=$nice_t_0+$nice_a_0['bv'];
}
return $nice_t_0;
}
}

if(!function_exists('tds')){
function tds($new,$new1,$new2)
{
$nice_q_0=mysql_query("$new $new1") or die (mysql_error());
$nice_c_0=mysql_num_rows($nice_q_0);
$tr_start='<tr>';
$tr_end='</tr>';
while ($nice_a_0=mysql_fetch_array($nice_q_0))
{ 
$td_val='<td>INDHA_IDATHIL_NUMBER</td><td class="main_profile">'.$nice_a_0[uniq_ids].'</td><td class="main_profile">'.$nice_a_0[name].'</td><td class="main_profile">'.date_with_day($nice_a_0[dated]).'</td>';
$td_val_to=$tr_start.$td_val.$tr_end;
$td_val_total=$td_val_total.$td_val_to;
}
return $td_val_total;
}
}

$m='';
for ($i=1;$i<=$max_value;$i++){	$m++;
$j=$i+1;
$where_c_j='where_c_'.$j;
$where_c_k='where_c_'.$i;
$$where_c_j=query($select,$$where_c_k,$select_1);
$bv_v_j='bv_v_'.$j;
$$bv_v_j=bvs($select,$$where_c_k,$select_1);
$bv_v_j_total=$bv_v_j_total+$$bv_v_j;

$j=$i+1;
$count_n_j='count_n_'.$j;
$$count_n_j=cound($select,$$where_c_k,$select_1);

$j=$i+1;
$downl_n_j='downl_n_'.$j;
$$downl_n_j=tds($select,$$where_c_k,$select_1);
$downl_n_j_new=str_replace("INDHA_IDATHIL_NUMBER","INDHA_IDATHIL_NUMBER",$$downl_n_j);
$downl_n_j_total=$downl_n_j_total.$downl_n_j_new;
}

$change_pannu_fast=explode("IDATHIL_NUMBER",$downl_n_j_total);
$waste_count=count($change_pannu_fast);

for ($waste=0;$waste<=$waste_count-1;$waste++)
{
$jupiter_web_soft_test=$change_pannu_fast[$waste];
$waste_new=$waste+2;
if ($waste_new%2!=0)
{$new_variable='<tr style="height:25px; background:#F0F0F0;"><td class="main_profile">'.$waste_new;}
else
{ $new_variable='<tr style="height:25px;"><td class="main_profile">'.$waste_new; }
$jupiter_web_soft=str_replace("<tr><td>INDHA_",$new_variable,$jupiter_web_soft_test);
$jupiter_web_soft_new=$jupiter_web_soft_new.$jupiter_web_soft;
}
//echo $where_c_3;
/*
for ($i=1;$i<=$max_value;$i++){
$j=$i+1;
$bv_v_j='bv_v_'.$j;
$where_c_k='where_c_'.$i;
$$bv_v_j=bvs($select,$$where_c_k,$select_1);
$bv_v_j_total=$bv_v_j_total+$$bv_v_j;
}

for ($i=1;$i<=$max_value;$i++){
$j=$i+1;
$count_n_j='count_n_'.$j;
$where_c_k='where_c_'.$i;
$$count_n_j=cound($select,$$where_c_k,$select_1);
}
*/

//return $jupiter_web_soft_new;
return $waste_new-1;
}
}


if(!function_exists('samam_right')){
function samam_right($nice,$nice1)
{
if($nice>$nice1) { $left_earning_amount_main_concept=$nice-$nice1; $big_value=$nice; $small_value=$nice1; }
if($nice1>$nice) { $right_earning_amount_main_concept=$nice1-$nice; $big_value=$nice1; $small_value=$nice; }
if($nice1==$nice) { $right_earning_amount_main_concept=0; $left_earning_amount_main_concept=0; }
return $left_earning_amount_main_concept;
}
}

if(!function_exists('samam_left')){
function samam_left($nice,$nice1)
{
if($nice>$nice1) { $left_earning_amount_main_concept=$nice-$nice1; $big_value=$nice; $small_value=$nice1; }
if($nice1>$nice) { $right_earning_amount_main_concept=$nice1-$nice; $big_value=$nice1; $small_value=$nice; }
if($nice1==$nice) { $right_earning_amount_main_concept=0; $left_earning_amount_main_concept=0; }
return $right_earning_amount_main_concept;
}
}

if(!function_exists('samam')){
function samam($nice,$nice1)
{
if($nice>$nice1) { $left_earning_amount_main_concept=$nice-$nice1; $big_value=$nice; $small_value=$nice1; }
if($nice1>$nice) { $right_earning_amount_main_concept=$nice1-$nice; $big_value=$nice1; $small_value=$nice; }
if($nice1==$nice) { $right_earning_amount_main_concept=0; $left_earning_amount_main_concept=0;$small_value=$nice; }
return $small_value;
}
}
?>