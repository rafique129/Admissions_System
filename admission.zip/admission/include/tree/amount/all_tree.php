<?php
if(!function_exists('all_tree')){
function all_tree($nice,$nice1,$timing)
{
//echo "select * from $nice1 where refer_id='$nice' and active='1' and side='$timing'";
$prabakar=mysql_query("select * from $nice1 where refer_id='$nice' and active='1'") or (mysql_error());
while ($prabakars=mysql_fetch_array($prabakar))
{
$prabakars3=$prabakars['sno'];
$prabhu12=$prabhu12." or refer_id='".$prabakars3."' and active='1' ";

$td_val='<td class="for_border" align="center"><img src="images/trees003.gif" width="50" height="52"><br />'.$prabakars[name].' ('.new_number($prabakars[sno],$nice1).')</td>';
$td_val_to=$tr_start.$td_val.$tr_end;
$td_val_total=$td_val_total.$td_val_to;
}

$poda_jupiter_web_soft_new='<div align="left"><table border=1><tr><td class="for_border1" width="75">Level 1</td>'.$td_val_total.'</tr></table></div>';
/*
$poda_change_pannu_fast=explode("IDATHIL_NUMBER",$td_val_total);
$poda_waste_count=count($poda_change_pannu_fast);

for ($poda_waste=0;$poda_waste<=$poda_waste_count-1;$poda_waste++)
{
$poda_jupiter_web_soft_test=$poda_change_pannu_fast[$poda_waste];
$poda_waste_new=$poda_waste+1;
if ($poda_waste_new%2!=0)
{$poda_new_variable='<tr style="height:25px; background:#E3E3E3;"><td class="for_border">'.$poda_waste_new;}
else
{ $poda_new_variable='<tr style="height:25px;"><td class="for_border">'.$poda_waste_new; }
$poda_jupiter_web_soft=str_replace("<tr><td>INDHA_",$poda_new_variable,$poda_jupiter_web_soft_test);
$poda_jupiter_web_soft_new=$poda_jupiter_web_soft_new.$poda_jupiter_web_soft;
}
*/
$common_level_count=mysql_fetch_array(mysql_query("select * from $nice1 order by level_id desc"));
$common_level_count_total=$common_level_count['level_id'];

$common_level_count_1=mysql_fetch_array(mysql_query("select * from $nice1 where sno='$nice'"));
$common_level_count_3=$common_level_count_1['level_id'];
$select="select * from $nice1 where sno='' ";
$max_value=$common_level_count_total-1-$common_level_count_3;



if(!function_exists('file_name')){
function file_name($test)
{
$test1=explode("/","$test");
$test2=count($test1);
$testing=$test1[$test2-2];
return $testing;
}
}

$for_file_name=file_name($_SERVER['PHP_SELF']);
//if($for_file_name!='rambakthan') { include "include/dated.php"; } else { include "../include/dated.php"; }




//$select_1=" and datetimed>='$started' and datetimed<='$ended'";
$select_1='';

//$where_c_1=" or refer_id='".$nice."' and active='1' $prabhu12";
$where_c_1=" $prabhu12";
//echo $where_c_1;

if(!function_exists('date_with_day')){ function date_with_day($nice) { if(($nice=='0000-00-00 00:00:00') or ($nice=='')) { $nice1='--'; } else{$nice1=date("d-m-Y (D)",strtotime($nice)); } return $nice1; } }


if(!function_exists('query')){
function query($new,$new1,$new2)
{
$nice_q_0=mysql_query("$new $new1 $new2") or die (mysql_error());
$nice_c_0=mysql_num_rows($nice_q_0);
while ($nice_a_0=mysql_fetch_array($nice_q_0))
{
$nice_r_0=$nice_a_0['sno'];
$nice_w_1=$nice_w_1." or refer_id='".$nice_r_0."' and active='1'  $new2";
//$nice_t_0=$nice_t_0+$nice_a_0['bv'];
}
return $nice_w_1;
}
}


if(!function_exists('cound')){
function cound($new,$new1,$new2)
{
$nice_q_0=mysql_query("$new $new1") or die (mysql_error());
$nice_c_0=mysql_num_rows($nice_q_0);
/*while ($nice_a_0=mysql_fetch_array($nice_q_0))
{
$nice_r_0=$nice_a_0['sno'];
$nice_w_1=$nice_w_1." or refer_id='".$nice_r_0."' and active='1'  $new2";
$nice_t_0=$nice_t_0+$nice_a_0['bv'];
}*/
return $nice_c_0;
}
}


if(!function_exists('bvs')){
function bvs($new,$new1,$new2)
{
$nice_q_0=mysql_query("$new $new1") or die (mysql_error());
$nice_c_0=mysql_num_rows($nice_q_0);
while ($nice_a_0=mysql_fetch_array($nice_q_0))
{
/*
$nice_r_0=$nice_a_0['sno'];
$nice_w_1=$nice_w_1." or refer_id='".$nice_r_0."' and active='1'  $new2";
*/
$nice_t_0=$nice_t_0+$nice_a_0['bv'];
}
return $nice_t_0;
}
}

if(!function_exists('tds')){
function tds($new,$new1,$new2)
{
$nice_q_0=mysql_query("$new $new1") or die (mysql_error());
$nice_c_0=mysql_num_rows($nice_q_0);
//$tr_start='<tr>';
//$tr_end='</tr>';
while ($nice_a_0=mysql_fetch_array($nice_q_0))
{ 
/*$td_val='<td>INDHA_IDATHIL_NUMBER</td><td class="for_border">'.$nice_a_0[sno].'</td><td class="for_border">'.$nice_a_0[name].'</td><td class="for_border">'.date_with_day($nice_a_0[dated]).'</td>';*/
$new_table=str_replace('select * from ','',$new);
$new_table=str_replace(" where sno='' ","",$new_table);
$td_val='<td class="for_border" align="center"><img src="images/trees003.gif" width="50" height="52"><br />'.$nice_a_0[name].' ('.new_number($nice_a_0[sno],$new_table).')</td>';
$td_val_to=$tr_start.$td_val.$tr_end;
$td_val_total=$td_val_total.$td_val_to;
}
return $td_val_total;
}
}

$downl_n_j_new='';
$m='';
$j='';
$i='';
$downl_n_j_new1='';
$downl_n_j_total='';
for ($i=1;$i<=$max_value;$i++){	$m++;
$j=$i+1;
$where_c_j='where_c_'.$j;
$where_c_k='where_c_'.$i;
$$where_c_j=query($select,$$where_c_k,$select_1);
$bv_v_j='bv_v_'.$j;
$$bv_v_j=bvs($select,$$where_c_k,$select_1);
$bv_v_j_total=$bv_v_j_total+$$bv_v_j;

$j=$i+1;
$count_n_j='count_n_'.$j;
$$count_n_j=cound($select,$$where_c_k,$select_1);


$j=$i+1;
$downl_n_j='downl_n_'.$j;
$$downl_n_j=tds($select,$$where_c_k,$select_1);
$downl_n_j_new=str_replace("INDHA_IDATHIL_NUMBER","INDHA_IDATHIL_NUMBER",$$downl_n_j);
//if($downl_n_j_new!='') {
$downl_n_j_new1='<div align="left"><table border=1><tr><td class="for_border1" width="75">Level '.$j.'</td>'.$downl_n_j_new.'</tr></table></div>
'; //}
$downl_n_j_total=$downl_n_j_total.$downl_n_j_new1;
}
$jupiter_web_soft_new=$downl_n_j_total;
/*
$change_pannu_fast=explode("IDATHIL_NUMBER",$downl_n_j_total);
$waste_count=count($change_pannu_fast);

for ($waste=0;$waste<=$waste_count-1;$waste++)
{
$jupiter_web_soft_test=$change_pannu_fast[$waste];
$waste_new=$waste+$poda_waste_count;
if ($waste_new%2!=0)
{$new_variable='<tr style="height:25px; background:#E3E3E3;"><td class="for_border">'.$waste_new;}
else
{ $new_variable='<tr style="height:25px;"><td class="for_border">'.$waste_new; }
$jupiter_web_soft=str_replace("<tr><td>INDHA_",$new_variable,$jupiter_web_soft_test);
$jupiter_web_soft_new=$jupiter_web_soft_new.$jupiter_web_soft;
}
*/


$jupiter_web_soft_new_total_value=$poda_jupiter_web_soft_new.$jupiter_web_soft_new;



//echo $where_c_3;
/*
for ($i=1;$i<=$max_value;$i++){
$j=$i+1;
$bv_v_j='bv_v_'.$j;
$where_c_k='where_c_'.$i;
$$bv_v_j=bvs($select,$$where_c_k,$select_1);
$bv_v_j_total=$bv_v_j_total+$$bv_v_j;
}

for ($i=1;$i<=$max_value;$i++){
$j=$i+1;
$count_n_j='count_n_'.$j;
$where_c_k='where_c_'.$i;
$$count_n_j=cound($select,$$where_c_k,$select_1);
}
*/

return $jupiter_web_soft_new_total_value;
}
}


if(!function_exists('samam_right')){
function samam_right($nice,$nice1)
{
if($nice>$nice1) { $left_earning_amount_main_concept=$nice-$nice1; $big_value=$nice; $small_value=$nice1; }
if($nice1>$nice) { $right_earning_amount_main_concept=$nice1-$nice; $big_value=$nice1; $small_value=$nice; }
if($nice1==$nice) { $right_earning_amount_main_concept=0; $left_earning_amount_main_concept=0; }
return $left_earning_amount_main_concept;
}
}

if(!function_exists('samam_left')){
function samam_left($nice,$nice1)
{
if($nice>$nice1) { $left_earning_amount_main_concept=$nice-$nice1; $big_value=$nice; $small_value=$nice1; }
if($nice1>$nice) { $right_earning_amount_main_concept=$nice1-$nice; $big_value=$nice1; $small_value=$nice; }
if($nice1==$nice) { $right_earning_amount_main_concept=0; $left_earning_amount_main_concept=0; }
return $right_earning_amount_main_concept;
}
}

if(!function_exists('samam')){
function samam($nice,$nice1)
{
if($nice>$nice1) { $left_earning_amount_main_concept=$nice-$nice1; $big_value=$nice; $small_value=$nice1; }
if($nice1>$nice) { $right_earning_amount_main_concept=$nice1-$nice; $big_value=$nice1; $small_value=$nice; }
if($nice1==$nice) { $right_earning_amount_main_concept=0; $left_earning_amount_main_concept=0;$small_value=$nice; }
return $small_value;
}
}
?>