<?php $different_concept4=mysql_query("select * from $jws_b4table where level_id='$different_concept3a_user_id' group by user_id");	/*$different_concept4a_count=mysql_num_rows($different_concept4); $different_concept4a_commission='0';*/
while ($different_concept4a=mysql_fetch_array($different_concept4))	{	$different_concept4a_user_id=$different_concept4a['user_id'];	?>
<ul>
<li><?php /*echo $different_concept4a_user_id; echo ', ';*/ echo name_display($different_concept4a_user_id,$jws_b3table);
$different_concept4a_commission=$different_concept4a['amount']+$different_concept4a_commission;
include "include/tree/tree/tree5.php"; ?>
</li>
</ul>
<?php } ?>
