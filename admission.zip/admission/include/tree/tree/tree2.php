<?php $different_concept2=mysql_query("select * from $jws_b4table where level_id='$different_concept1a_user_id' group by user_id");	/*$different_concept2a_count=mysql_num_rows($different_concept2); $different_concept2a_commission='0';*/
while ($different_concept2a=mysql_fetch_array($different_concept2))	{	$different_concept2a_user_id=$different_concept2a['user_id'];	?>
<ul>
<li><?php /*echo $different_concept2a_user_id; echo ', ';*/ echo name_display($different_concept2a_user_id,$jws_b3table);
$different_concept2a_commission=$different_concept2a['amount']+$different_concept2a_commission;
include "include/tree/tree/tree3.php"; ?>
</li>
</ul>
<?php }  ?>
