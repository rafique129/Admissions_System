<?php $different_concept6=mysql_query("select * from $jws_b4table where level_id='$different_concept5a_user_id' group by user_id");	/*$different_concept6a_count=mysql_num_rows($different_concept6); $different_concept6a_commission='0';*/
while ($different_concept6a=mysql_fetch_array($different_concept6))	{	$different_concept6a_user_id=$different_concept6a['user_id'];	?>
<ul>
<li><?php /*echo $different_concept6a_user_id; echo ', ';*/ echo name_display($different_concept6a_user_id,$jws_b3table);
$different_concept6a_commission=$different_concept6a['amount']+$different_concept6a_commission;//include "include/tree/tree/tree7.php"; ?>
</li>
</ul>
<?php }  ?>
