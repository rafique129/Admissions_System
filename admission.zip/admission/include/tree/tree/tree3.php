<?php $different_concept3=mysql_query("select * from $jws_b4table where level_id='$different_concept2a_user_id' group by user_id");	/*$different_concept3a_count=mysql_num_rows($different_concept3); $different_concept3a_commission='0';*/
while ($different_concept3a=mysql_fetch_array($different_concept3))	{	$different_concept3a_user_id=$different_concept3a['user_id'];	?>
<ul>
<li><?php /*echo $different_concept3a_user_id; echo ', ';*/ echo name_display($different_concept3a_user_id,$jws_b3table);
$different_concept3a_commission=$different_concept3a['amount']+$different_concept3a_commission; 
include "include/tree/tree/tree4.php"; ?>
</li>
</ul>
<?php } ?>
