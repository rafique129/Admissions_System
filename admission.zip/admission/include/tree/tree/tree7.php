<?php $different_concept7=mysql_query("select * from $jws_b4table where level_id='$different_concept6a_user_id' group by user_id");	while ($different_concept7a=mysql_fetch_array($different_concept7))	{	$different_concept7a_user_id=$different_concept7a['user_id'];	?>
<ul>
<li><?php echo $different_concept7a_user_id; //include "include/tree/tree/tree8.php"; ?>
</li>
</ul>
<?php } ?>
