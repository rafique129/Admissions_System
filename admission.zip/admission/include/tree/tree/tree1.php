<?php $different_concept1=mysql_query("select * from $jws_b4table where level_id='$different_concepta_user_id' group by user_id");	/*$different_concept1a_count=mysql_num_rows($different_concept1); $different_concept1a_commission='0';*/
while ($different_concept1a=mysql_fetch_array($different_concept1))	{	$different_concept1a_user_id=$different_concept1a['user_id'];	?>
<ul>
<li><?php /* echo $different_concept1a_user_id; echo ', '; */echo name_display($different_concept1a_user_id,$jws_b3table);
$different_concept1a_commission=$different_concept1a['amount']+$different_concept1a_commission;
include "include/tree/tree/tree2.php"; ?>
</li>
</ul>
<?php }?>
