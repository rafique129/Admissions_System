<table width="100%">
<tr>
<td align="center" class="tree">
<?php
$tree_view1=$_REQUEST['tree_view1'];
if ($tree_view1=='')
{
if ($tree_view2!='')
{ $tree_common=" and uniq_ids='$tree_view2'"; }
}
else
{ $tree_common=" and uniq_ids='$tree_view1'"; $back_button='<INPUT TYPE="button" VALUE="Back" onClick="history.go(-1);">'; }
//$first_1=mysql_fetch_array(mysql_query("select * from $table4 where active='1' $tree_common"));
$first_1=mysql_fetch_array(mysql_query("select * from $table4 where sno!='' $tree_common"));
$a1=$first_1['uniq_ids'];
echo '<div class="tree1">'.$a1.'<br />'.$first_1['name'].' ('.ucfirst($first_1[side]).')<br />
<img src="include/images/tree/'.tree_image($first_1[method]).'" width="40" height="50">';?>
<table align="center" cellpadding="2" cellspacing="2"><tr><td><a style="color:#000000;" href="user_tree_view.php?tree_view1=<?php echo $first_1[uniq_ids]; ?>"><?php echo $tree_view_link1; ?></a>&nbsp;</td><td><?php if (double($a1,$table4)!=2) { ?><a style="color:#000000;" href="<?php echo $reg_url_link; ?>?new_sponsor_id=<?php echo $first_1[uniq_ids]; ?>"><?php echo $tree_view_link2; ?></a><?php }else{echo $tree_view_link2;} ?>&nbsp;</td></tr></table>
</div>
<?php
/*
$where1=" or sponsor_id='$a1'";

$where2=main_tree_where($table4,$where1);
$where3=main_tree_where($table4,$where2);
$where4=main_tree_where($table4,$where3);
$where5=main_tree_where($table4,$where4);
$where6=main_tree_where($table4,$where5);
$where7=main_tree_where($table4,$where6);
$where8=main_tree_where($table4,$where7);
$where9=main_tree_where($table4,$where8);
$where10=main_tree_where($table4,$where9);
//$where11=main_tree_where($table4,$where10);
*/
include "tree1.php"; echo $back_button;
?>

&nbsp;</td>
</tr>
</table>
