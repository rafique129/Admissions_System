<?php /*<table><tr><?php $treeq3=main_tree_query($table4,$where3); while ($tree3=mysql_fetch_array($treeq3)) { ?><td class="tree" style="text-align:<?php echo tree_1($tree1[side]); ?>; cursor:pointer;"><?php echo $tree3[uniq_ids]; include "tree3.php"; ?>&nbsp;</td><?php } ?></tr></table>*/?>
<table cellpadding="0" cellspacing="0" width="100%">
<?php /*if(mysql_num_rows(mysql_query("select * from $table4 where sponsor_id='$a3' and active='1' order by side"))=='1') { ?>
<tr><td colspan="2" align="center"><img src="include/images/tree_joind.jpg" />&nbsp;</td></tr>
<?php } */?>



<?php if(mysql_num_rows(mysql_query("select * from $table4 where sponsor_id='$a3' and active='1' order by side"))=='0') { ?>
<tr><td colspan="2" align="center"><img src="include/images/tree/arrow2.jpg" />&nbsp;</td></tr>
<tr><td width="50%" align="center"><img src="include/images/tree/amount.gif" width="40" height="50" /><br />Blank</td><td width="50%" align="center"><img src="include/images/tree/amount.gif" width="40" height="50" /><br />Blank&nbsp;</td></tr><?php } $tree3aa=mysql_num_rows(mysql_query("select * from $table4 where sponsor_id='$a3' and active='1' order by side"));?>

<?php if($tree3aa=='2') { ?><tr><td colspan="2" align="center"><img src="include/images/tree/arrow2.jpg" />&nbsp;</td></tr><?php } else if($tree3aa=='1'){ ?><tr><td colspan="2" align="center"><img src="include/images/tree/arrow2.jpg" />&nbsp;</td></tr><?php } ?>

<tr><?php $treeq3=mysql_query("select * from $table4 where sponsor_id='$a3' and active='1' order by side"); while ($tree3=mysql_fetch_array($treeq3)) { ?>


<?php if($tree3aa=='1'){?>
<?php if(kandu_pidi_new($tree3[uniq_ids],$table4,side,uniq_ids)!='left') { ?>
<td class="tree" width="50%"><div class="tree1">
<img src="include/images/tree/amount.gif" width="40" height="50"><br />Blank
</div></td>
<?php }?>
<?php }?>



<td class="tree" width="50%"><div class="tree1" style="text-align:<?php echo tree_1($tree3[side]); ?>;"><?php $a4=$tree3[uniq_ids]; echo ucfirst($tree3[side]); echo '<br />'; echo $a4;  echo '<br />'; echo $tree3[name];//echo ' ('.ucfirst($tree3[side]).')'; ?><br />
<img src="include/images/tree/<?php if ($tree3[side]!='') { echo tree_image($tree3[method]); } else { echo 'amount.gif'; } ?>" width="40" height="50">
<table align="center" cellpadding="2" cellspacing="2"><tr><td><a style="color:#000000;" href="user_tree_view.php?tree_view1=<?php echo $tree3[uniq_ids]; ?>"><?php echo $tree_view_link1; ?></a>&nbsp;</td><td>
<?php if (double($a4,$table4)!=2) { ?><a style="color:#000000;" href="<?php echo $reg_url_link; ?>?new_sponsor_id=<?php echo $tree3[uniq_ids]; ?>"><?php echo $tree_view_link2; ?></a>
<?php } else {echo $tree_view_link2; } ?>&nbsp;</td>



<?php if($tree3aa=='1'){?>
<?php if(kandu_pidi_new($tree3[uniq_ids],$table4,side,uniq_ids)!='right') { ?>
<td class="tree" width="50%"><div class="tree1">
<img src="include/images/tree/amount.gif" width="40" height="50"><br />Blank
</div></td>
<?php }?>
<?php }?>





</tr></table>
</div><?php if($tree_main_user_side=='') {/*include "tree4.php";*/} ?>&nbsp;</td><?php } ?></tr></table>