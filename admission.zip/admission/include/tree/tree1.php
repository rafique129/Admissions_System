<?php /*<table><tr><?php $treeq1=main_tree_query($table4,$where1); while ($tree1=mysql_fetch_array($treeq1)) { ?><td class="tree" style="text-align:<?php echo tree_1($tree1[side]); ?>; cursor:pointer;"><?php echo $tree1[uniq_ids]; include "tree2.php"; ?></td><?php } ?></tr></table>*/?>
<table cellpadding="0" cellspacing="0" width="100%">
<?php /*if(mysql_num_rows(mysql_query("select * from $table4 where sponsor_id='$a1' and active='1' order by side"))=='1') { ?>
<tr><td colspan="2" align="center"><img src="include/images/tree_joind.jpg" />&nbsp;</td></tr>
<?php } */?>


<?php if(mysql_num_rows(mysql_query("select * from $table4 where sponsor_id='$a1' and active='1' order by side"))=='0') { ?>
<tr><td colspan="2" align="center"><img src="include/images/tree/arrow.jpg" />&nbsp;</td></tr>
<tr><td width="50%" align="center"><img src="include/images/tree/amount.gif" width="40" height="50" /><br />Blank&nbsp;</td><td width="50%" align="center"><img src="include/images/tree/amount.gif" width="40" height="50" /><br />Blank&nbsp;</td></tr><?php }  $tree1aa=mysql_num_rows(mysql_query("select * from $table4 where sponsor_id='$a1' and active='1' order by side"));?>

<?php if($tree1aa=='2') { ?><tr><td colspan="2" align="center"><img src="include/images/tree/arrow.jpg" />&nbsp;</td></tr><?php } elseif($tree1aa=='1') { ?><tr><td colspan="2" align="center"><img src="include/images/tree/arrow.jpg" />&nbsp;</td></tr><?php } ?>


<tr><?php $treeq1=mysql_query("select * from $table4 where sponsor_id='$a1' and active='1' order by side"); while ($tree1=mysql_fetch_array($treeq1)) { ?>

<?php if($tree1aa=='1'){?>
<?php if(kandu_pidi_new($tree1[uniq_ids],$table4,side,uniq_ids)!='left') { ?>
<td class="tree" width="50%"><div class="tree1">
<img src="include/images/tree/amount.gif" width="40" height="50"><br />Blank
</div></td>
<?php }?>
<?php }?>


<td class="tree" width="50%"><div style="text-align:<?php echo tree_1($tree1[side]); ?>;" class="tree1">
<?php $a2=$tree1[uniq_ids]; echo ucfirst($tree1[side]); echo '<br />'; echo $a2; echo '<br />'; echo $tree1[name]; //echo ' ('.ucfirst($tree1[side]).')'; ?><br />
<img src="include/images/tree/<?php echo tree_image($tree1[method]); ?>" width="40" height="50">
<table align="center" cellpadding="2" cellspacing="2"><tr><td><a style="color:#000000;" href="user_tree_view.php?tree_view1=<?php echo $tree1[uniq_ids]; ?>"><?php echo $tree_view_link1; ?></a>&nbsp;</td><td>
<?php if (double($a2,$table4)!=2) { ?><a style="color:#000000;" href="<?php echo $reg_url_link; ?>?new_sponsor_id=<?php echo $tree1[uniq_ids]; ?>"><?php echo $tree_view_link2; ?></a><?php }else{echo$tree_view_link2;} ?>&nbsp;</td></tr></table>
</div><?php include "tree2.php"; ?>&nbsp;</td>


<?php if($tree1aa=='1'){?>
<?php if(kandu_pidi_new($tree1[uniq_ids],$table4,side,uniq_ids)!='right') { ?>
<td class="tree" width="50%"><div class="tree1">
<img src="include/images/tree/amount.gif" width="40" height="50"><br />Blank
</div></td>
<?php }?>
<?php }?>


<?php } ?></tr></table>