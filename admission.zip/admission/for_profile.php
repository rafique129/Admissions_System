<table cellpadding="10%" align="center">
<tr>
<td align="center"><a href="profile.php" class="text" style="color:#000000;"><img src="images/my_profile.png" border="0" /></a></td>
<td align="center"><a href="edit_profile.php" class="text" style="color:#000000;"><img src="images/edit_profile.png" border="0" /></a></td>
</tr>
</table>