<?php include"header.php"; ?>
<?php if ($_SESSION['resort_user_login']=='') { echo '<script>window.location.href="website.php";</script>'; } else { ?>
<style>
select.simple_da {font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px;}
</style>

<?php $welcome='Income Report '; include "member.php"; ?>

<?php $ed_ge=mysql_fetch_array(mysql_query("select * from $table4 where sno='$main_sno'")); ?>


<table align="center" cellpadding="0" cellspacing="0" style="border:0px solid #999999;" width="80%">

<tr><td colspan="2" style="text-align:center;"><?php include "for_account.php"; ?></td></tr>

<?php if ($_REQUEST['added']=='1') { ?><tr><td colspan="2" align="center" class="text">Your Information Has Been Updated</td>
</tr><?php } ?>



<tr><td colspan="2" valign="top" height="100%">

<table width="75%" align="center" cellpadding="5" cellspacing="0" height="100%">
<tr bgcolor="#003366">
<td class="ttitle"><strong>Date</strong></td>
<td class="ttitle"><strong>Total Amount</strong></td>
<td class="ttitle"><strong>TDS</strong></td>
<td class="ttitle"><strong>S Charge</strong></td>
<td class="ttitle"><strong>Net Amount</strong></td>
</tr>

<?php $account_page=mysql_query("select * from $table8 where user_id='$main_sno'"); while ($account_page_1=mysql_fetch_array($account_page)) {?>
<tr>
<td class="text"><?php echo date_only($account_page_1['dated']); ?></td>
<td style="text-align:right;" class="text"><?php echo $account_page_1['amount']; ?></td>
<td style="text-align:right;" class="text"><?php echo $account_page_1['amount']/$extra_charges_1; ?></td>
<td style="text-align:right;" class="text"><?php echo $account_page_1['amount']/$extra_charges_2; ?></td>
<td style="text-align:right;" class="text"><?php echo $account_page_1['amount']-$account_page_1['amount']/$extra_charges_new; ?></td>
</tr>
<?php } ?>
</table>

</td></tr>


</table>

<?php include"footer.php"; } ?>