<?php include "include/db.php"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Life Easy - Level Income, Awards & Rewards, Online Earnings, Earn Money at Home</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body bgcolor="#024888" style="margin:0px;">

<table align="center" cellpadding="0" cellspacing="0" width="998">
<tr>
<td style="background:url(images/body_back.jpg) repeat-y" height="20"></td>
</tr>
<tr>
<td valign="top">

<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="top" width="19"><img src="images/left_corner.jpg" width="19" height="20" /></td>
<td style="background:url(images/center.jpg) repeat-x"></td>
<td valign="top" align="right" width="19"><img src="images/right_corner.jpg" width="32" height="20" /></td>
</tr>
<tr>
<td valign="top" width="19"><img src="images/left_back.jpg" /></td>
<td style="background:url(images/center_back.jpg) repeat-x">

<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td style="background:url(images/life_easy_logo.jpg) no-repeat;" width="422px" height="142px"></td>
<td align="right"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="200" height="142">
  <param name="movie" value="globe.swf" />
  <param name="quality" value="high" />
  <param name="wmode" value="transparent" />
  <embed src="globe.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="200" height="142" wmode="transparent"></embed></object></td>
</tr>
</table>

</td>
<td valign="top" align="right" width="19"><img src="images/right_back.jpg" /></td>
</tr>
</table>

</td>
</tr>
<tr>
<td>
<?php
if (($_SESSION['pdc']!='')) { include "menu_logged_in_pdc.php"; }
?>
</td>
</tr>
<tr>
<td valign="top">

<table bgcolor="#f7f8fa" align="center" cellpadding="3" cellspacing="3" width="100%">
<tr>
<td valign="top">

<table bgcolor="#e3ecf5" align="center" cellpadding="0" cellspacing="0" width="100%" height="563">
<tr>
<td width="18" valign="top"><img src="images/old/blue_lt.jpg" width="6" height="6"></td>
<td></td>
<td width="18" valign="top"><img src="images/old/blue_rt.jpg" width="6" height="6"></td>
</tr>
<tr>
<td></td>
<td valign="top">