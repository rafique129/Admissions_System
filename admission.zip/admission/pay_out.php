<?php include"header.php"; ?>
<?php if ($_SESSION['resort_user_login']=='') { echo '<script>window.location.href="website.php";</script>'; } else { ?>

<table align="center" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="14"><img src="images/orange_left.png" width="14" height="43" /></td>
<td style="background:url(images/orange_center.jpg)" class="mtitle"><img src="images/arrow.png" align="absmiddle" /> Payout Details</td>
<td width="14" align="right"><img src="images/orange_right.png" width="14" height="43" /></td>
</tr>
<tr bgcolor="#FFFFFF">
<td></td>
<td valign="top" class="text">


<?php $where=" and active='1'"; include "earning.php";?>

<?php include"footer.php"; } ?>